Unit Tests
==========

> For more details on unit testing, see the internal document on
> [Unit Testing](docs/UnitTesting.md)

```
# cd /vagrant
# nosetests -c .noserc --cov-report term
```
