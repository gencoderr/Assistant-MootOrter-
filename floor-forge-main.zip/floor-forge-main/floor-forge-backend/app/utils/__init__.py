#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Utility functions for the FloorForge API.
"""

# This file marks utils/ as a Python package.