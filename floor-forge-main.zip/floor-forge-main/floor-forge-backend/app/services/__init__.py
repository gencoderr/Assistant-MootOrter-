#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Services package for business logic in the FloorForge API.
"""

# This file marks services/ as a Python package.