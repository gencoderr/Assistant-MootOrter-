/* eslint-disable no-undef */
pref("__prefsPrefix__.duplicate.default.action", "ask");
pref("__prefsPrefix__.bulk.master.item", "oldest");
pref("__prefsPrefix__.duplicate.stats.enable", true);
