#include "systime.h"

volatile uint32_t g_sysTime = 0;
