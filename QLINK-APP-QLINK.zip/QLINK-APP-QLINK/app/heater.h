#pragma once

#include "cl_common.h"

void Heater_Init(void);
void Heater_Process(void);
void Heater_SetWork(bool w);
