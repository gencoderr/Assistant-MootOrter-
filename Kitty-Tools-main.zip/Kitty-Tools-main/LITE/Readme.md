<div align=center>

#  `Kitty-Tools LITE v1.10`

<div align="left">

# How to use

* INSTALL TERMUX ON YOUR ANDROID PHONE
* Install python: `pkg install python`
* Install git: `pkg install git`
* clone the repo: `git clone https://github.com/CPScript/Kitty-Tools`
* Go to `LITE`'s dir: `cd Kitty-Tools/LITE`
* Run script: `python lite.py`

---

> This version of `Kitty-Tools` is ment to be ran on Android!

---

<p align="center">
  &copy; 2025 Kitty Tools LITE. All rights reserved.
  | BETA v1.10
</p>
