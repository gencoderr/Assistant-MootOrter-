# History Common Crate

This crate contains the common code for the ic-history service, it
matches implementations of the protocol specification. And contains
the implementation of common data structures mentioned in the spec.
