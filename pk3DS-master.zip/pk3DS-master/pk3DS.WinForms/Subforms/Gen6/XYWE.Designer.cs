﻿namespace pk3DS.WinForms;

partial class XYWE
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.TabControl_EncounterData = new System.Windows.Forms.TabControl();
        this.TabPage_Land = new System.Windows.Forms.TabPage();
        this.label107 = new System.Windows.Forms.Label();
        this.label115 = new System.Windows.Forms.Label();
        this.label108 = new System.Windows.Forms.Label();
        this.NUP_RockSmashMax5 = new System.Windows.Forms.NumericUpDown();
        this.label109 = new System.Windows.Forms.Label();
        this.NUP_RockSmashMin5 = new System.Windows.Forms.NumericUpDown();
        this.label110 = new System.Windows.Forms.Label();
        this.NUP_RockSmashForme5 = new System.Windows.Forms.NumericUpDown();
        this.label111 = new System.Windows.Forms.Label();
        this.CB_RockSmash5 = new System.Windows.Forms.ComboBox();
        this.CB_RockSmash1 = new System.Windows.Forms.ComboBox();
        this.NUP_RockSmashMax4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RockSmashForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RockSmashMin4 = new System.Windows.Forms.NumericUpDown();
        this.label112 = new System.Windows.Forms.Label();
        this.NUP_RockSmashForme4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RockSmashMin1 = new System.Windows.Forms.NumericUpDown();
        this.CB_RockSmash4 = new System.Windows.Forms.ComboBox();
        this.label113 = new System.Windows.Forms.Label();
        this.NUP_RockSmashMax3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RockSmashMax1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RockSmashMin3 = new System.Windows.Forms.NumericUpDown();
        this.label114 = new System.Windows.Forms.Label();
        this.NUP_RockSmashForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_RockSmash2 = new System.Windows.Forms.ComboBox();
        this.CB_RockSmash3 = new System.Windows.Forms.ComboBox();
        this.NUP_RockSmashMax2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RockSmashForme2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RockSmashMin2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTMin1 = new System.Windows.Forms.NumericUpDown();
        this.label6 = new System.Windows.Forms.Label();
        this.NUP_RTMax1 = new System.Windows.Forms.NumericUpDown();
        this.label7 = new System.Windows.Forms.Label();
        this.NUP_RTForme2 = new System.Windows.Forms.NumericUpDown();
        this.label8 = new System.Windows.Forms.Label();
        this.NUP_RTMin2 = new System.Windows.Forms.NumericUpDown();
        this.label9 = new System.Windows.Forms.Label();
        this.NUP_RTMax2 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT12 = new System.Windows.Forms.ComboBox();
        this.NUP_RTForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT11 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMin3 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT10 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMax3 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT9 = new System.Windows.Forms.ComboBox();
        this.NUP_RTForme4 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT8 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMin4 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT7 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMax4 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT6 = new System.Windows.Forms.ComboBox();
        this.NUP_RTForme5 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT5 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMin5 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT4 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMax5 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT3 = new System.Windows.Forms.ComboBox();
        this.NUP_RTForme6 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT2 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMin6 = new System.Windows.Forms.NumericUpDown();
        this.CB_RT1 = new System.Windows.Forms.ComboBox();
        this.NUP_RTMax6 = new System.Windows.Forms.NumericUpDown();
        this.label10 = new System.Windows.Forms.Label();
        this.NUP_RTForme7 = new System.Windows.Forms.NumericUpDown();
        this.label11 = new System.Windows.Forms.Label();
        this.NUP_RTMin7 = new System.Windows.Forms.NumericUpDown();
        this.label12 = new System.Windows.Forms.Label();
        this.NUP_RTMax7 = new System.Windows.Forms.NumericUpDown();
        this.label13 = new System.Windows.Forms.Label();
        this.NUP_RTForme8 = new System.Windows.Forms.NumericUpDown();
        this.label14 = new System.Windows.Forms.Label();
        this.NUP_RTMin8 = new System.Windows.Forms.NumericUpDown();
        this.label15 = new System.Windows.Forms.Label();
        this.NUP_RTMax8 = new System.Windows.Forms.NumericUpDown();
        this.label16 = new System.Windows.Forms.Label();
        this.NUP_RTForme9 = new System.Windows.Forms.NumericUpDown();
        this.label17 = new System.Windows.Forms.Label();
        this.NUP_RTMin9 = new System.Windows.Forms.NumericUpDown();
        this.label18 = new System.Windows.Forms.Label();
        this.NUP_RTMax9 = new System.Windows.Forms.NumericUpDown();
        this.label19 = new System.Windows.Forms.Label();
        this.NUP_RTForme10 = new System.Windows.Forms.NumericUpDown();
        this.label20 = new System.Windows.Forms.Label();
        this.NUP_RTMin10 = new System.Windows.Forms.NumericUpDown();
        this.label21 = new System.Windows.Forms.Label();
        this.NUP_RTMax10 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTForme11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTMin11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTMax11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTForme12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTMin12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RTMax12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassMin1 = new System.Windows.Forms.NumericUpDown();
        this.label3 = new System.Windows.Forms.Label();
        this.NUP_GrassMax1 = new System.Windows.Forms.NumericUpDown();
        this.label4 = new System.Windows.Forms.Label();
        this.NUP_GrassForme2 = new System.Windows.Forms.NumericUpDown();
        this.label5 = new System.Windows.Forms.Label();
        this.NUP_GrassMin2 = new System.Windows.Forms.NumericUpDown();
        this.label2 = new System.Windows.Forms.Label();
        this.NUP_GrassMax2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass12 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass11 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMin3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass10 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMax3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass9 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassForme4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass8 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMin4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass7 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMax4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass6 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassForme5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass5 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMin5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass4 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMax5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass3 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassForme6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass2 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMin6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Grass1 = new System.Windows.Forms.ComboBox();
        this.NUP_GrassMax6 = new System.Windows.Forms.NumericUpDown();
        this.label31 = new System.Windows.Forms.Label();
        this.NUP_GrassForme7 = new System.Windows.Forms.NumericUpDown();
        this.label41 = new System.Windows.Forms.Label();
        this.NUP_GrassMin7 = new System.Windows.Forms.NumericUpDown();
        this.label42 = new System.Windows.Forms.Label();
        this.NUP_GrassMax7 = new System.Windows.Forms.NumericUpDown();
        this.label40 = new System.Windows.Forms.Label();
        this.NUP_GrassForme8 = new System.Windows.Forms.NumericUpDown();
        this.label39 = new System.Windows.Forms.Label();
        this.NUP_GrassMin8 = new System.Windows.Forms.NumericUpDown();
        this.label38 = new System.Windows.Forms.Label();
        this.NUP_GrassMax8 = new System.Windows.Forms.NumericUpDown();
        this.label37 = new System.Windows.Forms.Label();
        this.NUP_GrassForme9 = new System.Windows.Forms.NumericUpDown();
        this.label36 = new System.Windows.Forms.Label();
        this.NUP_GrassMin9 = new System.Windows.Forms.NumericUpDown();
        this.label35 = new System.Windows.Forms.Label();
        this.NUP_GrassMax9 = new System.Windows.Forms.NumericUpDown();
        this.label34 = new System.Windows.Forms.Label();
        this.NUP_GrassForme10 = new System.Windows.Forms.NumericUpDown();
        this.label33 = new System.Windows.Forms.Label();
        this.NUP_GrassMin10 = new System.Windows.Forms.NumericUpDown();
        this.label32 = new System.Windows.Forms.Label();
        this.NUP_GrassMax10 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassMax12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassForme11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassMin12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassMin11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassForme12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GrassMax11 = new System.Windows.Forms.NumericUpDown();
        this.TabPage_Water = new System.Windows.Forms.TabPage();
        this.label116 = new System.Windows.Forms.Label();
        this.label117 = new System.Windows.Forms.Label();
        this.label118 = new System.Windows.Forms.Label();
        this.label119 = new System.Windows.Forms.Label();
        this.label120 = new System.Windows.Forms.Label();
        this.label103 = new System.Windows.Forms.Label();
        this.label48 = new System.Windows.Forms.Label();
        this.label104 = new System.Windows.Forms.Label();
        this.CB_Super1 = new System.Windows.Forms.ComboBox();
        this.label105 = new System.Windows.Forms.Label();
        this.NUP_SuperForme1 = new System.Windows.Forms.NumericUpDown();
        this.label106 = new System.Windows.Forms.Label();
        this.CB_Surf1 = new System.Windows.Forms.ComboBox();
        this.NUP_SuperMin1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SurfForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SuperMax1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SurfMin1 = new System.Windows.Forms.NumericUpDown();
        this.CB_Super2 = new System.Windows.Forms.ComboBox();
        this.NUP_SurfMax1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SuperForme2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Surf2 = new System.Windows.Forms.ComboBox();
        this.NUP_SuperMin2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SurfForme2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SuperMax2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SurfMin2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Super3 = new System.Windows.Forms.ComboBox();
        this.NUP_SurfMax5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SuperForme3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SurfMax2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SuperMin3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SurfMin5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SuperMax3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Surf3 = new System.Windows.Forms.ComboBox();
        this.label49 = new System.Windows.Forms.Label();
        this.NUP_SurfForme5 = new System.Windows.Forms.NumericUpDown();
        this.label98 = new System.Windows.Forms.Label();
        this.NUP_SurfForme3 = new System.Windows.Forms.NumericUpDown();
        this.label99 = new System.Windows.Forms.Label();
        this.CB_Surf5 = new System.Windows.Forms.ComboBox();
        this.label100 = new System.Windows.Forms.Label();
        this.NUP_SurfMin3 = new System.Windows.Forms.NumericUpDown();
        this.label101 = new System.Windows.Forms.Label();
        this.NUP_SurfMax4 = new System.Windows.Forms.NumericUpDown();
        this.label102 = new System.Windows.Forms.Label();
        this.NUP_SurfMax3 = new System.Windows.Forms.NumericUpDown();
        this.label26 = new System.Windows.Forms.Label();
        this.NUP_SurfMin4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Good1 = new System.Windows.Forms.ComboBox();
        this.CB_Surf4 = new System.Windows.Forms.ComboBox();
        this.NUP_GoodForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_SurfForme4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GoodMin1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GoodMax1 = new System.Windows.Forms.NumericUpDown();
        this.CB_Good2 = new System.Windows.Forms.ComboBox();
        this.NUP_GoodForme2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GoodMin2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GoodMax2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Good3 = new System.Windows.Forms.ComboBox();
        this.NUP_GoodForme3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GoodMin3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_GoodMax3 = new System.Windows.Forms.NumericUpDown();
        this.label27 = new System.Windows.Forms.Label();
        this.label28 = new System.Windows.Forms.Label();
        this.label29 = new System.Windows.Forms.Label();
        this.label30 = new System.Windows.Forms.Label();
        this.label46 = new System.Windows.Forms.Label();
        this.label47 = new System.Windows.Forms.Label();
        this.label22 = new System.Windows.Forms.Label();
        this.CB_Old1 = new System.Windows.Forms.ComboBox();
        this.NUP_OldForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_OldMin1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_OldMax1 = new System.Windows.Forms.NumericUpDown();
        this.CB_Old2 = new System.Windows.Forms.ComboBox();
        this.NUP_OldForme2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_OldMin2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_OldMax2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Old3 = new System.Windows.Forms.ComboBox();
        this.NUP_OldForme3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_OldMin3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_OldMax3 = new System.Windows.Forms.NumericUpDown();
        this.label45 = new System.Windows.Forms.Label();
        this.label44 = new System.Windows.Forms.Label();
        this.label43 = new System.Windows.Forms.Label();
        this.label23 = new System.Windows.Forms.Label();
        this.label24 = new System.Windows.Forms.Label();
        this.label25 = new System.Windows.Forms.Label();
        this.TabPage_Horde = new System.Windows.Forms.TabPage();
        this.GB_Tweak = new System.Windows.Forms.GroupBox();
        this.CHK_HomogeneousHordes = new System.Windows.Forms.CheckBox();
        this.CHK_MegaForm = new System.Windows.Forms.CheckBox();
        this.L_RandOpt = new System.Windows.Forms.Label();
        this.CHK_BST = new System.Windows.Forms.CheckBox();
        this.CHK_E = new System.Windows.Forms.CheckBox();
        this.CHK_L = new System.Windows.Forms.CheckBox();
        this.CHK_G6 = new System.Windows.Forms.CheckBox();
        this.CHK_G5 = new System.Windows.Forms.CheckBox();
        this.CHK_G4 = new System.Windows.Forms.CheckBox();
        this.CHK_G3 = new System.Windows.Forms.CheckBox();
        this.CHK_G2 = new System.Windows.Forms.CheckBox();
        this.CHK_G1 = new System.Windows.Forms.CheckBox();
        this.B_LevelPlus = new System.Windows.Forms.Button();
        this.NUD_LevelAmp = new System.Windows.Forms.NumericUpDown();
        this.CHK_Level = new System.Windows.Forms.CheckBox();
        this.label129 = new System.Windows.Forms.Label();
        this.label130 = new System.Windows.Forms.Label();
        this.label131 = new System.Windows.Forms.Label();
        this.label132 = new System.Windows.Forms.Label();
        this.NUP_HordeCMax5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCMin5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCForme5 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeC5 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeCMax4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCMin4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCForme4 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeC4 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeCMax3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCMin3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeC3 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeCMax2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCMin2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCForme2 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeC2 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeCMax1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCMin1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeCForme1 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeC1 = new System.Windows.Forms.ComboBox();
        this.label125 = new System.Windows.Forms.Label();
        this.label121 = new System.Windows.Forms.Label();
        this.label126 = new System.Windows.Forms.Label();
        this.label124 = new System.Windows.Forms.Label();
        this.label127 = new System.Windows.Forms.Label();
        this.label122 = new System.Windows.Forms.Label();
        this.label128 = new System.Windows.Forms.Label();
        this.NUP_HordeBMax5 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeA1 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeBMin5 = new System.Windows.Forms.NumericUpDown();
        this.label123 = new System.Windows.Forms.Label();
        this.NUP_HordeBForme5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAForme1 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeB5 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeAMin1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBMax4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAMax5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBMin4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAMax1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBForme4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAMin5 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeB4 = new System.Windows.Forms.ComboBox();
        this.CB_HordeA2 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeBMax3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAForme5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBMin3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAForme2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeA5 = new System.Windows.Forms.ComboBox();
        this.CB_HordeB3 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeAMin2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBMax2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAMax4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBMin2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAMax2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBForme2 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAMin4 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeB2 = new System.Windows.Forms.ComboBox();
        this.CB_HordeA3 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeBMax1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAForme4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBMin1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAForme3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeBForme1 = new System.Windows.Forms.NumericUpDown();
        this.CB_HordeA4 = new System.Windows.Forms.ComboBox();
        this.CB_HordeB1 = new System.Windows.Forms.ComboBox();
        this.NUP_HordeAMin3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_HordeAMax3 = new System.Windows.Forms.NumericUpDown();
        this.tabPage1 = new System.Windows.Forms.TabPage();
        this.NUP_RedForme11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RedMin11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RedMax11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RedForme12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RedMin12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RedMax12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleForme11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleMin11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleMax11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleForme12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleMin12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleMax12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowForme11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowMin11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowMax11 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowForme12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowMin12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowMax12 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RedForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_RedMin1 = new System.Windows.Forms.NumericUpDown();
        this.label82 = new System.Windows.Forms.Label();
        this.NUP_RedMax1 = new System.Windows.Forms.NumericUpDown();
        this.label83 = new System.Windows.Forms.Label();
        this.NUP_RedForme2 = new System.Windows.Forms.NumericUpDown();
        this.label84 = new System.Windows.Forms.Label();
        this.NUP_RedMin2 = new System.Windows.Forms.NumericUpDown();
        this.label85 = new System.Windows.Forms.Label();
        this.NUP_RedMax2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple12 = new System.Windows.Forms.ComboBox();
        this.NUP_RedForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple11 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMin3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple10 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMax3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple9 = new System.Windows.Forms.ComboBox();
        this.NUP_RedForme4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple8 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMin4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple7 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMax4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple6 = new System.Windows.Forms.ComboBox();
        this.NUP_RedForme5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple5 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMin5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple4 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMax5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple3 = new System.Windows.Forms.ComboBox();
        this.NUP_RedForme6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple2 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMin6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Purple1 = new System.Windows.Forms.ComboBox();
        this.NUP_RedMax6 = new System.Windows.Forms.NumericUpDown();
        this.label86 = new System.Windows.Forms.Label();
        this.NUP_RedForme7 = new System.Windows.Forms.NumericUpDown();
        this.label87 = new System.Windows.Forms.Label();
        this.NUP_RedMin7 = new System.Windows.Forms.NumericUpDown();
        this.label88 = new System.Windows.Forms.Label();
        this.NUP_RedMax7 = new System.Windows.Forms.NumericUpDown();
        this.label89 = new System.Windows.Forms.Label();
        this.NUP_RedForme8 = new System.Windows.Forms.NumericUpDown();
        this.label90 = new System.Windows.Forms.Label();
        this.NUP_RedMin8 = new System.Windows.Forms.NumericUpDown();
        this.label91 = new System.Windows.Forms.Label();
        this.NUP_RedMax8 = new System.Windows.Forms.NumericUpDown();
        this.label92 = new System.Windows.Forms.Label();
        this.NUP_RedForme9 = new System.Windows.Forms.NumericUpDown();
        this.label93 = new System.Windows.Forms.Label();
        this.NUP_RedMin9 = new System.Windows.Forms.NumericUpDown();
        this.label94 = new System.Windows.Forms.Label();
        this.NUP_RedMax9 = new System.Windows.Forms.NumericUpDown();
        this.label95 = new System.Windows.Forms.Label();
        this.NUP_RedForme10 = new System.Windows.Forms.NumericUpDown();
        this.label96 = new System.Windows.Forms.Label();
        this.NUP_RedMin10 = new System.Windows.Forms.NumericUpDown();
        this.label97 = new System.Windows.Forms.Label();
        this.NUP_RedMax10 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_PurpleMin1 = new System.Windows.Forms.NumericUpDown();
        this.label66 = new System.Windows.Forms.Label();
        this.NUP_PurpleMax1 = new System.Windows.Forms.NumericUpDown();
        this.label67 = new System.Windows.Forms.Label();
        this.NUP_PurpleForme2 = new System.Windows.Forms.NumericUpDown();
        this.label68 = new System.Windows.Forms.Label();
        this.NUP_PurpleMin2 = new System.Windows.Forms.NumericUpDown();
        this.label69 = new System.Windows.Forms.Label();
        this.NUP_PurpleMax2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red12 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red11 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMin3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red10 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMax3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red9 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleForme4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red8 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMin4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red7 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMax4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red6 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleForme5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red5 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMin5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red4 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMax5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red3 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleForme6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red2 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMin6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Red1 = new System.Windows.Forms.ComboBox();
        this.NUP_PurpleMax6 = new System.Windows.Forms.NumericUpDown();
        this.label70 = new System.Windows.Forms.Label();
        this.NUP_PurpleForme7 = new System.Windows.Forms.NumericUpDown();
        this.label71 = new System.Windows.Forms.Label();
        this.NUP_PurpleMin7 = new System.Windows.Forms.NumericUpDown();
        this.label72 = new System.Windows.Forms.Label();
        this.NUP_PurpleMax7 = new System.Windows.Forms.NumericUpDown();
        this.label73 = new System.Windows.Forms.Label();
        this.NUP_PurpleForme8 = new System.Windows.Forms.NumericUpDown();
        this.label74 = new System.Windows.Forms.Label();
        this.NUP_PurpleMin8 = new System.Windows.Forms.NumericUpDown();
        this.label75 = new System.Windows.Forms.Label();
        this.NUP_PurpleMax8 = new System.Windows.Forms.NumericUpDown();
        this.label76 = new System.Windows.Forms.Label();
        this.NUP_PurpleForme9 = new System.Windows.Forms.NumericUpDown();
        this.label77 = new System.Windows.Forms.Label();
        this.NUP_PurpleMin9 = new System.Windows.Forms.NumericUpDown();
        this.label78 = new System.Windows.Forms.Label();
        this.NUP_PurpleMax9 = new System.Windows.Forms.NumericUpDown();
        this.label79 = new System.Windows.Forms.Label();
        this.NUP_PurpleForme10 = new System.Windows.Forms.NumericUpDown();
        this.label80 = new System.Windows.Forms.Label();
        this.NUP_PurpleMin10 = new System.Windows.Forms.NumericUpDown();
        this.label81 = new System.Windows.Forms.Label();
        this.NUP_PurpleMax10 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowForme1 = new System.Windows.Forms.NumericUpDown();
        this.NUP_YellowMin1 = new System.Windows.Forms.NumericUpDown();
        this.label50 = new System.Windows.Forms.Label();
        this.NUP_YellowMax1 = new System.Windows.Forms.NumericUpDown();
        this.label51 = new System.Windows.Forms.Label();
        this.NUP_YellowForme2 = new System.Windows.Forms.NumericUpDown();
        this.label52 = new System.Windows.Forms.Label();
        this.NUP_YellowMin2 = new System.Windows.Forms.NumericUpDown();
        this.label53 = new System.Windows.Forms.Label();
        this.NUP_YellowMax2 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow12 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow11 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMin3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow10 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMax3 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow9 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowForme4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow8 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMin4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow7 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMax4 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow6 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowForme5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow5 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMin5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow4 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMax5 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow3 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowForme6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow2 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMin6 = new System.Windows.Forms.NumericUpDown();
        this.CB_Yellow1 = new System.Windows.Forms.ComboBox();
        this.NUP_YellowMax6 = new System.Windows.Forms.NumericUpDown();
        this.label54 = new System.Windows.Forms.Label();
        this.NUP_YellowForme7 = new System.Windows.Forms.NumericUpDown();
        this.label55 = new System.Windows.Forms.Label();
        this.NUP_YellowMin7 = new System.Windows.Forms.NumericUpDown();
        this.label56 = new System.Windows.Forms.Label();
        this.NUP_YellowMax7 = new System.Windows.Forms.NumericUpDown();
        this.label57 = new System.Windows.Forms.Label();
        this.NUP_YellowForme8 = new System.Windows.Forms.NumericUpDown();
        this.label58 = new System.Windows.Forms.Label();
        this.NUP_YellowMin8 = new System.Windows.Forms.NumericUpDown();
        this.label59 = new System.Windows.Forms.Label();
        this.NUP_YellowMax8 = new System.Windows.Forms.NumericUpDown();
        this.label60 = new System.Windows.Forms.Label();
        this.NUP_YellowForme9 = new System.Windows.Forms.NumericUpDown();
        this.label61 = new System.Windows.Forms.Label();
        this.NUP_YellowMin9 = new System.Windows.Forms.NumericUpDown();
        this.label62 = new System.Windows.Forms.Label();
        this.NUP_YellowMax9 = new System.Windows.Forms.NumericUpDown();
        this.label63 = new System.Windows.Forms.Label();
        this.NUP_YellowForme10 = new System.Windows.Forms.NumericUpDown();
        this.label64 = new System.Windows.Forms.Label();
        this.NUP_YellowMin10 = new System.Windows.Forms.NumericUpDown();
        this.label65 = new System.Windows.Forms.Label();
        this.NUP_YellowMax10 = new System.Windows.Forms.NumericUpDown();
        this.CB_LocationID = new System.Windows.Forms.ComboBox();
        this.B_Save = new System.Windows.Forms.Button();
        this.label134 = new System.Windows.Forms.Label();
        this.label136 = new System.Windows.Forms.Label();
        this.CB_FormeList = new System.Windows.Forms.ComboBox();
        this.B_Randomize = new System.Windows.Forms.Button();
        this.B_Dump = new System.Windows.Forms.Button();
        this.TabControl_EncounterData.SuspendLayout();
        this.TabPage_Land.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax11)).BeginInit();
        this.TabPage_Water.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMax3)).BeginInit();
        this.TabPage_Horde.SuspendLayout();
        this.GB_Tweak.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_LevelAmp)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax3)).BeginInit();
        this.tabPage1.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax10)).BeginInit();
        this.SuspendLayout();
        // 
        // TabControl_EncounterData
        // 
        this.TabControl_EncounterData.Controls.Add(this.TabPage_Land);
        this.TabControl_EncounterData.Controls.Add(this.TabPage_Water);
        this.TabControl_EncounterData.Controls.Add(this.TabPage_Horde);
        this.TabControl_EncounterData.Controls.Add(this.tabPage1);
        this.TabControl_EncounterData.Location = new System.Drawing.Point(12, 12);
        this.TabControl_EncounterData.Name = "TabControl_EncounterData";
        this.TabControl_EncounterData.SelectedIndex = 0;
        this.TabControl_EncounterData.Size = new System.Drawing.Size(926, 395);
        this.TabControl_EncounterData.TabIndex = 2;
        // 
        // TabPage_Land
        // 
        this.TabPage_Land.Controls.Add(this.label107);
        this.TabPage_Land.Controls.Add(this.label115);
        this.TabPage_Land.Controls.Add(this.label108);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMax5);
        this.TabPage_Land.Controls.Add(this.label109);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMin5);
        this.TabPage_Land.Controls.Add(this.label110);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashForme5);
        this.TabPage_Land.Controls.Add(this.label111);
        this.TabPage_Land.Controls.Add(this.CB_RockSmash5);
        this.TabPage_Land.Controls.Add(this.CB_RockSmash1);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMax4);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashForme1);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMin4);
        this.TabPage_Land.Controls.Add(this.label112);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashForme4);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMin1);
        this.TabPage_Land.Controls.Add(this.CB_RockSmash4);
        this.TabPage_Land.Controls.Add(this.label113);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMax3);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMax1);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMin3);
        this.TabPage_Land.Controls.Add(this.label114);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashForme3);
        this.TabPage_Land.Controls.Add(this.CB_RockSmash2);
        this.TabPage_Land.Controls.Add(this.CB_RockSmash3);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMax2);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashForme2);
        this.TabPage_Land.Controls.Add(this.NUP_RockSmashMin2);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme1);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin1);
        this.TabPage_Land.Controls.Add(this.label6);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax1);
        this.TabPage_Land.Controls.Add(this.label7);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme2);
        this.TabPage_Land.Controls.Add(this.label8);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin2);
        this.TabPage_Land.Controls.Add(this.label9);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax2);
        this.TabPage_Land.Controls.Add(this.CB_RT12);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme3);
        this.TabPage_Land.Controls.Add(this.CB_RT11);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin3);
        this.TabPage_Land.Controls.Add(this.CB_RT10);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax3);
        this.TabPage_Land.Controls.Add(this.CB_RT9);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme4);
        this.TabPage_Land.Controls.Add(this.CB_RT8);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin4);
        this.TabPage_Land.Controls.Add(this.CB_RT7);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax4);
        this.TabPage_Land.Controls.Add(this.CB_RT6);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme5);
        this.TabPage_Land.Controls.Add(this.CB_RT5);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin5);
        this.TabPage_Land.Controls.Add(this.CB_RT4);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax5);
        this.TabPage_Land.Controls.Add(this.CB_RT3);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme6);
        this.TabPage_Land.Controls.Add(this.CB_RT2);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin6);
        this.TabPage_Land.Controls.Add(this.CB_RT1);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax6);
        this.TabPage_Land.Controls.Add(this.label10);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme7);
        this.TabPage_Land.Controls.Add(this.label11);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin7);
        this.TabPage_Land.Controls.Add(this.label12);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax7);
        this.TabPage_Land.Controls.Add(this.label13);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme8);
        this.TabPage_Land.Controls.Add(this.label14);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin8);
        this.TabPage_Land.Controls.Add(this.label15);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax8);
        this.TabPage_Land.Controls.Add(this.label16);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme9);
        this.TabPage_Land.Controls.Add(this.label17);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin9);
        this.TabPage_Land.Controls.Add(this.label18);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax9);
        this.TabPage_Land.Controls.Add(this.label19);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme10);
        this.TabPage_Land.Controls.Add(this.label20);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin10);
        this.TabPage_Land.Controls.Add(this.label21);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax10);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme11);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin11);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax11);
        this.TabPage_Land.Controls.Add(this.NUP_RTForme12);
        this.TabPage_Land.Controls.Add(this.NUP_RTMin12);
        this.TabPage_Land.Controls.Add(this.NUP_RTMax12);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme1);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin1);
        this.TabPage_Land.Controls.Add(this.label3);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax1);
        this.TabPage_Land.Controls.Add(this.label4);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme2);
        this.TabPage_Land.Controls.Add(this.label5);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin2);
        this.TabPage_Land.Controls.Add(this.label2);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax2);
        this.TabPage_Land.Controls.Add(this.CB_Grass12);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme3);
        this.TabPage_Land.Controls.Add(this.CB_Grass11);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin3);
        this.TabPage_Land.Controls.Add(this.CB_Grass10);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax3);
        this.TabPage_Land.Controls.Add(this.CB_Grass9);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme4);
        this.TabPage_Land.Controls.Add(this.CB_Grass8);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin4);
        this.TabPage_Land.Controls.Add(this.CB_Grass7);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax4);
        this.TabPage_Land.Controls.Add(this.CB_Grass6);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme5);
        this.TabPage_Land.Controls.Add(this.CB_Grass5);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin5);
        this.TabPage_Land.Controls.Add(this.CB_Grass4);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax5);
        this.TabPage_Land.Controls.Add(this.CB_Grass3);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme6);
        this.TabPage_Land.Controls.Add(this.CB_Grass2);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin6);
        this.TabPage_Land.Controls.Add(this.CB_Grass1);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax6);
        this.TabPage_Land.Controls.Add(this.label31);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme7);
        this.TabPage_Land.Controls.Add(this.label41);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin7);
        this.TabPage_Land.Controls.Add(this.label42);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax7);
        this.TabPage_Land.Controls.Add(this.label40);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme8);
        this.TabPage_Land.Controls.Add(this.label39);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin8);
        this.TabPage_Land.Controls.Add(this.label38);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax8);
        this.TabPage_Land.Controls.Add(this.label37);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme9);
        this.TabPage_Land.Controls.Add(this.label36);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin9);
        this.TabPage_Land.Controls.Add(this.label35);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax9);
        this.TabPage_Land.Controls.Add(this.label34);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme10);
        this.TabPage_Land.Controls.Add(this.label33);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin10);
        this.TabPage_Land.Controls.Add(this.label32);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax10);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax12);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme11);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin12);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMin11);
        this.TabPage_Land.Controls.Add(this.NUP_GrassForme12);
        this.TabPage_Land.Controls.Add(this.NUP_GrassMax11);
        this.TabPage_Land.Location = new System.Drawing.Point(4, 22);
        this.TabPage_Land.Name = "TabPage_Land";
        this.TabPage_Land.Padding = new System.Windows.Forms.Padding(3);
        this.TabPage_Land.Size = new System.Drawing.Size(918, 369);
        this.TabPage_Land.TabIndex = 0;
        this.TabPage_Land.Text = "Land";
        this.TabPage_Land.UseVisualStyleBackColor = true;
        // 
        // label107
        // 
        this.label107.AutoSize = true;
        this.label107.Location = new System.Drawing.Point(619, 147);
        this.label107.Name = "label107";
        this.label107.Size = new System.Drawing.Size(21, 13);
        this.label107.TabIndex = 406;
        this.label107.Text = "1%";
        // 
        // label115
        // 
        this.label115.AutoSize = true;
        this.label115.Location = new System.Drawing.Point(643, 20);
        this.label115.Name = "label115";
        this.label115.Size = new System.Drawing.Size(68, 13);
        this.label115.TabIndex = 398;
        this.label115.Text = "Rock Smash";
        // 
        // label108
        // 
        this.label108.AutoSize = true;
        this.label108.Location = new System.Drawing.Point(619, 120);
        this.label108.Name = "label108";
        this.label108.Size = new System.Drawing.Size(21, 13);
        this.label108.TabIndex = 405;
        this.label108.Text = "4%";
        // 
        // NUP_RockSmashMax5
        // 
        this.NUP_RockSmashMax5.Location = new System.Drawing.Point(867, 145);
        this.NUP_RockSmashMax5.Name = "NUP_RockSmashMax5";
        this.NUP_RockSmashMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMax5.TabIndex = 397;
        // 
        // label109
        // 
        this.label109.AutoSize = true;
        this.label109.Location = new System.Drawing.Point(614, 93);
        this.label109.Name = "label109";
        this.label109.Size = new System.Drawing.Size(27, 13);
        this.label109.TabIndex = 404;
        this.label109.Text = "15%";
        // 
        // NUP_RockSmashMin5
        // 
        this.NUP_RockSmashMin5.Location = new System.Drawing.Point(820, 145);
        this.NUP_RockSmashMin5.Name = "NUP_RockSmashMin5";
        this.NUP_RockSmashMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMin5.TabIndex = 396;
        // 
        // label110
        // 
        this.label110.AutoSize = true;
        this.label110.Location = new System.Drawing.Point(613, 66);
        this.label110.Name = "label110";
        this.label110.Size = new System.Drawing.Size(27, 13);
        this.label110.TabIndex = 403;
        this.label110.Text = "30%";
        // 
        // NUP_RockSmashForme5
        // 
        this.NUP_RockSmashForme5.Location = new System.Drawing.Point(773, 145);
        this.NUP_RockSmashForme5.Name = "NUP_RockSmashForme5";
        this.NUP_RockSmashForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashForme5.TabIndex = 395;
        // 
        // label111
        // 
        this.label111.AutoSize = true;
        this.label111.Location = new System.Drawing.Point(613, 39);
        this.label111.Name = "label111";
        this.label111.Size = new System.Drawing.Size(27, 13);
        this.label111.TabIndex = 402;
        this.label111.Text = "50%";
        // 
        // CB_RockSmash5
        // 
        this.CB_RockSmash5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_RockSmash5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_RockSmash5.FormattingEnabled = true;
        this.CB_RockSmash5.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_RockSmash5.Location = new System.Drawing.Point(646, 144);
        this.CB_RockSmash5.Name = "CB_RockSmash5";
        this.CB_RockSmash5.Size = new System.Drawing.Size(121, 21);
        this.CB_RockSmash5.TabIndex = 394;
        // 
        // CB_RockSmash1
        // 
        this.CB_RockSmash1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_RockSmash1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_RockSmash1.FormattingEnabled = true;
        this.CB_RockSmash1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_RockSmash1.Location = new System.Drawing.Point(646, 36);
        this.CB_RockSmash1.Name = "CB_RockSmash1";
        this.CB_RockSmash1.Size = new System.Drawing.Size(121, 21);
        this.CB_RockSmash1.TabIndex = 378;
        // 
        // NUP_RockSmashMax4
        // 
        this.NUP_RockSmashMax4.Location = new System.Drawing.Point(867, 118);
        this.NUP_RockSmashMax4.Name = "NUP_RockSmashMax4";
        this.NUP_RockSmashMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMax4.TabIndex = 393;
        // 
        // NUP_RockSmashForme1
        // 
        this.NUP_RockSmashForme1.Location = new System.Drawing.Point(773, 37);
        this.NUP_RockSmashForme1.Name = "NUP_RockSmashForme1";
        this.NUP_RockSmashForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashForme1.TabIndex = 379;
        // 
        // NUP_RockSmashMin4
        // 
        this.NUP_RockSmashMin4.Location = new System.Drawing.Point(820, 118);
        this.NUP_RockSmashMin4.Name = "NUP_RockSmashMin4";
        this.NUP_RockSmashMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMin4.TabIndex = 392;
        // 
        // label112
        // 
        this.label112.AutoSize = true;
        this.label112.Location = new System.Drawing.Point(864, 20);
        this.label112.Name = "label112";
        this.label112.Size = new System.Drawing.Size(27, 13);
        this.label112.TabIndex = 401;
        this.label112.Text = "Max";
        // 
        // NUP_RockSmashForme4
        // 
        this.NUP_RockSmashForme4.Location = new System.Drawing.Point(773, 118);
        this.NUP_RockSmashForme4.Name = "NUP_RockSmashForme4";
        this.NUP_RockSmashForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashForme4.TabIndex = 391;
        // 
        // NUP_RockSmashMin1
        // 
        this.NUP_RockSmashMin1.Location = new System.Drawing.Point(820, 37);
        this.NUP_RockSmashMin1.Name = "NUP_RockSmashMin1";
        this.NUP_RockSmashMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMin1.TabIndex = 380;
        // 
        // CB_RockSmash4
        // 
        this.CB_RockSmash4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_RockSmash4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_RockSmash4.FormattingEnabled = true;
        this.CB_RockSmash4.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_RockSmash4.Location = new System.Drawing.Point(646, 117);
        this.CB_RockSmash4.Name = "CB_RockSmash4";
        this.CB_RockSmash4.Size = new System.Drawing.Size(121, 21);
        this.CB_RockSmash4.TabIndex = 390;
        // 
        // label113
        // 
        this.label113.AutoSize = true;
        this.label113.Location = new System.Drawing.Point(817, 21);
        this.label113.Name = "label113";
        this.label113.Size = new System.Drawing.Size(24, 13);
        this.label113.TabIndex = 400;
        this.label113.Text = "Min";
        // 
        // NUP_RockSmashMax3
        // 
        this.NUP_RockSmashMax3.Location = new System.Drawing.Point(867, 91);
        this.NUP_RockSmashMax3.Name = "NUP_RockSmashMax3";
        this.NUP_RockSmashMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMax3.TabIndex = 389;
        // 
        // NUP_RockSmashMax1
        // 
        this.NUP_RockSmashMax1.Location = new System.Drawing.Point(867, 37);
        this.NUP_RockSmashMax1.Name = "NUP_RockSmashMax1";
        this.NUP_RockSmashMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMax1.TabIndex = 381;
        // 
        // NUP_RockSmashMin3
        // 
        this.NUP_RockSmashMin3.Location = new System.Drawing.Point(820, 91);
        this.NUP_RockSmashMin3.Name = "NUP_RockSmashMin3";
        this.NUP_RockSmashMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMin3.TabIndex = 388;
        // 
        // label114
        // 
        this.label114.AutoSize = true;
        this.label114.Location = new System.Drawing.Point(770, 21);
        this.label114.Name = "label114";
        this.label114.Size = new System.Drawing.Size(36, 13);
        this.label114.TabIndex = 399;
        this.label114.Text = "Forme";
        // 
        // NUP_RockSmashForme3
        // 
        this.NUP_RockSmashForme3.Location = new System.Drawing.Point(773, 91);
        this.NUP_RockSmashForme3.Name = "NUP_RockSmashForme3";
        this.NUP_RockSmashForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashForme3.TabIndex = 387;
        // 
        // CB_RockSmash2
        // 
        this.CB_RockSmash2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_RockSmash2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_RockSmash2.FormattingEnabled = true;
        this.CB_RockSmash2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_RockSmash2.Location = new System.Drawing.Point(646, 63);
        this.CB_RockSmash2.Name = "CB_RockSmash2";
        this.CB_RockSmash2.Size = new System.Drawing.Size(121, 21);
        this.CB_RockSmash2.TabIndex = 382;
        // 
        // CB_RockSmash3
        // 
        this.CB_RockSmash3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_RockSmash3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_RockSmash3.FormattingEnabled = true;
        this.CB_RockSmash3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_RockSmash3.Location = new System.Drawing.Point(646, 90);
        this.CB_RockSmash3.Name = "CB_RockSmash3";
        this.CB_RockSmash3.Size = new System.Drawing.Size(121, 21);
        this.CB_RockSmash3.TabIndex = 386;
        // 
        // NUP_RockSmashMax2
        // 
        this.NUP_RockSmashMax2.Location = new System.Drawing.Point(867, 64);
        this.NUP_RockSmashMax2.Name = "NUP_RockSmashMax2";
        this.NUP_RockSmashMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMax2.TabIndex = 385;
        // 
        // NUP_RockSmashForme2
        // 
        this.NUP_RockSmashForme2.Location = new System.Drawing.Point(773, 64);
        this.NUP_RockSmashForme2.Name = "NUP_RockSmashForme2";
        this.NUP_RockSmashForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashForme2.TabIndex = 383;
        // 
        // NUP_RockSmashMin2
        // 
        this.NUP_RockSmashMin2.Location = new System.Drawing.Point(820, 64);
        this.NUP_RockSmashMin2.Name = "NUP_RockSmashMin2";
        this.NUP_RockSmashMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RockSmashMin2.TabIndex = 384;
        // 
        // NUP_RTForme1
        // 
        this.NUP_RTForme1.Location = new System.Drawing.Point(470, 36);
        this.NUP_RTForme1.Name = "NUP_RTForme1";
        this.NUP_RTForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme1.TabIndex = 315;
        // 
        // NUP_RTMin1
        // 
        this.NUP_RTMin1.Location = new System.Drawing.Point(517, 36);
        this.NUP_RTMin1.Name = "NUP_RTMin1";
        this.NUP_RTMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin1.TabIndex = 316;
        // 
        // label6
        // 
        this.label6.AutoSize = true;
        this.label6.Location = new System.Drawing.Point(469, 20);
        this.label6.Name = "label6";
        this.label6.Size = new System.Drawing.Size(36, 13);
        this.label6.TabIndex = 375;
        this.label6.Text = "Forme";
        // 
        // NUP_RTMax1
        // 
        this.NUP_RTMax1.Location = new System.Drawing.Point(564, 36);
        this.NUP_RTMax1.Name = "NUP_RTMax1";
        this.NUP_RTMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax1.TabIndex = 317;
        // 
        // label7
        // 
        this.label7.AutoSize = true;
        this.label7.Location = new System.Drawing.Point(516, 20);
        this.label7.Name = "label7";
        this.label7.Size = new System.Drawing.Size(24, 13);
        this.label7.TabIndex = 376;
        this.label7.Text = "Min";
        // 
        // NUP_RTForme2
        // 
        this.NUP_RTForme2.Location = new System.Drawing.Point(470, 63);
        this.NUP_RTForme2.Name = "NUP_RTForme2";
        this.NUP_RTForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme2.TabIndex = 318;
        // 
        // label8
        // 
        this.label8.AutoSize = true;
        this.label8.Location = new System.Drawing.Point(563, 20);
        this.label8.Name = "label8";
        this.label8.Size = new System.Drawing.Size(27, 13);
        this.label8.TabIndex = 377;
        this.label8.Text = "Max";
        // 
        // NUP_RTMin2
        // 
        this.NUP_RTMin2.Location = new System.Drawing.Point(517, 63);
        this.NUP_RTMin2.Name = "NUP_RTMin2";
        this.NUP_RTMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin2.TabIndex = 319;
        // 
        // label9
        // 
        this.label9.AutoSize = true;
        this.label9.Location = new System.Drawing.Point(343, 20);
        this.label9.Name = "label9";
        this.label9.Size = new System.Drawing.Size(75, 13);
        this.label9.TabIndex = 374;
        this.label9.Text = "Rough Terrain";
        // 
        // NUP_RTMax2
        // 
        this.NUP_RTMax2.Location = new System.Drawing.Point(564, 63);
        this.NUP_RTMax2.Name = "NUP_RTMax2";
        this.NUP_RTMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax2.TabIndex = 320;
        // 
        // CB_RT12
        // 
        this.CB_RT12.FormattingEnabled = true;
        this.CB_RT12.Location = new System.Drawing.Point(343, 327);
        this.CB_RT12.Name = "CB_RT12";
        this.CB_RT12.Size = new System.Drawing.Size(121, 21);
        this.CB_RT12.TabIndex = 373;
        // 
        // NUP_RTForme3
        // 
        this.NUP_RTForme3.Location = new System.Drawing.Point(470, 90);
        this.NUP_RTForme3.Name = "NUP_RTForme3";
        this.NUP_RTForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme3.TabIndex = 321;
        // 
        // CB_RT11
        // 
        this.CB_RT11.FormattingEnabled = true;
        this.CB_RT11.Location = new System.Drawing.Point(343, 301);
        this.CB_RT11.Name = "CB_RT11";
        this.CB_RT11.Size = new System.Drawing.Size(121, 21);
        this.CB_RT11.TabIndex = 372;
        // 
        // NUP_RTMin3
        // 
        this.NUP_RTMin3.Location = new System.Drawing.Point(517, 90);
        this.NUP_RTMin3.Name = "NUP_RTMin3";
        this.NUP_RTMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin3.TabIndex = 322;
        // 
        // CB_RT10
        // 
        this.CB_RT10.FormattingEnabled = true;
        this.CB_RT10.Location = new System.Drawing.Point(343, 274);
        this.CB_RT10.Name = "CB_RT10";
        this.CB_RT10.Size = new System.Drawing.Size(121, 21);
        this.CB_RT10.TabIndex = 371;
        // 
        // NUP_RTMax3
        // 
        this.NUP_RTMax3.Location = new System.Drawing.Point(564, 90);
        this.NUP_RTMax3.Name = "NUP_RTMax3";
        this.NUP_RTMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax3.TabIndex = 323;
        // 
        // CB_RT9
        // 
        this.CB_RT9.FormattingEnabled = true;
        this.CB_RT9.Location = new System.Drawing.Point(343, 248);
        this.CB_RT9.Name = "CB_RT9";
        this.CB_RT9.Size = new System.Drawing.Size(121, 21);
        this.CB_RT9.TabIndex = 370;
        // 
        // NUP_RTForme4
        // 
        this.NUP_RTForme4.Location = new System.Drawing.Point(470, 116);
        this.NUP_RTForme4.Name = "NUP_RTForme4";
        this.NUP_RTForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme4.TabIndex = 324;
        // 
        // CB_RT8
        // 
        this.CB_RT8.FormattingEnabled = true;
        this.CB_RT8.Location = new System.Drawing.Point(343, 221);
        this.CB_RT8.Name = "CB_RT8";
        this.CB_RT8.Size = new System.Drawing.Size(121, 21);
        this.CB_RT8.TabIndex = 369;
        // 
        // NUP_RTMin4
        // 
        this.NUP_RTMin4.Location = new System.Drawing.Point(517, 116);
        this.NUP_RTMin4.Name = "NUP_RTMin4";
        this.NUP_RTMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin4.TabIndex = 325;
        // 
        // CB_RT7
        // 
        this.CB_RT7.FormattingEnabled = true;
        this.CB_RT7.Location = new System.Drawing.Point(343, 195);
        this.CB_RT7.Name = "CB_RT7";
        this.CB_RT7.Size = new System.Drawing.Size(121, 21);
        this.CB_RT7.TabIndex = 368;
        // 
        // NUP_RTMax4
        // 
        this.NUP_RTMax4.Location = new System.Drawing.Point(564, 116);
        this.NUP_RTMax4.Name = "NUP_RTMax4";
        this.NUP_RTMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax4.TabIndex = 326;
        // 
        // CB_RT6
        // 
        this.CB_RT6.FormattingEnabled = true;
        this.CB_RT6.Location = new System.Drawing.Point(343, 168);
        this.CB_RT6.Name = "CB_RT6";
        this.CB_RT6.Size = new System.Drawing.Size(121, 21);
        this.CB_RT6.TabIndex = 367;
        // 
        // NUP_RTForme5
        // 
        this.NUP_RTForme5.Location = new System.Drawing.Point(470, 143);
        this.NUP_RTForme5.Name = "NUP_RTForme5";
        this.NUP_RTForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme5.TabIndex = 327;
        // 
        // CB_RT5
        // 
        this.CB_RT5.FormattingEnabled = true;
        this.CB_RT5.Location = new System.Drawing.Point(343, 142);
        this.CB_RT5.Name = "CB_RT5";
        this.CB_RT5.Size = new System.Drawing.Size(121, 21);
        this.CB_RT5.TabIndex = 366;
        // 
        // NUP_RTMin5
        // 
        this.NUP_RTMin5.Location = new System.Drawing.Point(517, 143);
        this.NUP_RTMin5.Name = "NUP_RTMin5";
        this.NUP_RTMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin5.TabIndex = 328;
        // 
        // CB_RT4
        // 
        this.CB_RT4.FormattingEnabled = true;
        this.CB_RT4.Location = new System.Drawing.Point(343, 115);
        this.CB_RT4.Name = "CB_RT4";
        this.CB_RT4.Size = new System.Drawing.Size(121, 21);
        this.CB_RT4.TabIndex = 365;
        // 
        // NUP_RTMax5
        // 
        this.NUP_RTMax5.Location = new System.Drawing.Point(564, 143);
        this.NUP_RTMax5.Name = "NUP_RTMax5";
        this.NUP_RTMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax5.TabIndex = 329;
        // 
        // CB_RT3
        // 
        this.CB_RT3.FormattingEnabled = true;
        this.CB_RT3.Location = new System.Drawing.Point(343, 89);
        this.CB_RT3.Name = "CB_RT3";
        this.CB_RT3.Size = new System.Drawing.Size(121, 21);
        this.CB_RT3.TabIndex = 364;
        // 
        // NUP_RTForme6
        // 
        this.NUP_RTForme6.Location = new System.Drawing.Point(470, 170);
        this.NUP_RTForme6.Name = "NUP_RTForme6";
        this.NUP_RTForme6.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme6.TabIndex = 330;
        // 
        // CB_RT2
        // 
        this.CB_RT2.FormattingEnabled = true;
        this.CB_RT2.Location = new System.Drawing.Point(343, 62);
        this.CB_RT2.Name = "CB_RT2";
        this.CB_RT2.Size = new System.Drawing.Size(121, 21);
        this.CB_RT2.TabIndex = 363;
        // 
        // NUP_RTMin6
        // 
        this.NUP_RTMin6.Location = new System.Drawing.Point(517, 170);
        this.NUP_RTMin6.Name = "NUP_RTMin6";
        this.NUP_RTMin6.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin6.TabIndex = 331;
        // 
        // CB_RT1
        // 
        this.CB_RT1.FormattingEnabled = true;
        this.CB_RT1.Location = new System.Drawing.Point(343, 36);
        this.CB_RT1.Name = "CB_RT1";
        this.CB_RT1.Size = new System.Drawing.Size(121, 21);
        this.CB_RT1.TabIndex = 314;
        // 
        // NUP_RTMax6
        // 
        this.NUP_RTMax6.Location = new System.Drawing.Point(564, 170);
        this.NUP_RTMax6.Name = "NUP_RTMax6";
        this.NUP_RTMax6.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax6.TabIndex = 332;
        // 
        // label10
        // 
        this.label10.AutoSize = true;
        this.label10.Location = new System.Drawing.Point(310, 39);
        this.label10.Name = "label10";
        this.label10.Size = new System.Drawing.Size(27, 13);
        this.label10.TabIndex = 351;
        this.label10.Text = "10%";
        // 
        // NUP_RTForme7
        // 
        this.NUP_RTForme7.Location = new System.Drawing.Point(470, 196);
        this.NUP_RTForme7.Name = "NUP_RTForme7";
        this.NUP_RTForme7.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme7.TabIndex = 333;
        // 
        // label11
        // 
        this.label11.AutoSize = true;
        this.label11.Location = new System.Drawing.Point(316, 332);
        this.label11.Name = "label11";
        this.label11.Size = new System.Drawing.Size(21, 13);
        this.label11.TabIndex = 362;
        this.label11.Text = "1%";
        // 
        // NUP_RTMin7
        // 
        this.NUP_RTMin7.Location = new System.Drawing.Point(517, 196);
        this.NUP_RTMin7.Name = "NUP_RTMin7";
        this.NUP_RTMin7.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin7.TabIndex = 334;
        // 
        // label12
        // 
        this.label12.AutoSize = true;
        this.label12.Location = new System.Drawing.Point(316, 305);
        this.label12.Name = "label12";
        this.label12.Size = new System.Drawing.Size(21, 13);
        this.label12.TabIndex = 361;
        this.label12.Text = "4%";
        // 
        // NUP_RTMax7
        // 
        this.NUP_RTMax7.Location = new System.Drawing.Point(564, 196);
        this.NUP_RTMax7.Name = "NUP_RTMax7";
        this.NUP_RTMax7.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax7.TabIndex = 335;
        // 
        // label13
        // 
        this.label13.AutoSize = true;
        this.label13.Location = new System.Drawing.Point(316, 278);
        this.label13.Name = "label13";
        this.label13.Size = new System.Drawing.Size(21, 13);
        this.label13.TabIndex = 360;
        this.label13.Text = "5%";
        // 
        // NUP_RTForme8
        // 
        this.NUP_RTForme8.Location = new System.Drawing.Point(470, 223);
        this.NUP_RTForme8.Name = "NUP_RTForme8";
        this.NUP_RTForme8.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme8.TabIndex = 336;
        // 
        // label14
        // 
        this.label14.AutoSize = true;
        this.label14.Location = new System.Drawing.Point(309, 252);
        this.label14.Name = "label14";
        this.label14.Size = new System.Drawing.Size(27, 13);
        this.label14.TabIndex = 359;
        this.label14.Text = "10%";
        // 
        // NUP_RTMin8
        // 
        this.NUP_RTMin8.Location = new System.Drawing.Point(517, 223);
        this.NUP_RTMin8.Name = "NUP_RTMin8";
        this.NUP_RTMin8.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin8.TabIndex = 337;
        // 
        // label15
        // 
        this.label15.AutoSize = true;
        this.label15.Location = new System.Drawing.Point(309, 228);
        this.label15.Name = "label15";
        this.label15.Size = new System.Drawing.Size(27, 13);
        this.label15.TabIndex = 358;
        this.label15.Text = "10%";
        // 
        // NUP_RTMax8
        // 
        this.NUP_RTMax8.Location = new System.Drawing.Point(564, 223);
        this.NUP_RTMax8.Name = "NUP_RTMax8";
        this.NUP_RTMax8.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax8.TabIndex = 338;
        // 
        // label16
        // 
        this.label16.AutoSize = true;
        this.label16.Location = new System.Drawing.Point(309, 201);
        this.label16.Name = "label16";
        this.label16.Size = new System.Drawing.Size(27, 13);
        this.label16.TabIndex = 357;
        this.label16.Text = "10%";
        // 
        // NUP_RTForme9
        // 
        this.NUP_RTForme9.Location = new System.Drawing.Point(470, 250);
        this.NUP_RTForme9.Name = "NUP_RTForme9";
        this.NUP_RTForme9.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme9.TabIndex = 339;
        // 
        // label17
        // 
        this.label17.AutoSize = true;
        this.label17.Location = new System.Drawing.Point(310, 174);
        this.label17.Name = "label17";
        this.label17.Size = new System.Drawing.Size(27, 13);
        this.label17.TabIndex = 356;
        this.label17.Text = "10%";
        // 
        // NUP_RTMin9
        // 
        this.NUP_RTMin9.Location = new System.Drawing.Point(517, 250);
        this.NUP_RTMin9.Name = "NUP_RTMin9";
        this.NUP_RTMin9.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin9.TabIndex = 340;
        // 
        // label18
        // 
        this.label18.AutoSize = true;
        this.label18.Location = new System.Drawing.Point(310, 147);
        this.label18.Name = "label18";
        this.label18.Size = new System.Drawing.Size(27, 13);
        this.label18.TabIndex = 355;
        this.label18.Text = "10%";
        // 
        // NUP_RTMax9
        // 
        this.NUP_RTMax9.Location = new System.Drawing.Point(564, 250);
        this.NUP_RTMax9.Name = "NUP_RTMax9";
        this.NUP_RTMax9.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax9.TabIndex = 341;
        // 
        // label19
        // 
        this.label19.AutoSize = true;
        this.label19.Location = new System.Drawing.Point(310, 120);
        this.label19.Name = "label19";
        this.label19.Size = new System.Drawing.Size(27, 13);
        this.label19.TabIndex = 354;
        this.label19.Text = "10%";
        // 
        // NUP_RTForme10
        // 
        this.NUP_RTForme10.Location = new System.Drawing.Point(470, 276);
        this.NUP_RTForme10.Name = "NUP_RTForme10";
        this.NUP_RTForme10.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme10.TabIndex = 342;
        // 
        // label20
        // 
        this.label20.AutoSize = true;
        this.label20.Location = new System.Drawing.Point(310, 93);
        this.label20.Name = "label20";
        this.label20.Size = new System.Drawing.Size(27, 13);
        this.label20.TabIndex = 353;
        this.label20.Text = "10%";
        // 
        // NUP_RTMin10
        // 
        this.NUP_RTMin10.Location = new System.Drawing.Point(517, 276);
        this.NUP_RTMin10.Name = "NUP_RTMin10";
        this.NUP_RTMin10.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin10.TabIndex = 343;
        // 
        // label21
        // 
        this.label21.AutoSize = true;
        this.label21.Location = new System.Drawing.Point(310, 66);
        this.label21.Name = "label21";
        this.label21.Size = new System.Drawing.Size(27, 13);
        this.label21.TabIndex = 352;
        this.label21.Text = "10%";
        // 
        // NUP_RTMax10
        // 
        this.NUP_RTMax10.Location = new System.Drawing.Point(564, 276);
        this.NUP_RTMax10.Name = "NUP_RTMax10";
        this.NUP_RTMax10.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax10.TabIndex = 344;
        // 
        // NUP_RTForme11
        // 
        this.NUP_RTForme11.Location = new System.Drawing.Point(470, 301);
        this.NUP_RTForme11.Name = "NUP_RTForme11";
        this.NUP_RTForme11.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme11.TabIndex = 350;
        // 
        // NUP_RTMin11
        // 
        this.NUP_RTMin11.Location = new System.Drawing.Point(517, 301);
        this.NUP_RTMin11.Name = "NUP_RTMin11";
        this.NUP_RTMin11.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin11.TabIndex = 345;
        // 
        // NUP_RTMax11
        // 
        this.NUP_RTMax11.Location = new System.Drawing.Point(564, 301);
        this.NUP_RTMax11.Name = "NUP_RTMax11";
        this.NUP_RTMax11.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax11.TabIndex = 349;
        // 
        // NUP_RTForme12
        // 
        this.NUP_RTForme12.Location = new System.Drawing.Point(470, 326);
        this.NUP_RTForme12.Name = "NUP_RTForme12";
        this.NUP_RTForme12.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTForme12.TabIndex = 346;
        // 
        // NUP_RTMin12
        // 
        this.NUP_RTMin12.Location = new System.Drawing.Point(517, 326);
        this.NUP_RTMin12.Name = "NUP_RTMin12";
        this.NUP_RTMin12.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMin12.TabIndex = 348;
        // 
        // NUP_RTMax12
        // 
        this.NUP_RTMax12.Location = new System.Drawing.Point(564, 326);
        this.NUP_RTMax12.Name = "NUP_RTMax12";
        this.NUP_RTMax12.Size = new System.Drawing.Size(41, 20);
        this.NUP_RTMax12.TabIndex = 347;
        // 
        // NUP_GrassForme1
        // 
        this.NUP_GrassForme1.Location = new System.Drawing.Point(171, 36);
        this.NUP_GrassForme1.Name = "NUP_GrassForme1";
        this.NUP_GrassForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme1.TabIndex = 48;
        // 
        // NUP_GrassMin1
        // 
        this.NUP_GrassMin1.Location = new System.Drawing.Point(218, 36);
        this.NUP_GrassMin1.Name = "NUP_GrassMin1";
        this.NUP_GrassMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin1.TabIndex = 49;
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Location = new System.Drawing.Point(170, 20);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(36, 13);
        this.label3.TabIndex = 311;
        this.label3.Text = "Forme";
        // 
        // NUP_GrassMax1
        // 
        this.NUP_GrassMax1.Location = new System.Drawing.Point(265, 36);
        this.NUP_GrassMax1.Name = "NUP_GrassMax1";
        this.NUP_GrassMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax1.TabIndex = 50;
        // 
        // label4
        // 
        this.label4.AutoSize = true;
        this.label4.Location = new System.Drawing.Point(217, 20);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(24, 13);
        this.label4.TabIndex = 312;
        this.label4.Text = "Min";
        // 
        // NUP_GrassForme2
        // 
        this.NUP_GrassForme2.Location = new System.Drawing.Point(171, 63);
        this.NUP_GrassForme2.Name = "NUP_GrassForme2";
        this.NUP_GrassForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme2.TabIndex = 51;
        // 
        // label5
        // 
        this.label5.AutoSize = true;
        this.label5.Location = new System.Drawing.Point(264, 20);
        this.label5.Name = "label5";
        this.label5.Size = new System.Drawing.Size(27, 13);
        this.label5.TabIndex = 313;
        this.label5.Text = "Max";
        // 
        // NUP_GrassMin2
        // 
        this.NUP_GrassMin2.Location = new System.Drawing.Point(218, 63);
        this.NUP_GrassMin2.Name = "NUP_GrassMin2";
        this.NUP_GrassMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin2.TabIndex = 52;
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Location = new System.Drawing.Point(44, 20);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(54, 13);
        this.label2.TabIndex = 310;
        this.label2.Text = "Tall Grass";
        // 
        // NUP_GrassMax2
        // 
        this.NUP_GrassMax2.Location = new System.Drawing.Point(265, 63);
        this.NUP_GrassMax2.Name = "NUP_GrassMax2";
        this.NUP_GrassMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax2.TabIndex = 53;
        // 
        // CB_Grass12
        // 
        this.CB_Grass12.FormattingEnabled = true;
        this.CB_Grass12.Location = new System.Drawing.Point(44, 327);
        this.CB_Grass12.Name = "CB_Grass12";
        this.CB_Grass12.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass12.TabIndex = 309;
        // 
        // NUP_GrassForme3
        // 
        this.NUP_GrassForme3.Location = new System.Drawing.Point(171, 90);
        this.NUP_GrassForme3.Name = "NUP_GrassForme3";
        this.NUP_GrassForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme3.TabIndex = 54;
        // 
        // CB_Grass11
        // 
        this.CB_Grass11.FormattingEnabled = true;
        this.CB_Grass11.Location = new System.Drawing.Point(44, 301);
        this.CB_Grass11.Name = "CB_Grass11";
        this.CB_Grass11.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass11.TabIndex = 308;
        // 
        // NUP_GrassMin3
        // 
        this.NUP_GrassMin3.Location = new System.Drawing.Point(218, 90);
        this.NUP_GrassMin3.Name = "NUP_GrassMin3";
        this.NUP_GrassMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin3.TabIndex = 55;
        // 
        // CB_Grass10
        // 
        this.CB_Grass10.FormattingEnabled = true;
        this.CB_Grass10.Location = new System.Drawing.Point(44, 274);
        this.CB_Grass10.Name = "CB_Grass10";
        this.CB_Grass10.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass10.TabIndex = 307;
        // 
        // NUP_GrassMax3
        // 
        this.NUP_GrassMax3.Location = new System.Drawing.Point(265, 90);
        this.NUP_GrassMax3.Name = "NUP_GrassMax3";
        this.NUP_GrassMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax3.TabIndex = 56;
        // 
        // CB_Grass9
        // 
        this.CB_Grass9.FormattingEnabled = true;
        this.CB_Grass9.Location = new System.Drawing.Point(44, 248);
        this.CB_Grass9.Name = "CB_Grass9";
        this.CB_Grass9.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass9.TabIndex = 306;
        // 
        // NUP_GrassForme4
        // 
        this.NUP_GrassForme4.Location = new System.Drawing.Point(171, 116);
        this.NUP_GrassForme4.Name = "NUP_GrassForme4";
        this.NUP_GrassForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme4.TabIndex = 57;
        // 
        // CB_Grass8
        // 
        this.CB_Grass8.FormattingEnabled = true;
        this.CB_Grass8.Location = new System.Drawing.Point(44, 221);
        this.CB_Grass8.Name = "CB_Grass8";
        this.CB_Grass8.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass8.TabIndex = 305;
        // 
        // NUP_GrassMin4
        // 
        this.NUP_GrassMin4.Location = new System.Drawing.Point(218, 116);
        this.NUP_GrassMin4.Name = "NUP_GrassMin4";
        this.NUP_GrassMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin4.TabIndex = 58;
        // 
        // CB_Grass7
        // 
        this.CB_Grass7.FormattingEnabled = true;
        this.CB_Grass7.Location = new System.Drawing.Point(44, 195);
        this.CB_Grass7.Name = "CB_Grass7";
        this.CB_Grass7.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass7.TabIndex = 304;
        // 
        // NUP_GrassMax4
        // 
        this.NUP_GrassMax4.Location = new System.Drawing.Point(265, 116);
        this.NUP_GrassMax4.Name = "NUP_GrassMax4";
        this.NUP_GrassMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax4.TabIndex = 59;
        // 
        // CB_Grass6
        // 
        this.CB_Grass6.FormattingEnabled = true;
        this.CB_Grass6.Location = new System.Drawing.Point(44, 168);
        this.CB_Grass6.Name = "CB_Grass6";
        this.CB_Grass6.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass6.TabIndex = 303;
        // 
        // NUP_GrassForme5
        // 
        this.NUP_GrassForme5.Location = new System.Drawing.Point(171, 143);
        this.NUP_GrassForme5.Name = "NUP_GrassForme5";
        this.NUP_GrassForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme5.TabIndex = 60;
        // 
        // CB_Grass5
        // 
        this.CB_Grass5.FormattingEnabled = true;
        this.CB_Grass5.Location = new System.Drawing.Point(44, 142);
        this.CB_Grass5.Name = "CB_Grass5";
        this.CB_Grass5.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass5.TabIndex = 302;
        // 
        // NUP_GrassMin5
        // 
        this.NUP_GrassMin5.Location = new System.Drawing.Point(218, 143);
        this.NUP_GrassMin5.Name = "NUP_GrassMin5";
        this.NUP_GrassMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin5.TabIndex = 61;
        // 
        // CB_Grass4
        // 
        this.CB_Grass4.FormattingEnabled = true;
        this.CB_Grass4.Location = new System.Drawing.Point(44, 115);
        this.CB_Grass4.Name = "CB_Grass4";
        this.CB_Grass4.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass4.TabIndex = 301;
        // 
        // NUP_GrassMax5
        // 
        this.NUP_GrassMax5.Location = new System.Drawing.Point(265, 143);
        this.NUP_GrassMax5.Name = "NUP_GrassMax5";
        this.NUP_GrassMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax5.TabIndex = 62;
        // 
        // CB_Grass3
        // 
        this.CB_Grass3.FormattingEnabled = true;
        this.CB_Grass3.Location = new System.Drawing.Point(44, 89);
        this.CB_Grass3.Name = "CB_Grass3";
        this.CB_Grass3.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass3.TabIndex = 300;
        // 
        // NUP_GrassForme6
        // 
        this.NUP_GrassForme6.Location = new System.Drawing.Point(171, 170);
        this.NUP_GrassForme6.Name = "NUP_GrassForme6";
        this.NUP_GrassForme6.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme6.TabIndex = 63;
        // 
        // CB_Grass2
        // 
        this.CB_Grass2.FormattingEnabled = true;
        this.CB_Grass2.Location = new System.Drawing.Point(44, 62);
        this.CB_Grass2.Name = "CB_Grass2";
        this.CB_Grass2.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass2.TabIndex = 299;
        // 
        // NUP_GrassMin6
        // 
        this.NUP_GrassMin6.Location = new System.Drawing.Point(218, 170);
        this.NUP_GrassMin6.Name = "NUP_GrassMin6";
        this.NUP_GrassMin6.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin6.TabIndex = 64;
        // 
        // CB_Grass1
        // 
        this.CB_Grass1.FormattingEnabled = true;
        this.CB_Grass1.Location = new System.Drawing.Point(44, 36);
        this.CB_Grass1.Name = "CB_Grass1";
        this.CB_Grass1.Size = new System.Drawing.Size(121, 21);
        this.CB_Grass1.TabIndex = 3;
        // 
        // NUP_GrassMax6
        // 
        this.NUP_GrassMax6.Location = new System.Drawing.Point(265, 170);
        this.NUP_GrassMax6.Name = "NUP_GrassMax6";
        this.NUP_GrassMax6.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax6.TabIndex = 65;
        // 
        // label31
        // 
        this.label31.AutoSize = true;
        this.label31.Location = new System.Drawing.Point(11, 39);
        this.label31.Name = "label31";
        this.label31.Size = new System.Drawing.Size(27, 13);
        this.label31.TabIndex = 287;
        this.label31.Text = "10%";
        // 
        // NUP_GrassForme7
        // 
        this.NUP_GrassForme7.Location = new System.Drawing.Point(171, 196);
        this.NUP_GrassForme7.Name = "NUP_GrassForme7";
        this.NUP_GrassForme7.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme7.TabIndex = 66;
        // 
        // label41
        // 
        this.label41.AutoSize = true;
        this.label41.Location = new System.Drawing.Point(17, 332);
        this.label41.Name = "label41";
        this.label41.Size = new System.Drawing.Size(21, 13);
        this.label41.TabIndex = 298;
        this.label41.Text = "1%";
        // 
        // NUP_GrassMin7
        // 
        this.NUP_GrassMin7.Location = new System.Drawing.Point(218, 196);
        this.NUP_GrassMin7.Name = "NUP_GrassMin7";
        this.NUP_GrassMin7.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin7.TabIndex = 67;
        // 
        // label42
        // 
        this.label42.AutoSize = true;
        this.label42.Location = new System.Drawing.Point(17, 305);
        this.label42.Name = "label42";
        this.label42.Size = new System.Drawing.Size(21, 13);
        this.label42.TabIndex = 297;
        this.label42.Text = "4%";
        // 
        // NUP_GrassMax7
        // 
        this.NUP_GrassMax7.Location = new System.Drawing.Point(265, 196);
        this.NUP_GrassMax7.Name = "NUP_GrassMax7";
        this.NUP_GrassMax7.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax7.TabIndex = 68;
        // 
        // label40
        // 
        this.label40.AutoSize = true;
        this.label40.Location = new System.Drawing.Point(17, 278);
        this.label40.Name = "label40";
        this.label40.Size = new System.Drawing.Size(21, 13);
        this.label40.TabIndex = 296;
        this.label40.Text = "5%";
        // 
        // NUP_GrassForme8
        // 
        this.NUP_GrassForme8.Location = new System.Drawing.Point(171, 223);
        this.NUP_GrassForme8.Name = "NUP_GrassForme8";
        this.NUP_GrassForme8.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme8.TabIndex = 69;
        // 
        // label39
        // 
        this.label39.AutoSize = true;
        this.label39.Location = new System.Drawing.Point(10, 252);
        this.label39.Name = "label39";
        this.label39.Size = new System.Drawing.Size(27, 13);
        this.label39.TabIndex = 295;
        this.label39.Text = "10%";
        // 
        // NUP_GrassMin8
        // 
        this.NUP_GrassMin8.Location = new System.Drawing.Point(218, 223);
        this.NUP_GrassMin8.Name = "NUP_GrassMin8";
        this.NUP_GrassMin8.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin8.TabIndex = 70;
        // 
        // label38
        // 
        this.label38.AutoSize = true;
        this.label38.Location = new System.Drawing.Point(10, 228);
        this.label38.Name = "label38";
        this.label38.Size = new System.Drawing.Size(27, 13);
        this.label38.TabIndex = 294;
        this.label38.Text = "10%";
        // 
        // NUP_GrassMax8
        // 
        this.NUP_GrassMax8.Location = new System.Drawing.Point(265, 223);
        this.NUP_GrassMax8.Name = "NUP_GrassMax8";
        this.NUP_GrassMax8.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax8.TabIndex = 71;
        // 
        // label37
        // 
        this.label37.AutoSize = true;
        this.label37.Location = new System.Drawing.Point(10, 201);
        this.label37.Name = "label37";
        this.label37.Size = new System.Drawing.Size(27, 13);
        this.label37.TabIndex = 293;
        this.label37.Text = "10%";
        // 
        // NUP_GrassForme9
        // 
        this.NUP_GrassForme9.Location = new System.Drawing.Point(171, 250);
        this.NUP_GrassForme9.Name = "NUP_GrassForme9";
        this.NUP_GrassForme9.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme9.TabIndex = 72;
        // 
        // label36
        // 
        this.label36.AutoSize = true;
        this.label36.Location = new System.Drawing.Point(11, 174);
        this.label36.Name = "label36";
        this.label36.Size = new System.Drawing.Size(27, 13);
        this.label36.TabIndex = 292;
        this.label36.Text = "10%";
        // 
        // NUP_GrassMin9
        // 
        this.NUP_GrassMin9.Location = new System.Drawing.Point(218, 250);
        this.NUP_GrassMin9.Name = "NUP_GrassMin9";
        this.NUP_GrassMin9.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin9.TabIndex = 73;
        // 
        // label35
        // 
        this.label35.AutoSize = true;
        this.label35.Location = new System.Drawing.Point(11, 147);
        this.label35.Name = "label35";
        this.label35.Size = new System.Drawing.Size(27, 13);
        this.label35.TabIndex = 291;
        this.label35.Text = "10%";
        // 
        // NUP_GrassMax9
        // 
        this.NUP_GrassMax9.Location = new System.Drawing.Point(265, 250);
        this.NUP_GrassMax9.Name = "NUP_GrassMax9";
        this.NUP_GrassMax9.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax9.TabIndex = 74;
        // 
        // label34
        // 
        this.label34.AutoSize = true;
        this.label34.Location = new System.Drawing.Point(11, 120);
        this.label34.Name = "label34";
        this.label34.Size = new System.Drawing.Size(27, 13);
        this.label34.TabIndex = 290;
        this.label34.Text = "10%";
        // 
        // NUP_GrassForme10
        // 
        this.NUP_GrassForme10.Location = new System.Drawing.Point(171, 276);
        this.NUP_GrassForme10.Name = "NUP_GrassForme10";
        this.NUP_GrassForme10.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme10.TabIndex = 75;
        // 
        // label33
        // 
        this.label33.AutoSize = true;
        this.label33.Location = new System.Drawing.Point(11, 93);
        this.label33.Name = "label33";
        this.label33.Size = new System.Drawing.Size(27, 13);
        this.label33.TabIndex = 289;
        this.label33.Text = "10%";
        // 
        // NUP_GrassMin10
        // 
        this.NUP_GrassMin10.Location = new System.Drawing.Point(218, 276);
        this.NUP_GrassMin10.Name = "NUP_GrassMin10";
        this.NUP_GrassMin10.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin10.TabIndex = 76;
        // 
        // label32
        // 
        this.label32.AutoSize = true;
        this.label32.Location = new System.Drawing.Point(11, 66);
        this.label32.Name = "label32";
        this.label32.Size = new System.Drawing.Size(27, 13);
        this.label32.TabIndex = 288;
        this.label32.Text = "10%";
        // 
        // NUP_GrassMax10
        // 
        this.NUP_GrassMax10.Location = new System.Drawing.Point(265, 276);
        this.NUP_GrassMax10.Name = "NUP_GrassMax10";
        this.NUP_GrassMax10.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax10.TabIndex = 77;
        // 
        // NUP_GrassMax12
        // 
        this.NUP_GrassMax12.Location = new System.Drawing.Point(265, 330);
        this.NUP_GrassMax12.Name = "NUP_GrassMax12";
        this.NUP_GrassMax12.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax12.TabIndex = 83;
        // 
        // NUP_GrassForme11
        // 
        this.NUP_GrassForme11.Location = new System.Drawing.Point(171, 303);
        this.NUP_GrassForme11.Name = "NUP_GrassForme11";
        this.NUP_GrassForme11.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme11.TabIndex = 78;
        // 
        // NUP_GrassMin12
        // 
        this.NUP_GrassMin12.Location = new System.Drawing.Point(218, 330);
        this.NUP_GrassMin12.Name = "NUP_GrassMin12";
        this.NUP_GrassMin12.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin12.TabIndex = 82;
        // 
        // NUP_GrassMin11
        // 
        this.NUP_GrassMin11.Location = new System.Drawing.Point(218, 303);
        this.NUP_GrassMin11.Name = "NUP_GrassMin11";
        this.NUP_GrassMin11.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMin11.TabIndex = 79;
        // 
        // NUP_GrassForme12
        // 
        this.NUP_GrassForme12.Location = new System.Drawing.Point(171, 330);
        this.NUP_GrassForme12.Name = "NUP_GrassForme12";
        this.NUP_GrassForme12.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassForme12.TabIndex = 81;
        // 
        // NUP_GrassMax11
        // 
        this.NUP_GrassMax11.Location = new System.Drawing.Point(265, 303);
        this.NUP_GrassMax11.Name = "NUP_GrassMax11";
        this.NUP_GrassMax11.Size = new System.Drawing.Size(41, 20);
        this.NUP_GrassMax11.TabIndex = 80;
        // 
        // TabPage_Water
        // 
        this.TabPage_Water.Controls.Add(this.label116);
        this.TabPage_Water.Controls.Add(this.label117);
        this.TabPage_Water.Controls.Add(this.label118);
        this.TabPage_Water.Controls.Add(this.label119);
        this.TabPage_Water.Controls.Add(this.label120);
        this.TabPage_Water.Controls.Add(this.label103);
        this.TabPage_Water.Controls.Add(this.label48);
        this.TabPage_Water.Controls.Add(this.label104);
        this.TabPage_Water.Controls.Add(this.CB_Super1);
        this.TabPage_Water.Controls.Add(this.label105);
        this.TabPage_Water.Controls.Add(this.NUP_SuperForme1);
        this.TabPage_Water.Controls.Add(this.label106);
        this.TabPage_Water.Controls.Add(this.CB_Surf1);
        this.TabPage_Water.Controls.Add(this.NUP_SuperMin1);
        this.TabPage_Water.Controls.Add(this.NUP_SurfForme1);
        this.TabPage_Water.Controls.Add(this.NUP_SuperMax1);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMin1);
        this.TabPage_Water.Controls.Add(this.CB_Super2);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMax1);
        this.TabPage_Water.Controls.Add(this.NUP_SuperForme2);
        this.TabPage_Water.Controls.Add(this.CB_Surf2);
        this.TabPage_Water.Controls.Add(this.NUP_SuperMin2);
        this.TabPage_Water.Controls.Add(this.NUP_SurfForme2);
        this.TabPage_Water.Controls.Add(this.NUP_SuperMax2);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMin2);
        this.TabPage_Water.Controls.Add(this.CB_Super3);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMax5);
        this.TabPage_Water.Controls.Add(this.NUP_SuperForme3);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMax2);
        this.TabPage_Water.Controls.Add(this.NUP_SuperMin3);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMin5);
        this.TabPage_Water.Controls.Add(this.NUP_SuperMax3);
        this.TabPage_Water.Controls.Add(this.CB_Surf3);
        this.TabPage_Water.Controls.Add(this.label49);
        this.TabPage_Water.Controls.Add(this.NUP_SurfForme5);
        this.TabPage_Water.Controls.Add(this.label98);
        this.TabPage_Water.Controls.Add(this.NUP_SurfForme3);
        this.TabPage_Water.Controls.Add(this.label99);
        this.TabPage_Water.Controls.Add(this.CB_Surf5);
        this.TabPage_Water.Controls.Add(this.label100);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMin3);
        this.TabPage_Water.Controls.Add(this.label101);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMax4);
        this.TabPage_Water.Controls.Add(this.label102);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMax3);
        this.TabPage_Water.Controls.Add(this.label26);
        this.TabPage_Water.Controls.Add(this.NUP_SurfMin4);
        this.TabPage_Water.Controls.Add(this.CB_Good1);
        this.TabPage_Water.Controls.Add(this.CB_Surf4);
        this.TabPage_Water.Controls.Add(this.NUP_GoodForme1);
        this.TabPage_Water.Controls.Add(this.NUP_SurfForme4);
        this.TabPage_Water.Controls.Add(this.NUP_GoodMin1);
        this.TabPage_Water.Controls.Add(this.NUP_GoodMax1);
        this.TabPage_Water.Controls.Add(this.CB_Good2);
        this.TabPage_Water.Controls.Add(this.NUP_GoodForme2);
        this.TabPage_Water.Controls.Add(this.NUP_GoodMin2);
        this.TabPage_Water.Controls.Add(this.NUP_GoodMax2);
        this.TabPage_Water.Controls.Add(this.CB_Good3);
        this.TabPage_Water.Controls.Add(this.NUP_GoodForme3);
        this.TabPage_Water.Controls.Add(this.NUP_GoodMin3);
        this.TabPage_Water.Controls.Add(this.NUP_GoodMax3);
        this.TabPage_Water.Controls.Add(this.label27);
        this.TabPage_Water.Controls.Add(this.label28);
        this.TabPage_Water.Controls.Add(this.label29);
        this.TabPage_Water.Controls.Add(this.label30);
        this.TabPage_Water.Controls.Add(this.label46);
        this.TabPage_Water.Controls.Add(this.label47);
        this.TabPage_Water.Controls.Add(this.label22);
        this.TabPage_Water.Controls.Add(this.CB_Old1);
        this.TabPage_Water.Controls.Add(this.NUP_OldForme1);
        this.TabPage_Water.Controls.Add(this.NUP_OldMin1);
        this.TabPage_Water.Controls.Add(this.NUP_OldMax1);
        this.TabPage_Water.Controls.Add(this.CB_Old2);
        this.TabPage_Water.Controls.Add(this.NUP_OldForme2);
        this.TabPage_Water.Controls.Add(this.NUP_OldMin2);
        this.TabPage_Water.Controls.Add(this.NUP_OldMax2);
        this.TabPage_Water.Controls.Add(this.CB_Old3);
        this.TabPage_Water.Controls.Add(this.NUP_OldForme3);
        this.TabPage_Water.Controls.Add(this.NUP_OldMin3);
        this.TabPage_Water.Controls.Add(this.NUP_OldMax3);
        this.TabPage_Water.Controls.Add(this.label45);
        this.TabPage_Water.Controls.Add(this.label44);
        this.TabPage_Water.Controls.Add(this.label43);
        this.TabPage_Water.Controls.Add(this.label23);
        this.TabPage_Water.Controls.Add(this.label24);
        this.TabPage_Water.Controls.Add(this.label25);
        this.TabPage_Water.Location = new System.Drawing.Point(4, 22);
        this.TabPage_Water.Name = "TabPage_Water";
        this.TabPage_Water.Padding = new System.Windows.Forms.Padding(3);
        this.TabPage_Water.Size = new System.Drawing.Size(918, 369);
        this.TabPage_Water.TabIndex = 1;
        this.TabPage_Water.Text = "Water";
        this.TabPage_Water.UseVisualStyleBackColor = true;
        // 
        // label116
        // 
        this.label116.AutoSize = true;
        this.label116.Location = new System.Drawing.Point(313, 285);
        this.label116.Name = "label116";
        this.label116.Size = new System.Drawing.Size(21, 13);
        this.label116.TabIndex = 351;
        this.label116.Text = "1%";
        // 
        // label117
        // 
        this.label117.AutoSize = true;
        this.label117.Location = new System.Drawing.Point(313, 258);
        this.label117.Name = "label117";
        this.label117.Size = new System.Drawing.Size(21, 13);
        this.label117.TabIndex = 350;
        this.label117.Text = "4%";
        // 
        // label118
        // 
        this.label118.AutoSize = true;
        this.label118.Location = new System.Drawing.Point(308, 231);
        this.label118.Name = "label118";
        this.label118.Size = new System.Drawing.Size(27, 13);
        this.label118.TabIndex = 349;
        this.label118.Text = "15%";
        // 
        // label119
        // 
        this.label119.AutoSize = true;
        this.label119.Location = new System.Drawing.Point(307, 204);
        this.label119.Name = "label119";
        this.label119.Size = new System.Drawing.Size(27, 13);
        this.label119.TabIndex = 348;
        this.label119.Text = "30%";
        // 
        // label120
        // 
        this.label120.AutoSize = true;
        this.label120.Location = new System.Drawing.Point(307, 177);
        this.label120.Name = "label120";
        this.label120.Size = new System.Drawing.Size(27, 13);
        this.label120.TabIndex = 347;
        this.label120.Text = "50%";
        // 
        // label103
        // 
        this.label103.AutoSize = true;
        this.label103.Location = new System.Drawing.Point(558, 159);
        this.label103.Name = "label103";
        this.label103.Size = new System.Drawing.Size(27, 13);
        this.label103.TabIndex = 288;
        this.label103.Text = "Max";
        // 
        // label48
        // 
        this.label48.AutoSize = true;
        this.label48.Location = new System.Drawing.Point(639, 13);
        this.label48.Name = "label48";
        this.label48.Size = new System.Drawing.Size(58, 13);
        this.label48.TabIndex = 340;
        this.label48.Text = "Super Rod";
        // 
        // label104
        // 
        this.label104.AutoSize = true;
        this.label104.Location = new System.Drawing.Point(511, 159);
        this.label104.Name = "label104";
        this.label104.Size = new System.Drawing.Size(24, 13);
        this.label104.TabIndex = 287;
        this.label104.Text = "Min";
        // 
        // CB_Super1
        // 
        this.CB_Super1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Super1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Super1.FormattingEnabled = true;
        this.CB_Super1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Super1.Location = new System.Drawing.Point(642, 29);
        this.CB_Super1.Name = "CB_Super1";
        this.CB_Super1.Size = new System.Drawing.Size(121, 21);
        this.CB_Super1.TabIndex = 328;
        // 
        // label105
        // 
        this.label105.AutoSize = true;
        this.label105.Location = new System.Drawing.Point(464, 159);
        this.label105.Name = "label105";
        this.label105.Size = new System.Drawing.Size(36, 13);
        this.label105.TabIndex = 286;
        this.label105.Text = "Forme";
        // 
        // NUP_SuperForme1
        // 
        this.NUP_SuperForme1.Location = new System.Drawing.Point(769, 30);
        this.NUP_SuperForme1.Name = "NUP_SuperForme1";
        this.NUP_SuperForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperForme1.TabIndex = 329;
        // 
        // label106
        // 
        this.label106.AutoSize = true;
        this.label106.Location = new System.Drawing.Point(340, 159);
        this.label106.Name = "label106";
        this.label106.Size = new System.Drawing.Size(40, 13);
        this.label106.TabIndex = 285;
        this.label106.Text = "Surfing";
        // 
        // CB_Surf1
        // 
        this.CB_Surf1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Surf1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Surf1.FormattingEnabled = true;
        this.CB_Surf1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Surf1.Location = new System.Drawing.Point(340, 174);
        this.CB_Surf1.Name = "CB_Surf1";
        this.CB_Surf1.Size = new System.Drawing.Size(121, 21);
        this.CB_Surf1.TabIndex = 265;
        // 
        // NUP_SuperMin1
        // 
        this.NUP_SuperMin1.Location = new System.Drawing.Point(816, 30);
        this.NUP_SuperMin1.Name = "NUP_SuperMin1";
        this.NUP_SuperMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperMin1.TabIndex = 330;
        // 
        // NUP_SurfForme1
        // 
        this.NUP_SurfForme1.Location = new System.Drawing.Point(467, 175);
        this.NUP_SurfForme1.Name = "NUP_SurfForme1";
        this.NUP_SurfForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfForme1.TabIndex = 266;
        // 
        // NUP_SuperMax1
        // 
        this.NUP_SuperMax1.Location = new System.Drawing.Point(863, 30);
        this.NUP_SuperMax1.Name = "NUP_SuperMax1";
        this.NUP_SuperMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperMax1.TabIndex = 331;
        // 
        // NUP_SurfMin1
        // 
        this.NUP_SurfMin1.Location = new System.Drawing.Point(514, 175);
        this.NUP_SurfMin1.Name = "NUP_SurfMin1";
        this.NUP_SurfMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMin1.TabIndex = 267;
        // 
        // CB_Super2
        // 
        this.CB_Super2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Super2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Super2.FormattingEnabled = true;
        this.CB_Super2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Super2.Location = new System.Drawing.Point(642, 56);
        this.CB_Super2.Name = "CB_Super2";
        this.CB_Super2.Size = new System.Drawing.Size(121, 21);
        this.CB_Super2.TabIndex = 332;
        // 
        // NUP_SurfMax1
        // 
        this.NUP_SurfMax1.Location = new System.Drawing.Point(561, 175);
        this.NUP_SurfMax1.Name = "NUP_SurfMax1";
        this.NUP_SurfMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMax1.TabIndex = 268;
        // 
        // NUP_SuperForme2
        // 
        this.NUP_SuperForme2.Location = new System.Drawing.Point(769, 57);
        this.NUP_SuperForme2.Name = "NUP_SuperForme2";
        this.NUP_SuperForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperForme2.TabIndex = 333;
        // 
        // CB_Surf2
        // 
        this.CB_Surf2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Surf2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Surf2.FormattingEnabled = true;
        this.CB_Surf2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Surf2.Location = new System.Drawing.Point(340, 201);
        this.CB_Surf2.Name = "CB_Surf2";
        this.CB_Surf2.Size = new System.Drawing.Size(121, 21);
        this.CB_Surf2.TabIndex = 269;
        // 
        // NUP_SuperMin2
        // 
        this.NUP_SuperMin2.Location = new System.Drawing.Point(816, 57);
        this.NUP_SuperMin2.Name = "NUP_SuperMin2";
        this.NUP_SuperMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperMin2.TabIndex = 334;
        // 
        // NUP_SurfForme2
        // 
        this.NUP_SurfForme2.Location = new System.Drawing.Point(467, 202);
        this.NUP_SurfForme2.Name = "NUP_SurfForme2";
        this.NUP_SurfForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfForme2.TabIndex = 270;
        // 
        // NUP_SuperMax2
        // 
        this.NUP_SuperMax2.Location = new System.Drawing.Point(863, 57);
        this.NUP_SuperMax2.Name = "NUP_SuperMax2";
        this.NUP_SuperMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperMax2.TabIndex = 335;
        // 
        // NUP_SurfMin2
        // 
        this.NUP_SurfMin2.Location = new System.Drawing.Point(514, 202);
        this.NUP_SurfMin2.Name = "NUP_SurfMin2";
        this.NUP_SurfMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMin2.TabIndex = 271;
        // 
        // CB_Super3
        // 
        this.CB_Super3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Super3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Super3.FormattingEnabled = true;
        this.CB_Super3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Super3.Location = new System.Drawing.Point(642, 83);
        this.CB_Super3.Name = "CB_Super3";
        this.CB_Super3.Size = new System.Drawing.Size(121, 21);
        this.CB_Super3.TabIndex = 336;
        // 
        // NUP_SurfMax5
        // 
        this.NUP_SurfMax5.Location = new System.Drawing.Point(561, 283);
        this.NUP_SurfMax5.Name = "NUP_SurfMax5";
        this.NUP_SurfMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMax5.TabIndex = 284;
        // 
        // NUP_SuperForme3
        // 
        this.NUP_SuperForme3.Location = new System.Drawing.Point(769, 84);
        this.NUP_SuperForme3.Name = "NUP_SuperForme3";
        this.NUP_SuperForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperForme3.TabIndex = 337;
        // 
        // NUP_SurfMax2
        // 
        this.NUP_SurfMax2.Location = new System.Drawing.Point(561, 202);
        this.NUP_SurfMax2.Name = "NUP_SurfMax2";
        this.NUP_SurfMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMax2.TabIndex = 272;
        // 
        // NUP_SuperMin3
        // 
        this.NUP_SuperMin3.Location = new System.Drawing.Point(816, 84);
        this.NUP_SuperMin3.Name = "NUP_SuperMin3";
        this.NUP_SuperMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperMin3.TabIndex = 338;
        // 
        // NUP_SurfMin5
        // 
        this.NUP_SurfMin5.Location = new System.Drawing.Point(514, 283);
        this.NUP_SurfMin5.Name = "NUP_SurfMin5";
        this.NUP_SurfMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMin5.TabIndex = 283;
        // 
        // NUP_SuperMax3
        // 
        this.NUP_SuperMax3.Location = new System.Drawing.Point(863, 84);
        this.NUP_SuperMax3.Name = "NUP_SuperMax3";
        this.NUP_SuperMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_SuperMax3.TabIndex = 339;
        // 
        // CB_Surf3
        // 
        this.CB_Surf3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Surf3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Surf3.FormattingEnabled = true;
        this.CB_Surf3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Surf3.Location = new System.Drawing.Point(340, 228);
        this.CB_Surf3.Name = "CB_Surf3";
        this.CB_Surf3.Size = new System.Drawing.Size(121, 21);
        this.CB_Surf3.TabIndex = 273;
        // 
        // label49
        // 
        this.label49.AutoSize = true;
        this.label49.Location = new System.Drawing.Point(615, 86);
        this.label49.Name = "label49";
        this.label49.Size = new System.Drawing.Size(21, 13);
        this.label49.TabIndex = 346;
        this.label49.Text = "5%";
        // 
        // NUP_SurfForme5
        // 
        this.NUP_SurfForme5.Location = new System.Drawing.Point(467, 283);
        this.NUP_SurfForme5.Name = "NUP_SurfForme5";
        this.NUP_SurfForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfForme5.TabIndex = 282;
        // 
        // label98
        // 
        this.label98.AutoSize = true;
        this.label98.Location = new System.Drawing.Point(609, 59);
        this.label98.Name = "label98";
        this.label98.Size = new System.Drawing.Size(27, 13);
        this.label98.TabIndex = 345;
        this.label98.Text = "35%";
        // 
        // NUP_SurfForme3
        // 
        this.NUP_SurfForme3.Location = new System.Drawing.Point(467, 229);
        this.NUP_SurfForme3.Name = "NUP_SurfForme3";
        this.NUP_SurfForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfForme3.TabIndex = 274;
        // 
        // label99
        // 
        this.label99.AutoSize = true;
        this.label99.Location = new System.Drawing.Point(609, 32);
        this.label99.Name = "label99";
        this.label99.Size = new System.Drawing.Size(27, 13);
        this.label99.TabIndex = 344;
        this.label99.Text = "60%";
        // 
        // CB_Surf5
        // 
        this.CB_Surf5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Surf5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Surf5.FormattingEnabled = true;
        this.CB_Surf5.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Surf5.Location = new System.Drawing.Point(340, 282);
        this.CB_Surf5.Name = "CB_Surf5";
        this.CB_Surf5.Size = new System.Drawing.Size(121, 21);
        this.CB_Surf5.TabIndex = 281;
        // 
        // label100
        // 
        this.label100.AutoSize = true;
        this.label100.Location = new System.Drawing.Point(766, 14);
        this.label100.Name = "label100";
        this.label100.Size = new System.Drawing.Size(36, 13);
        this.label100.TabIndex = 341;
        this.label100.Text = "Forme";
        // 
        // NUP_SurfMin3
        // 
        this.NUP_SurfMin3.Location = new System.Drawing.Point(514, 229);
        this.NUP_SurfMin3.Name = "NUP_SurfMin3";
        this.NUP_SurfMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMin3.TabIndex = 275;
        // 
        // label101
        // 
        this.label101.AutoSize = true;
        this.label101.Location = new System.Drawing.Point(813, 14);
        this.label101.Name = "label101";
        this.label101.Size = new System.Drawing.Size(24, 13);
        this.label101.TabIndex = 342;
        this.label101.Text = "Min";
        // 
        // NUP_SurfMax4
        // 
        this.NUP_SurfMax4.Location = new System.Drawing.Point(561, 256);
        this.NUP_SurfMax4.Name = "NUP_SurfMax4";
        this.NUP_SurfMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMax4.TabIndex = 280;
        // 
        // label102
        // 
        this.label102.AutoSize = true;
        this.label102.Location = new System.Drawing.Point(860, 14);
        this.label102.Name = "label102";
        this.label102.Size = new System.Drawing.Size(27, 13);
        this.label102.TabIndex = 343;
        this.label102.Text = "Max";
        // 
        // NUP_SurfMax3
        // 
        this.NUP_SurfMax3.Location = new System.Drawing.Point(561, 229);
        this.NUP_SurfMax3.Name = "NUP_SurfMax3";
        this.NUP_SurfMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMax3.TabIndex = 276;
        // 
        // label26
        // 
        this.label26.AutoSize = true;
        this.label26.Location = new System.Drawing.Point(340, 13);
        this.label26.Name = "label26";
        this.label26.Size = new System.Drawing.Size(56, 13);
        this.label26.TabIndex = 321;
        this.label26.Text = "Good Rod";
        // 
        // NUP_SurfMin4
        // 
        this.NUP_SurfMin4.Location = new System.Drawing.Point(514, 256);
        this.NUP_SurfMin4.Name = "NUP_SurfMin4";
        this.NUP_SurfMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfMin4.TabIndex = 279;
        // 
        // CB_Good1
        // 
        this.CB_Good1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Good1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Good1.FormattingEnabled = true;
        this.CB_Good1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Good1.Location = new System.Drawing.Point(343, 29);
        this.CB_Good1.Name = "CB_Good1";
        this.CB_Good1.Size = new System.Drawing.Size(121, 21);
        this.CB_Good1.TabIndex = 309;
        // 
        // CB_Surf4
        // 
        this.CB_Surf4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Surf4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Surf4.FormattingEnabled = true;
        this.CB_Surf4.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Surf4.Location = new System.Drawing.Point(340, 255);
        this.CB_Surf4.Name = "CB_Surf4";
        this.CB_Surf4.Size = new System.Drawing.Size(121, 21);
        this.CB_Surf4.TabIndex = 277;
        // 
        // NUP_GoodForme1
        // 
        this.NUP_GoodForme1.Location = new System.Drawing.Point(470, 30);
        this.NUP_GoodForme1.Name = "NUP_GoodForme1";
        this.NUP_GoodForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodForme1.TabIndex = 310;
        // 
        // NUP_SurfForme4
        // 
        this.NUP_SurfForme4.Location = new System.Drawing.Point(467, 256);
        this.NUP_SurfForme4.Name = "NUP_SurfForme4";
        this.NUP_SurfForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_SurfForme4.TabIndex = 278;
        // 
        // NUP_GoodMin1
        // 
        this.NUP_GoodMin1.Location = new System.Drawing.Point(517, 30);
        this.NUP_GoodMin1.Name = "NUP_GoodMin1";
        this.NUP_GoodMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodMin1.TabIndex = 311;
        // 
        // NUP_GoodMax1
        // 
        this.NUP_GoodMax1.Location = new System.Drawing.Point(564, 30);
        this.NUP_GoodMax1.Name = "NUP_GoodMax1";
        this.NUP_GoodMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodMax1.TabIndex = 312;
        // 
        // CB_Good2
        // 
        this.CB_Good2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Good2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Good2.FormattingEnabled = true;
        this.CB_Good2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Good2.Location = new System.Drawing.Point(343, 56);
        this.CB_Good2.Name = "CB_Good2";
        this.CB_Good2.Size = new System.Drawing.Size(121, 21);
        this.CB_Good2.TabIndex = 313;
        // 
        // NUP_GoodForme2
        // 
        this.NUP_GoodForme2.Location = new System.Drawing.Point(470, 57);
        this.NUP_GoodForme2.Name = "NUP_GoodForme2";
        this.NUP_GoodForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodForme2.TabIndex = 314;
        // 
        // NUP_GoodMin2
        // 
        this.NUP_GoodMin2.Location = new System.Drawing.Point(517, 57);
        this.NUP_GoodMin2.Name = "NUP_GoodMin2";
        this.NUP_GoodMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodMin2.TabIndex = 315;
        // 
        // NUP_GoodMax2
        // 
        this.NUP_GoodMax2.Location = new System.Drawing.Point(564, 57);
        this.NUP_GoodMax2.Name = "NUP_GoodMax2";
        this.NUP_GoodMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodMax2.TabIndex = 316;
        // 
        // CB_Good3
        // 
        this.CB_Good3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Good3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Good3.FormattingEnabled = true;
        this.CB_Good3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Good3.Location = new System.Drawing.Point(343, 83);
        this.CB_Good3.Name = "CB_Good3";
        this.CB_Good3.Size = new System.Drawing.Size(121, 21);
        this.CB_Good3.TabIndex = 317;
        // 
        // NUP_GoodForme3
        // 
        this.NUP_GoodForme3.Location = new System.Drawing.Point(470, 84);
        this.NUP_GoodForme3.Name = "NUP_GoodForme3";
        this.NUP_GoodForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodForme3.TabIndex = 318;
        // 
        // NUP_GoodMin3
        // 
        this.NUP_GoodMin3.Location = new System.Drawing.Point(517, 84);
        this.NUP_GoodMin3.Name = "NUP_GoodMin3";
        this.NUP_GoodMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodMin3.TabIndex = 319;
        // 
        // NUP_GoodMax3
        // 
        this.NUP_GoodMax3.Location = new System.Drawing.Point(564, 84);
        this.NUP_GoodMax3.Name = "NUP_GoodMax3";
        this.NUP_GoodMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_GoodMax3.TabIndex = 320;
        // 
        // label27
        // 
        this.label27.AutoSize = true;
        this.label27.Location = new System.Drawing.Point(316, 86);
        this.label27.Name = "label27";
        this.label27.Size = new System.Drawing.Size(21, 13);
        this.label27.TabIndex = 327;
        this.label27.Text = "5%";
        // 
        // label28
        // 
        this.label28.AutoSize = true;
        this.label28.Location = new System.Drawing.Point(310, 59);
        this.label28.Name = "label28";
        this.label28.Size = new System.Drawing.Size(27, 13);
        this.label28.TabIndex = 326;
        this.label28.Text = "35%";
        // 
        // label29
        // 
        this.label29.AutoSize = true;
        this.label29.Location = new System.Drawing.Point(310, 32);
        this.label29.Name = "label29";
        this.label29.Size = new System.Drawing.Size(27, 13);
        this.label29.TabIndex = 325;
        this.label29.Text = "60%";
        // 
        // label30
        // 
        this.label30.AutoSize = true;
        this.label30.Location = new System.Drawing.Point(467, 14);
        this.label30.Name = "label30";
        this.label30.Size = new System.Drawing.Size(36, 13);
        this.label30.TabIndex = 322;
        this.label30.Text = "Forme";
        // 
        // label46
        // 
        this.label46.AutoSize = true;
        this.label46.Location = new System.Drawing.Point(514, 14);
        this.label46.Name = "label46";
        this.label46.Size = new System.Drawing.Size(24, 13);
        this.label46.TabIndex = 323;
        this.label46.Text = "Min";
        // 
        // label47
        // 
        this.label47.AutoSize = true;
        this.label47.Location = new System.Drawing.Point(561, 14);
        this.label47.Name = "label47";
        this.label47.Size = new System.Drawing.Size(27, 13);
        this.label47.TabIndex = 324;
        this.label47.Text = "Max";
        // 
        // label22
        // 
        this.label22.AutoSize = true;
        this.label22.Location = new System.Drawing.Point(39, 13);
        this.label22.Name = "label22";
        this.label22.Size = new System.Drawing.Size(46, 13);
        this.label22.TabIndex = 302;
        this.label22.Text = "Old Rod";
        // 
        // CB_Old1
        // 
        this.CB_Old1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Old1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Old1.FormattingEnabled = true;
        this.CB_Old1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Old1.Location = new System.Drawing.Point(42, 29);
        this.CB_Old1.Name = "CB_Old1";
        this.CB_Old1.Size = new System.Drawing.Size(121, 21);
        this.CB_Old1.TabIndex = 290;
        // 
        // NUP_OldForme1
        // 
        this.NUP_OldForme1.Location = new System.Drawing.Point(169, 30);
        this.NUP_OldForme1.Name = "NUP_OldForme1";
        this.NUP_OldForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldForme1.TabIndex = 291;
        // 
        // NUP_OldMin1
        // 
        this.NUP_OldMin1.Location = new System.Drawing.Point(216, 30);
        this.NUP_OldMin1.Name = "NUP_OldMin1";
        this.NUP_OldMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldMin1.TabIndex = 292;
        // 
        // NUP_OldMax1
        // 
        this.NUP_OldMax1.Location = new System.Drawing.Point(263, 30);
        this.NUP_OldMax1.Name = "NUP_OldMax1";
        this.NUP_OldMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldMax1.TabIndex = 293;
        // 
        // CB_Old2
        // 
        this.CB_Old2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Old2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Old2.FormattingEnabled = true;
        this.CB_Old2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Old2.Location = new System.Drawing.Point(42, 56);
        this.CB_Old2.Name = "CB_Old2";
        this.CB_Old2.Size = new System.Drawing.Size(121, 21);
        this.CB_Old2.TabIndex = 294;
        // 
        // NUP_OldForme2
        // 
        this.NUP_OldForme2.Location = new System.Drawing.Point(169, 57);
        this.NUP_OldForme2.Name = "NUP_OldForme2";
        this.NUP_OldForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldForme2.TabIndex = 295;
        // 
        // NUP_OldMin2
        // 
        this.NUP_OldMin2.Location = new System.Drawing.Point(216, 57);
        this.NUP_OldMin2.Name = "NUP_OldMin2";
        this.NUP_OldMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldMin2.TabIndex = 296;
        // 
        // NUP_OldMax2
        // 
        this.NUP_OldMax2.Location = new System.Drawing.Point(263, 57);
        this.NUP_OldMax2.Name = "NUP_OldMax2";
        this.NUP_OldMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldMax2.TabIndex = 297;
        // 
        // CB_Old3
        // 
        this.CB_Old3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Old3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Old3.FormattingEnabled = true;
        this.CB_Old3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_Old3.Location = new System.Drawing.Point(42, 83);
        this.CB_Old3.Name = "CB_Old3";
        this.CB_Old3.Size = new System.Drawing.Size(121, 21);
        this.CB_Old3.TabIndex = 298;
        // 
        // NUP_OldForme3
        // 
        this.NUP_OldForme3.Location = new System.Drawing.Point(169, 84);
        this.NUP_OldForme3.Name = "NUP_OldForme3";
        this.NUP_OldForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldForme3.TabIndex = 299;
        // 
        // NUP_OldMin3
        // 
        this.NUP_OldMin3.Location = new System.Drawing.Point(216, 84);
        this.NUP_OldMin3.Name = "NUP_OldMin3";
        this.NUP_OldMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldMin3.TabIndex = 300;
        // 
        // NUP_OldMax3
        // 
        this.NUP_OldMax3.Location = new System.Drawing.Point(263, 84);
        this.NUP_OldMax3.Name = "NUP_OldMax3";
        this.NUP_OldMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_OldMax3.TabIndex = 301;
        // 
        // label45
        // 
        this.label45.AutoSize = true;
        this.label45.Location = new System.Drawing.Point(15, 86);
        this.label45.Name = "label45";
        this.label45.Size = new System.Drawing.Size(21, 13);
        this.label45.TabIndex = 308;
        this.label45.Text = "5%";
        // 
        // label44
        // 
        this.label44.AutoSize = true;
        this.label44.Location = new System.Drawing.Point(9, 59);
        this.label44.Name = "label44";
        this.label44.Size = new System.Drawing.Size(27, 13);
        this.label44.TabIndex = 307;
        this.label44.Text = "35%";
        // 
        // label43
        // 
        this.label43.AutoSize = true;
        this.label43.Location = new System.Drawing.Point(9, 32);
        this.label43.Name = "label43";
        this.label43.Size = new System.Drawing.Size(27, 13);
        this.label43.TabIndex = 306;
        this.label43.Text = "60%";
        // 
        // label23
        // 
        this.label23.AutoSize = true;
        this.label23.Location = new System.Drawing.Point(166, 14);
        this.label23.Name = "label23";
        this.label23.Size = new System.Drawing.Size(36, 13);
        this.label23.TabIndex = 303;
        this.label23.Text = "Forme";
        // 
        // label24
        // 
        this.label24.AutoSize = true;
        this.label24.Location = new System.Drawing.Point(213, 14);
        this.label24.Name = "label24";
        this.label24.Size = new System.Drawing.Size(24, 13);
        this.label24.TabIndex = 304;
        this.label24.Text = "Min";
        // 
        // label25
        // 
        this.label25.AutoSize = true;
        this.label25.Location = new System.Drawing.Point(260, 14);
        this.label25.Name = "label25";
        this.label25.Size = new System.Drawing.Size(27, 13);
        this.label25.TabIndex = 305;
        this.label25.Text = "Max";
        // 
        // TabPage_Horde
        // 
        this.TabPage_Horde.Controls.Add(this.GB_Tweak);
        this.TabPage_Horde.Controls.Add(this.label129);
        this.TabPage_Horde.Controls.Add(this.label130);
        this.TabPage_Horde.Controls.Add(this.label131);
        this.TabPage_Horde.Controls.Add(this.label132);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMax5);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMin5);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCForme5);
        this.TabPage_Horde.Controls.Add(this.CB_HordeC5);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMax4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMin4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCForme4);
        this.TabPage_Horde.Controls.Add(this.CB_HordeC4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMax3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMin3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCForme3);
        this.TabPage_Horde.Controls.Add(this.CB_HordeC3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMax2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMin2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCForme2);
        this.TabPage_Horde.Controls.Add(this.CB_HordeC2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMax1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCMin1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeCForme1);
        this.TabPage_Horde.Controls.Add(this.CB_HordeC1);
        this.TabPage_Horde.Controls.Add(this.label125);
        this.TabPage_Horde.Controls.Add(this.label121);
        this.TabPage_Horde.Controls.Add(this.label126);
        this.TabPage_Horde.Controls.Add(this.label124);
        this.TabPage_Horde.Controls.Add(this.label127);
        this.TabPage_Horde.Controls.Add(this.label122);
        this.TabPage_Horde.Controls.Add(this.label128);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMax5);
        this.TabPage_Horde.Controls.Add(this.CB_HordeA1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMin5);
        this.TabPage_Horde.Controls.Add(this.label123);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBForme5);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAForme1);
        this.TabPage_Horde.Controls.Add(this.CB_HordeB5);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMin1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMax4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMax5);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMin4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMax1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBForme4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMin5);
        this.TabPage_Horde.Controls.Add(this.CB_HordeB4);
        this.TabPage_Horde.Controls.Add(this.CB_HordeA2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMax3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAForme5);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMin3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAForme2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBForme3);
        this.TabPage_Horde.Controls.Add(this.CB_HordeA5);
        this.TabPage_Horde.Controls.Add(this.CB_HordeB3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMin2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMax2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMax4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMin2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMax2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBForme2);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMin4);
        this.TabPage_Horde.Controls.Add(this.CB_HordeB2);
        this.TabPage_Horde.Controls.Add(this.CB_HordeA3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMax1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAForme4);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBMin1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAForme3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeBForme1);
        this.TabPage_Horde.Controls.Add(this.CB_HordeA4);
        this.TabPage_Horde.Controls.Add(this.CB_HordeB1);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMin3);
        this.TabPage_Horde.Controls.Add(this.NUP_HordeAMax3);
        this.TabPage_Horde.Location = new System.Drawing.Point(4, 22);
        this.TabPage_Horde.Name = "TabPage_Horde";
        this.TabPage_Horde.Padding = new System.Windows.Forms.Padding(3);
        this.TabPage_Horde.Size = new System.Drawing.Size(918, 369);
        this.TabPage_Horde.TabIndex = 2;
        this.TabPage_Horde.Text = "Horde";
        this.TabPage_Horde.UseVisualStyleBackColor = true;
        // 
        // GB_Tweak
        // 
        this.GB_Tweak.Controls.Add(this.CHK_HomogeneousHordes);
        this.GB_Tweak.Controls.Add(this.CHK_MegaForm);
        this.GB_Tweak.Controls.Add(this.L_RandOpt);
        this.GB_Tweak.Controls.Add(this.CHK_BST);
        this.GB_Tweak.Controls.Add(this.CHK_E);
        this.GB_Tweak.Controls.Add(this.CHK_L);
        this.GB_Tweak.Controls.Add(this.CHK_G6);
        this.GB_Tweak.Controls.Add(this.CHK_G5);
        this.GB_Tweak.Controls.Add(this.CHK_G4);
        this.GB_Tweak.Controls.Add(this.CHK_G3);
        this.GB_Tweak.Controls.Add(this.CHK_G2);
        this.GB_Tweak.Controls.Add(this.CHK_G1);
        this.GB_Tweak.Controls.Add(this.B_LevelPlus);
        this.GB_Tweak.Controls.Add(this.NUD_LevelAmp);
        this.GB_Tweak.Controls.Add(this.CHK_Level);
        this.GB_Tweak.Location = new System.Drawing.Point(341, 243);
        this.GB_Tweak.Name = "GB_Tweak";
        this.GB_Tweak.Size = new System.Drawing.Size(282, 120);
        this.GB_Tweak.TabIndex = 323;
        this.GB_Tweak.TabStop = false;
        this.GB_Tweak.Text = "Extra Tweaks";
        // 
        // CHK_HomogeneousHordes
        // 
        this.CHK_HomogeneousHordes.AutoSize = true;
        this.CHK_HomogeneousHordes.Location = new System.Drawing.Point(18, 97);
        this.CHK_HomogeneousHordes.Name = "CHK_HomogeneousHordes";
        this.CHK_HomogeneousHordes.Size = new System.Drawing.Size(133, 17);
        this.CHK_HomogeneousHordes.TabIndex = 297;
        this.CHK_HomogeneousHordes.Text = "Single Species Hordes";
        this.CHK_HomogeneousHordes.UseVisualStyleBackColor = true;
        // 
        // CHK_MegaForm
        // 
        this.CHK_MegaForm.AutoSize = true;
        this.CHK_MegaForm.Location = new System.Drawing.Point(152, 97);
        this.CHK_MegaForm.Name = "CHK_MegaForm";
        this.CHK_MegaForm.Size = new System.Drawing.Size(127, 17);
        this.CHK_MegaForm.TabIndex = 296;
        this.CHK_MegaForm.Text = "Random Mega Forms";
        this.CHK_MegaForm.UseVisualStyleBackColor = true;
        // 
        // L_RandOpt
        // 
        this.L_RandOpt.AutoSize = true;
        this.L_RandOpt.Location = new System.Drawing.Point(30, 34);
        this.L_RandOpt.Name = "L_RandOpt";
        this.L_RandOpt.Size = new System.Drawing.Size(105, 13);
        this.L_RandOpt.TabIndex = 294;
        this.L_RandOpt.Text = "Randomizer Options:";
        // 
        // CHK_BST
        // 
        this.CHK_BST.AutoSize = true;
        this.CHK_BST.Location = new System.Drawing.Point(152, 82);
        this.CHK_BST.Name = "CHK_BST";
        this.CHK_BST.Size = new System.Drawing.Size(117, 17);
        this.CHK_BST.TabIndex = 288;
        this.CHK_BST.Text = "Randomize by BST";
        this.CHK_BST.UseVisualStyleBackColor = true;
        // 
        // CHK_E
        // 
        this.CHK_E.AutoSize = true;
        this.CHK_E.Checked = true;
        this.CHK_E.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_E.Location = new System.Drawing.Point(152, 67);
        this.CHK_E.Name = "CHK_E";
        this.CHK_E.Size = new System.Drawing.Size(98, 17);
        this.CHK_E.TabIndex = 287;
        this.CHK_E.Text = "Event Legends";
        this.CHK_E.UseVisualStyleBackColor = true;
        // 
        // CHK_L
        // 
        this.CHK_L.AutoSize = true;
        this.CHK_L.Checked = true;
        this.CHK_L.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_L.Location = new System.Drawing.Point(152, 52);
        this.CHK_L.Name = "CHK_L";
        this.CHK_L.Size = new System.Drawing.Size(98, 17);
        this.CHK_L.TabIndex = 286;
        this.CHK_L.Text = "Game Legends";
        this.CHK_L.UseVisualStyleBackColor = true;
        // 
        // CHK_G6
        // 
        this.CHK_G6.AutoSize = true;
        this.CHK_G6.Checked = true;
        this.CHK_G6.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G6.Location = new System.Drawing.Point(91, 82);
        this.CHK_G6.Name = "CHK_G6";
        this.CHK_G6.Size = new System.Drawing.Size(55, 17);
        this.CHK_G6.TabIndex = 285;
        this.CHK_G6.Text = "Gen 6";
        this.CHK_G6.UseVisualStyleBackColor = true;
        // 
        // CHK_G5
        // 
        this.CHK_G5.AutoSize = true;
        this.CHK_G5.Checked = true;
        this.CHK_G5.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G5.Location = new System.Drawing.Point(91, 67);
        this.CHK_G5.Name = "CHK_G5";
        this.CHK_G5.Size = new System.Drawing.Size(55, 17);
        this.CHK_G5.TabIndex = 284;
        this.CHK_G5.Text = "Gen 5";
        this.CHK_G5.UseVisualStyleBackColor = true;
        // 
        // CHK_G4
        // 
        this.CHK_G4.AutoSize = true;
        this.CHK_G4.Checked = true;
        this.CHK_G4.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G4.Location = new System.Drawing.Point(91, 52);
        this.CHK_G4.Name = "CHK_G4";
        this.CHK_G4.Size = new System.Drawing.Size(55, 17);
        this.CHK_G4.TabIndex = 283;
        this.CHK_G4.Text = "Gen 4";
        this.CHK_G4.UseVisualStyleBackColor = true;
        // 
        // CHK_G3
        // 
        this.CHK_G3.AutoSize = true;
        this.CHK_G3.Checked = true;
        this.CHK_G3.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G3.Location = new System.Drawing.Point(33, 82);
        this.CHK_G3.Name = "CHK_G3";
        this.CHK_G3.Size = new System.Drawing.Size(55, 17);
        this.CHK_G3.TabIndex = 282;
        this.CHK_G3.Text = "Gen 3";
        this.CHK_G3.UseVisualStyleBackColor = true;
        // 
        // CHK_G2
        // 
        this.CHK_G2.AutoSize = true;
        this.CHK_G2.Checked = true;
        this.CHK_G2.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G2.Location = new System.Drawing.Point(33, 67);
        this.CHK_G2.Name = "CHK_G2";
        this.CHK_G2.Size = new System.Drawing.Size(55, 17);
        this.CHK_G2.TabIndex = 281;
        this.CHK_G2.Text = "Gen 2";
        this.CHK_G2.UseVisualStyleBackColor = true;
        // 
        // CHK_G1
        // 
        this.CHK_G1.AutoSize = true;
        this.CHK_G1.Checked = true;
        this.CHK_G1.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G1.Location = new System.Drawing.Point(33, 52);
        this.CHK_G1.Name = "CHK_G1";
        this.CHK_G1.Size = new System.Drawing.Size(55, 17);
        this.CHK_G1.TabIndex = 280;
        this.CHK_G1.Text = "Gen 1";
        this.CHK_G1.UseVisualStyleBackColor = true;
        // 
        // B_LevelPlus
        // 
        this.B_LevelPlus.Location = new System.Drawing.Point(199, 14);
        this.B_LevelPlus.Name = "B_LevelPlus";
        this.B_LevelPlus.Size = new System.Drawing.Size(70, 23);
        this.B_LevelPlus.TabIndex = 277;
        this.B_LevelPlus.Text = "× Current";
        this.B_LevelPlus.UseVisualStyleBackColor = true;
        this.B_LevelPlus.Click += new System.EventHandler(this.ModifyLevels);
        // 
        // NUD_LevelAmp
        // 
        this.NUD_LevelAmp.DecimalPlaces = 2;
        this.NUD_LevelAmp.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
        this.NUD_LevelAmp.Location = new System.Drawing.Point(152, 16);
        this.NUD_LevelAmp.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
        this.NUD_LevelAmp.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
        this.NUD_LevelAmp.Name = "NUD_LevelAmp";
        this.NUD_LevelAmp.Size = new System.Drawing.Size(41, 20);
        this.NUD_LevelAmp.TabIndex = 276;
        this.NUD_LevelAmp.Value = new decimal(new int[] {
            10,
            0,
            0,
            65536});
        // 
        // CHK_Level
        // 
        this.CHK_Level.AutoSize = true;
        this.CHK_Level.Location = new System.Drawing.Point(18, 17);
        this.CHK_Level.Name = "CHK_Level";
        this.CHK_Level.Size = new System.Drawing.Size(135, 17);
        this.CHK_Level.TabIndex = 279;
        this.CHK_Level.Text = "Multiply PKM Levels by";
        this.CHK_Level.UseVisualStyleBackColor = true;
        // 
        // label129
        // 
        this.label129.AutoSize = true;
        this.label129.Location = new System.Drawing.Point(825, 13);
        this.label129.Name = "label129";
        this.label129.Size = new System.Drawing.Size(27, 13);
        this.label129.TabIndex = 320;
        this.label129.Text = "Max";
        // 
        // label130
        // 
        this.label130.AutoSize = true;
        this.label130.Location = new System.Drawing.Point(778, 13);
        this.label130.Name = "label130";
        this.label130.Size = new System.Drawing.Size(24, 13);
        this.label130.TabIndex = 319;
        this.label130.Text = "Min";
        // 
        // label131
        // 
        this.label131.AutoSize = true;
        this.label131.Location = new System.Drawing.Point(731, 13);
        this.label131.Name = "label131";
        this.label131.Size = new System.Drawing.Size(36, 13);
        this.label131.TabIndex = 318;
        this.label131.Text = "Forme";
        // 
        // label132
        // 
        this.label132.AutoSize = true;
        this.label132.Location = new System.Drawing.Point(607, 13);
        this.label132.Name = "label132";
        this.label132.Size = new System.Drawing.Size(69, 13);
        this.label132.TabIndex = 317;
        this.label132.Text = "Horde C (5%)";
        // 
        // NUP_HordeCMax5
        // 
        this.NUP_HordeCMax5.Location = new System.Drawing.Point(828, 138);
        this.NUP_HordeCMax5.Name = "NUP_HordeCMax5";
        this.NUP_HordeCMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMax5.TabIndex = 316;
        // 
        // NUP_HordeCMin5
        // 
        this.NUP_HordeCMin5.Location = new System.Drawing.Point(781, 138);
        this.NUP_HordeCMin5.Name = "NUP_HordeCMin5";
        this.NUP_HordeCMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMin5.TabIndex = 315;
        // 
        // NUP_HordeCForme5
        // 
        this.NUP_HordeCForme5.Location = new System.Drawing.Point(734, 138);
        this.NUP_HordeCForme5.Name = "NUP_HordeCForme5";
        this.NUP_HordeCForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCForme5.TabIndex = 314;
        // 
        // CB_HordeC5
        // 
        this.CB_HordeC5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeC5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeC5.FormattingEnabled = true;
        this.CB_HordeC5.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeC5.Location = new System.Drawing.Point(607, 137);
        this.CB_HordeC5.Name = "CB_HordeC5";
        this.CB_HordeC5.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeC5.TabIndex = 313;
        // 
        // NUP_HordeCMax4
        // 
        this.NUP_HordeCMax4.Location = new System.Drawing.Point(828, 111);
        this.NUP_HordeCMax4.Name = "NUP_HordeCMax4";
        this.NUP_HordeCMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMax4.TabIndex = 312;
        // 
        // NUP_HordeCMin4
        // 
        this.NUP_HordeCMin4.Location = new System.Drawing.Point(781, 111);
        this.NUP_HordeCMin4.Name = "NUP_HordeCMin4";
        this.NUP_HordeCMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMin4.TabIndex = 311;
        // 
        // NUP_HordeCForme4
        // 
        this.NUP_HordeCForme4.Location = new System.Drawing.Point(734, 111);
        this.NUP_HordeCForme4.Name = "NUP_HordeCForme4";
        this.NUP_HordeCForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCForme4.TabIndex = 310;
        // 
        // CB_HordeC4
        // 
        this.CB_HordeC4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeC4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeC4.FormattingEnabled = true;
        this.CB_HordeC4.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeC4.Location = new System.Drawing.Point(607, 110);
        this.CB_HordeC4.Name = "CB_HordeC4";
        this.CB_HordeC4.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeC4.TabIndex = 309;
        // 
        // NUP_HordeCMax3
        // 
        this.NUP_HordeCMax3.Location = new System.Drawing.Point(828, 84);
        this.NUP_HordeCMax3.Name = "NUP_HordeCMax3";
        this.NUP_HordeCMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMax3.TabIndex = 308;
        // 
        // NUP_HordeCMin3
        // 
        this.NUP_HordeCMin3.Location = new System.Drawing.Point(781, 84);
        this.NUP_HordeCMin3.Name = "NUP_HordeCMin3";
        this.NUP_HordeCMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMin3.TabIndex = 307;
        // 
        // NUP_HordeCForme3
        // 
        this.NUP_HordeCForme3.Location = new System.Drawing.Point(734, 84);
        this.NUP_HordeCForme3.Name = "NUP_HordeCForme3";
        this.NUP_HordeCForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCForme3.TabIndex = 306;
        // 
        // CB_HordeC3
        // 
        this.CB_HordeC3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeC3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeC3.FormattingEnabled = true;
        this.CB_HordeC3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeC3.Location = new System.Drawing.Point(607, 83);
        this.CB_HordeC3.Name = "CB_HordeC3";
        this.CB_HordeC3.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeC3.TabIndex = 305;
        // 
        // NUP_HordeCMax2
        // 
        this.NUP_HordeCMax2.Location = new System.Drawing.Point(828, 57);
        this.NUP_HordeCMax2.Name = "NUP_HordeCMax2";
        this.NUP_HordeCMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMax2.TabIndex = 304;
        // 
        // NUP_HordeCMin2
        // 
        this.NUP_HordeCMin2.Location = new System.Drawing.Point(781, 57);
        this.NUP_HordeCMin2.Name = "NUP_HordeCMin2";
        this.NUP_HordeCMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMin2.TabIndex = 303;
        // 
        // NUP_HordeCForme2
        // 
        this.NUP_HordeCForme2.Location = new System.Drawing.Point(734, 57);
        this.NUP_HordeCForme2.Name = "NUP_HordeCForme2";
        this.NUP_HordeCForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCForme2.TabIndex = 302;
        // 
        // CB_HordeC2
        // 
        this.CB_HordeC2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeC2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeC2.FormattingEnabled = true;
        this.CB_HordeC2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeC2.Location = new System.Drawing.Point(607, 56);
        this.CB_HordeC2.Name = "CB_HordeC2";
        this.CB_HordeC2.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeC2.TabIndex = 301;
        // 
        // NUP_HordeCMax1
        // 
        this.NUP_HordeCMax1.Location = new System.Drawing.Point(828, 30);
        this.NUP_HordeCMax1.Name = "NUP_HordeCMax1";
        this.NUP_HordeCMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMax1.TabIndex = 300;
        // 
        // NUP_HordeCMin1
        // 
        this.NUP_HordeCMin1.Location = new System.Drawing.Point(781, 30);
        this.NUP_HordeCMin1.Name = "NUP_HordeCMin1";
        this.NUP_HordeCMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCMin1.TabIndex = 299;
        // 
        // NUP_HordeCForme1
        // 
        this.NUP_HordeCForme1.Location = new System.Drawing.Point(734, 30);
        this.NUP_HordeCForme1.Name = "NUP_HordeCForme1";
        this.NUP_HordeCForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeCForme1.TabIndex = 298;
        // 
        // CB_HordeC1
        // 
        this.CB_HordeC1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeC1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeC1.FormattingEnabled = true;
        this.CB_HordeC1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeC1.Location = new System.Drawing.Point(607, 29);
        this.CB_HordeC1.Name = "CB_HordeC1";
        this.CB_HordeC1.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeC1.TabIndex = 297;
        // 
        // label125
        // 
        this.label125.AutoSize = true;
        this.label125.Location = new System.Drawing.Point(530, 13);
        this.label125.Name = "label125";
        this.label125.Size = new System.Drawing.Size(27, 13);
        this.label125.TabIndex = 296;
        this.label125.Text = "Max";
        // 
        // label121
        // 
        this.label121.AutoSize = true;
        this.label121.Location = new System.Drawing.Point(234, 13);
        this.label121.Name = "label121";
        this.label121.Size = new System.Drawing.Size(27, 13);
        this.label121.TabIndex = 296;
        this.label121.Text = "Max";
        // 
        // label126
        // 
        this.label126.AutoSize = true;
        this.label126.Location = new System.Drawing.Point(483, 13);
        this.label126.Name = "label126";
        this.label126.Size = new System.Drawing.Size(24, 13);
        this.label126.TabIndex = 295;
        this.label126.Text = "Min";
        // 
        // label124
        // 
        this.label124.AutoSize = true;
        this.label124.Location = new System.Drawing.Point(16, 13);
        this.label124.Name = "label124";
        this.label124.Size = new System.Drawing.Size(75, 13);
        this.label124.TabIndex = 293;
        this.label124.Text = "Horde A (60%)";
        // 
        // label127
        // 
        this.label127.AutoSize = true;
        this.label127.Location = new System.Drawing.Point(436, 13);
        this.label127.Name = "label127";
        this.label127.Size = new System.Drawing.Size(36, 13);
        this.label127.TabIndex = 294;
        this.label127.Text = "Forme";
        // 
        // label122
        // 
        this.label122.AutoSize = true;
        this.label122.Location = new System.Drawing.Point(187, 13);
        this.label122.Name = "label122";
        this.label122.Size = new System.Drawing.Size(24, 13);
        this.label122.TabIndex = 295;
        this.label122.Text = "Min";
        // 
        // label128
        // 
        this.label128.AutoSize = true;
        this.label128.Location = new System.Drawing.Point(312, 13);
        this.label128.Name = "label128";
        this.label128.Size = new System.Drawing.Size(75, 13);
        this.label128.TabIndex = 293;
        this.label128.Text = "Horde B (35%)";
        // 
        // NUP_HordeBMax5
        // 
        this.NUP_HordeBMax5.Location = new System.Drawing.Point(533, 138);
        this.NUP_HordeBMax5.Name = "NUP_HordeBMax5";
        this.NUP_HordeBMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMax5.TabIndex = 292;
        // 
        // CB_HordeA1
        // 
        this.CB_HordeA1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeA1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeA1.FormattingEnabled = true;
        this.CB_HordeA1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeA1.Location = new System.Drawing.Point(16, 29);
        this.CB_HordeA1.Name = "CB_HordeA1";
        this.CB_HordeA1.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeA1.TabIndex = 273;
        // 
        // NUP_HordeBMin5
        // 
        this.NUP_HordeBMin5.Location = new System.Drawing.Point(486, 138);
        this.NUP_HordeBMin5.Name = "NUP_HordeBMin5";
        this.NUP_HordeBMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMin5.TabIndex = 291;
        // 
        // label123
        // 
        this.label123.AutoSize = true;
        this.label123.Location = new System.Drawing.Point(140, 13);
        this.label123.Name = "label123";
        this.label123.Size = new System.Drawing.Size(36, 13);
        this.label123.TabIndex = 294;
        this.label123.Text = "Forme";
        // 
        // NUP_HordeBForme5
        // 
        this.NUP_HordeBForme5.Location = new System.Drawing.Point(439, 138);
        this.NUP_HordeBForme5.Name = "NUP_HordeBForme5";
        this.NUP_HordeBForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBForme5.TabIndex = 290;
        // 
        // NUP_HordeAForme1
        // 
        this.NUP_HordeAForme1.Location = new System.Drawing.Point(143, 30);
        this.NUP_HordeAForme1.Name = "NUP_HordeAForme1";
        this.NUP_HordeAForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAForme1.TabIndex = 274;
        // 
        // CB_HordeB5
        // 
        this.CB_HordeB5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeB5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeB5.FormattingEnabled = true;
        this.CB_HordeB5.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeB5.Location = new System.Drawing.Point(312, 137);
        this.CB_HordeB5.Name = "CB_HordeB5";
        this.CB_HordeB5.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeB5.TabIndex = 289;
        // 
        // NUP_HordeAMin1
        // 
        this.NUP_HordeAMin1.Location = new System.Drawing.Point(190, 30);
        this.NUP_HordeAMin1.Name = "NUP_HordeAMin1";
        this.NUP_HordeAMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMin1.TabIndex = 275;
        // 
        // NUP_HordeBMax4
        // 
        this.NUP_HordeBMax4.Location = new System.Drawing.Point(533, 111);
        this.NUP_HordeBMax4.Name = "NUP_HordeBMax4";
        this.NUP_HordeBMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMax4.TabIndex = 288;
        // 
        // NUP_HordeAMax5
        // 
        this.NUP_HordeAMax5.Location = new System.Drawing.Point(237, 138);
        this.NUP_HordeAMax5.Name = "NUP_HordeAMax5";
        this.NUP_HordeAMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMax5.TabIndex = 292;
        // 
        // NUP_HordeBMin4
        // 
        this.NUP_HordeBMin4.Location = new System.Drawing.Point(486, 111);
        this.NUP_HordeBMin4.Name = "NUP_HordeBMin4";
        this.NUP_HordeBMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMin4.TabIndex = 287;
        // 
        // NUP_HordeAMax1
        // 
        this.NUP_HordeAMax1.Location = new System.Drawing.Point(237, 30);
        this.NUP_HordeAMax1.Name = "NUP_HordeAMax1";
        this.NUP_HordeAMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMax1.TabIndex = 276;
        // 
        // NUP_HordeBForme4
        // 
        this.NUP_HordeBForme4.Location = new System.Drawing.Point(439, 111);
        this.NUP_HordeBForme4.Name = "NUP_HordeBForme4";
        this.NUP_HordeBForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBForme4.TabIndex = 286;
        // 
        // NUP_HordeAMin5
        // 
        this.NUP_HordeAMin5.Location = new System.Drawing.Point(190, 138);
        this.NUP_HordeAMin5.Name = "NUP_HordeAMin5";
        this.NUP_HordeAMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMin5.TabIndex = 291;
        // 
        // CB_HordeB4
        // 
        this.CB_HordeB4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeB4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeB4.FormattingEnabled = true;
        this.CB_HordeB4.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeB4.Location = new System.Drawing.Point(312, 110);
        this.CB_HordeB4.Name = "CB_HordeB4";
        this.CB_HordeB4.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeB4.TabIndex = 285;
        // 
        // CB_HordeA2
        // 
        this.CB_HordeA2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeA2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeA2.FormattingEnabled = true;
        this.CB_HordeA2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeA2.Location = new System.Drawing.Point(16, 56);
        this.CB_HordeA2.Name = "CB_HordeA2";
        this.CB_HordeA2.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeA2.TabIndex = 277;
        // 
        // NUP_HordeBMax3
        // 
        this.NUP_HordeBMax3.Location = new System.Drawing.Point(533, 84);
        this.NUP_HordeBMax3.Name = "NUP_HordeBMax3";
        this.NUP_HordeBMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMax3.TabIndex = 284;
        // 
        // NUP_HordeAForme5
        // 
        this.NUP_HordeAForme5.Location = new System.Drawing.Point(143, 138);
        this.NUP_HordeAForme5.Name = "NUP_HordeAForme5";
        this.NUP_HordeAForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAForme5.TabIndex = 290;
        // 
        // NUP_HordeBMin3
        // 
        this.NUP_HordeBMin3.Location = new System.Drawing.Point(486, 84);
        this.NUP_HordeBMin3.Name = "NUP_HordeBMin3";
        this.NUP_HordeBMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMin3.TabIndex = 283;
        // 
        // NUP_HordeAForme2
        // 
        this.NUP_HordeAForme2.Location = new System.Drawing.Point(143, 57);
        this.NUP_HordeAForme2.Name = "NUP_HordeAForme2";
        this.NUP_HordeAForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAForme2.TabIndex = 278;
        // 
        // NUP_HordeBForme3
        // 
        this.NUP_HordeBForme3.Location = new System.Drawing.Point(439, 84);
        this.NUP_HordeBForme3.Name = "NUP_HordeBForme3";
        this.NUP_HordeBForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBForme3.TabIndex = 282;
        // 
        // CB_HordeA5
        // 
        this.CB_HordeA5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeA5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeA5.FormattingEnabled = true;
        this.CB_HordeA5.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeA5.Location = new System.Drawing.Point(16, 137);
        this.CB_HordeA5.Name = "CB_HordeA5";
        this.CB_HordeA5.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeA5.TabIndex = 289;
        // 
        // CB_HordeB3
        // 
        this.CB_HordeB3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeB3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeB3.FormattingEnabled = true;
        this.CB_HordeB3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeB3.Location = new System.Drawing.Point(312, 83);
        this.CB_HordeB3.Name = "CB_HordeB3";
        this.CB_HordeB3.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeB3.TabIndex = 281;
        // 
        // NUP_HordeAMin2
        // 
        this.NUP_HordeAMin2.Location = new System.Drawing.Point(190, 57);
        this.NUP_HordeAMin2.Name = "NUP_HordeAMin2";
        this.NUP_HordeAMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMin2.TabIndex = 279;
        // 
        // NUP_HordeBMax2
        // 
        this.NUP_HordeBMax2.Location = new System.Drawing.Point(533, 57);
        this.NUP_HordeBMax2.Name = "NUP_HordeBMax2";
        this.NUP_HordeBMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMax2.TabIndex = 280;
        // 
        // NUP_HordeAMax4
        // 
        this.NUP_HordeAMax4.Location = new System.Drawing.Point(237, 111);
        this.NUP_HordeAMax4.Name = "NUP_HordeAMax4";
        this.NUP_HordeAMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMax4.TabIndex = 288;
        // 
        // NUP_HordeBMin2
        // 
        this.NUP_HordeBMin2.Location = new System.Drawing.Point(486, 57);
        this.NUP_HordeBMin2.Name = "NUP_HordeBMin2";
        this.NUP_HordeBMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMin2.TabIndex = 279;
        // 
        // NUP_HordeAMax2
        // 
        this.NUP_HordeAMax2.Location = new System.Drawing.Point(237, 57);
        this.NUP_HordeAMax2.Name = "NUP_HordeAMax2";
        this.NUP_HordeAMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMax2.TabIndex = 280;
        // 
        // NUP_HordeBForme2
        // 
        this.NUP_HordeBForme2.Location = new System.Drawing.Point(439, 57);
        this.NUP_HordeBForme2.Name = "NUP_HordeBForme2";
        this.NUP_HordeBForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBForme2.TabIndex = 278;
        // 
        // NUP_HordeAMin4
        // 
        this.NUP_HordeAMin4.Location = new System.Drawing.Point(190, 111);
        this.NUP_HordeAMin4.Name = "NUP_HordeAMin4";
        this.NUP_HordeAMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMin4.TabIndex = 287;
        // 
        // CB_HordeB2
        // 
        this.CB_HordeB2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeB2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeB2.FormattingEnabled = true;
        this.CB_HordeB2.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeB2.Location = new System.Drawing.Point(312, 56);
        this.CB_HordeB2.Name = "CB_HordeB2";
        this.CB_HordeB2.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeB2.TabIndex = 277;
        // 
        // CB_HordeA3
        // 
        this.CB_HordeA3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeA3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeA3.FormattingEnabled = true;
        this.CB_HordeA3.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeA3.Location = new System.Drawing.Point(16, 83);
        this.CB_HordeA3.Name = "CB_HordeA3";
        this.CB_HordeA3.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeA3.TabIndex = 281;
        // 
        // NUP_HordeBMax1
        // 
        this.NUP_HordeBMax1.Location = new System.Drawing.Point(533, 30);
        this.NUP_HordeBMax1.Name = "NUP_HordeBMax1";
        this.NUP_HordeBMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMax1.TabIndex = 276;
        // 
        // NUP_HordeAForme4
        // 
        this.NUP_HordeAForme4.Location = new System.Drawing.Point(143, 111);
        this.NUP_HordeAForme4.Name = "NUP_HordeAForme4";
        this.NUP_HordeAForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAForme4.TabIndex = 286;
        // 
        // NUP_HordeBMin1
        // 
        this.NUP_HordeBMin1.Location = new System.Drawing.Point(486, 30);
        this.NUP_HordeBMin1.Name = "NUP_HordeBMin1";
        this.NUP_HordeBMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBMin1.TabIndex = 275;
        // 
        // NUP_HordeAForme3
        // 
        this.NUP_HordeAForme3.Location = new System.Drawing.Point(143, 84);
        this.NUP_HordeAForme3.Name = "NUP_HordeAForme3";
        this.NUP_HordeAForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAForme3.TabIndex = 282;
        // 
        // NUP_HordeBForme1
        // 
        this.NUP_HordeBForme1.Location = new System.Drawing.Point(439, 30);
        this.NUP_HordeBForme1.Name = "NUP_HordeBForme1";
        this.NUP_HordeBForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeBForme1.TabIndex = 274;
        // 
        // CB_HordeA4
        // 
        this.CB_HordeA4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeA4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeA4.FormattingEnabled = true;
        this.CB_HordeA4.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeA4.Location = new System.Drawing.Point(16, 110);
        this.CB_HordeA4.Name = "CB_HordeA4";
        this.CB_HordeA4.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeA4.TabIndex = 285;
        // 
        // CB_HordeB1
        // 
        this.CB_HordeB1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_HordeB1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_HordeB1.FormattingEnabled = true;
        this.CB_HordeB1.Items.AddRange(new object[] {
            "-----",
            "Bulbasaur",
            "Ivysaur",
            "Venusaur",
            "Charmander",
            "Charmeleon",
            "Charizard",
            "Squirtle",
            "Wartortle",
            "Blastoise",
            "Caterpie",
            "Metapod",
            "Butterfree",
            "Weedle",
            "Kakuna",
            "Beedrill",
            "Pidgey",
            "Pidgeotto",
            "Pidgeot",
            "Rattata",
            "Raticate",
            "Spearow",
            "Fearow",
            "Ekans",
            "Arbok",
            "Pikachu",
            "Raichu",
            "Sandshrew",
            "Sandslash",
            "Nidoran♀",
            "Nidorina",
            "Nidoqueen",
            "Nidoran♂",
            "Nidorino",
            "Nidoking",
            "Clefairy",
            "Clefable",
            "Vulpix",
            "Ninetales",
            "Jigglypuff",
            "Wigglytuff",
            "Zubat",
            "Golbat",
            "Oddish",
            "Gloom",
            "Vileplume",
            "Paras",
            "Parasect",
            "Venonat",
            "Venomoth",
            "Diglett",
            "Dugtrio",
            "Meowth",
            "Persian",
            "Psyduck",
            "Golduck",
            "Mankey",
            "Primeape",
            "Growlithe",
            "Arcanine",
            "Poliwag",
            "Poliwhirl",
            "Poliwrath",
            "Abra",
            "Kadabra",
            "Alakazam",
            "Machop",
            "Machoke",
            "Machamp",
            "Bellsprout",
            "Weepinbell",
            "Victreebel",
            "Tentacool",
            "Tentacruel",
            "Geodude",
            "Graveler",
            "Golem",
            "Ponyta",
            "Rapidash",
            "Slowpoke",
            "Slowbro",
            "Magnemite",
            "Magneton",
            "Farfetch\'d",
            "Doduo",
            "Dodrio",
            "Seel",
            "Dewgong",
            "Grimer",
            "Muk",
            "Shellder",
            "Cloyster",
            "Gastly",
            "Haunter",
            "Gengar",
            "Onix",
            "Drowzee",
            "Hypno",
            "Krabby",
            "Kingler",
            "Voltorb",
            "Electrode",
            "Exeggcute",
            "Exeggutor",
            "Cubone",
            "Marowak",
            "Hitmonlee",
            "Hitmonchan",
            "Lickitung",
            "Koffing",
            "Weezing",
            "Rhyhorn",
            "Rhydon",
            "Chansey",
            "Tangela",
            "Kangaskhan",
            "Horsea",
            "Seadra",
            "Goldeen",
            "Seaking",
            "Staryu",
            "Starmie",
            "Mr. Mime",
            "Scyther",
            "Jynx",
            "Electabuzz",
            "Magmar",
            "Pinsir",
            "Tauros",
            "Magikarp",
            "Gyarados",
            "Lapras",
            "Ditto",
            "Eevee",
            "Vaporeon",
            "Jolteon",
            "Flareon",
            "Porygon",
            "Omanyte",
            "Omastar",
            "Kabuto",
            "Kabutops",
            "Aerodactyl",
            "Snorlax",
            "Articuno",
            "Zapdos",
            "Moltres",
            "Dratini",
            "Dragonair",
            "Dragonite",
            "Mewtwo",
            "Mew",
            "Chikorita",
            "Bayleef",
            "Meganium",
            "Cyndaquil",
            "Quilava",
            "Typhlosion",
            "Totodile",
            "Croconaw",
            "Feraligatr",
            "Sentret",
            "Furret",
            "Hoothoot",
            "Noctowl",
            "Ledyba",
            "Ledian",
            "Spinarak",
            "Ariados",
            "Crobat",
            "Chinchou",
            "Lanturn",
            "Pichu",
            "Cleffa",
            "Igglybuff",
            "Togepi",
            "Togetic",
            "Natu",
            "Xatu",
            "Mareep",
            "Flaaffy",
            "Ampharos",
            "Bellossom",
            "Marill",
            "Azumarill",
            "Sudowoodo",
            "Politoed",
            "Hoppip",
            "Skiploom",
            "Jumpluff",
            "Aipom",
            "Sunkern",
            "Sunflora",
            "Yanma",
            "Wooper",
            "Quagsire",
            "Espeon",
            "Umbreon",
            "Murkrow",
            "Slowking",
            "Misdreavus",
            "Unown",
            "Wobbuffet",
            "Girafarig",
            "Pineco",
            "Forretress",
            "Dunsparce",
            "Gligar",
            "Steelix",
            "Snubbull",
            "Granbull",
            "Qwilfish",
            "Scizor",
            "Shuckle",
            "Heracross",
            "Sneasel",
            "Teddiursa",
            "Ursaring",
            "Slugma",
            "Magcargo",
            "Swinub",
            "Piloswine",
            "Corsola",
            "Remoraid",
            "Octillery",
            "Delibird",
            "Mantine",
            "Skarmory",
            "Houndour",
            "Houndoom",
            "Kingdra",
            "Phanpy",
            "Donphan",
            "Porygon2",
            "Stantler",
            "Smeargle",
            "Tyrogue",
            "Hitmontop",
            "Smoochum",
            "Elekid",
            "Magby",
            "Miltank",
            "Blissey",
            "Raikou",
            "Entei",
            "Suicune",
            "Larvitar",
            "Pupitar",
            "Tyranitar",
            "Lugia",
            "Ho-Oh",
            "Celebi",
            "Treecko",
            "Grovyle",
            "Sceptile",
            "Torchic",
            "Combusken",
            "Blaziken",
            "Mudkip",
            "Marshtomp",
            "Swampert",
            "Poochyena",
            "Mightyena",
            "Zigzagoon",
            "Linoone",
            "Wurmple",
            "Silcoon",
            "Beautifly",
            "Cascoon",
            "Dustox",
            "Lotad",
            "Lombre",
            "Ludicolo",
            "Seedot",
            "Nuzleaf",
            "Shiftry",
            "Taillow",
            "Swellow",
            "Wingull",
            "Pelipper",
            "Ralts",
            "Kirlia",
            "Gardevoir",
            "Surskit",
            "Masquerain",
            "Shroomish",
            "Breloom",
            "Slakoth",
            "Vigoroth",
            "Slaking",
            "Nincada",
            "Ninjask",
            "Shedinja",
            "Whismur",
            "Loudred",
            "Exploud",
            "Makuhita",
            "Hariyama",
            "Azurill",
            "Nosepass",
            "Skitty",
            "Delcatty",
            "Sableye",
            "Mawile",
            "Aron",
            "Lairon",
            "Aggron",
            "Meditite",
            "Medicham",
            "Electrike",
            "Manectric",
            "Plusle",
            "Minun",
            "Volbeat",
            "Illumise",
            "Roselia",
            "Gulpin",
            "Swalot",
            "Carvanha",
            "Sharpedo",
            "Wailmer",
            "Wailord",
            "Numel",
            "Camerupt",
            "Torkoal",
            "Spoink",
            "Grumpig",
            "Spinda",
            "Trapinch",
            "Vibrava",
            "Flygon",
            "Cacnea",
            "Cacturne",
            "Swablu",
            "Altaria",
            "Zangoose",
            "Seviper",
            "Lunatone",
            "Solrock",
            "Barboach",
            "Whiscash",
            "Corphish",
            "Crawdaunt",
            "Baltoy",
            "Claydol",
            "Lileep",
            "Cradily",
            "Anorith",
            "Armaldo",
            "Feebas",
            "Milotic",
            "Castform",
            "Kecleon",
            "Shuppet",
            "Banette",
            "Duskull",
            "Dusclops",
            "Tropius",
            "Chimecho",
            "Absol",
            "Wynaut",
            "Snorunt",
            "Glalie",
            "Spheal",
            "Sealeo",
            "Walrein",
            "Clamperl",
            "Huntail",
            "Gorebyss",
            "Relicanth",
            "Luvdisc",
            "Bagon",
            "Shelgon",
            "Salamence",
            "Beldum",
            "Metang",
            "Metagross",
            "Regirock",
            "Regice",
            "Registeel",
            "Latias",
            "Latios",
            "Kyogre",
            "Groudon",
            "Rayquaza",
            "Jirachi",
            "Deoxys",
            "Turtwig",
            "Grotle",
            "Torterra",
            "Chimchar",
            "Monferno",
            "Infernape",
            "Piplup",
            "Prinplup",
            "Empoleon",
            "Starly",
            "Staravia",
            "Staraptor",
            "Bidoof",
            "Bibarel",
            "Kricketot",
            "Kricketune",
            "Shinx",
            "Luxio",
            "Luxray",
            "Budew",
            "Roserade",
            "Cranidos",
            "Rampardos",
            "Shieldon",
            "Bastiodon",
            "Burmy",
            "Wormadam",
            "Mothim",
            "Combee",
            "Vespiquen",
            "Pachirisu",
            "Buizel",
            "Floatzel",
            "Cherubi",
            "Cherrim",
            "Shellos",
            "Gastrodon",
            "Ambipom",
            "Drifloon",
            "Drifblim",
            "Buneary",
            "Lopunny",
            "Mismagius",
            "Honchkrow",
            "Glameow",
            "Purugly",
            "Chingling",
            "Stunky",
            "Skuntank",
            "Bronzor",
            "Bronzong",
            "Bonsly",
            "Mime Jr.",
            "Happiny",
            "Chatot",
            "Spiritomb",
            "Gible",
            "Gabite",
            "Garchomp",
            "Munchlax",
            "Riolu",
            "Lucario",
            "Hippopotas",
            "Hippowdon",
            "Skorupi",
            "Drapion",
            "Croagunk",
            "Toxicroak",
            "Carnivine",
            "Finneon",
            "Lumineon",
            "Mantyke",
            "Snover",
            "Abomasnow",
            "Weavile",
            "Magnezone",
            "Lickilicky",
            "Rhyperior",
            "Tangrowth",
            "Electivire",
            "Magmortar",
            "Togekiss",
            "Yanmega",
            "Leafeon",
            "Glaceon",
            "Gliscor",
            "Mamoswine",
            "Porygon-Z",
            "Gallade",
            "Probopass",
            "Dusknoir",
            "Froslass",
            "Rotom",
            "Uxie",
            "Mesprit",
            "Azelf",
            "Dialga",
            "Palkia",
            "Heatran",
            "Regigigas",
            "Giratina",
            "Cresselia",
            "Phione",
            "Manaphy",
            "Darkrai",
            "Shaymin",
            "Arceus",
            "Victini",
            "Snivy",
            "Servine",
            "Serperior",
            "Tepig",
            "Pignite",
            "Emboar",
            "Oshawott",
            "Dewott",
            "Samurott",
            "Patrat",
            "Watchog",
            "Lillipup",
            "Herdier",
            "Stoutland",
            "Purrloin",
            "Liepard",
            "Pansage",
            "Simisage",
            "Pansear",
            "Simisear",
            "Panpour",
            "Simipour",
            "Munna",
            "Musharna",
            "Pidove",
            "Tranquill",
            "Unfezant",
            "Blitzle",
            "Zebstrika",
            "Roggenrola",
            "Boldore",
            "Gigalith",
            "Woobat",
            "Swoobat",
            "Drilbur",
            "Excadrill",
            "Audino",
            "Timburr",
            "Gurdurr",
            "Conkeldurr",
            "Tympole",
            "Palpitoad",
            "Seismitoad",
            "Throh",
            "Sawk",
            "Sewaddle",
            "Swadloon",
            "Leavanny",
            "Venipede",
            "Whirlipede",
            "Scolipede",
            "Cottonee",
            "Whimsicott",
            "Petilil",
            "Lilligant",
            "Basculin",
            "Sandile",
            "Krokorok",
            "Krookodile",
            "Darumaka",
            "Darmanitan",
            "Maractus",
            "Dwebble",
            "Crustle",
            "Scraggy",
            "Scrafty",
            "Sigilyph",
            "Yamask",
            "Cofagrigus",
            "Tirtouga",
            "Carracosta",
            "Archen",
            "Archeops",
            "Trubbish",
            "Garbodor",
            "Zorua",
            "Zoroark",
            "Minccino",
            "Cinccino",
            "Gothita",
            "Gothorita",
            "Gothitelle",
            "Solosis",
            "Duosion",
            "Reuniclus",
            "Ducklett",
            "Swanna",
            "Vanillite",
            "Vanillish",
            "Vanilluxe",
            "Deerling",
            "Sawsbuck",
            "Emolga",
            "Karrablast",
            "Escavalier",
            "Foongus",
            "Amoonguss",
            "Frillish",
            "Jellicent",
            "Alomomola",
            "Joltik",
            "Galvantula",
            "Ferroseed",
            "Ferrothorn",
            "Klink",
            "Klang",
            "Klinklang",
            "Tynamo",
            "Eelektrik",
            "Eelektross",
            "Elgyem",
            "Beheeyem",
            "Litwick",
            "Lampent",
            "Chandelure",
            "Axew",
            "Fraxure",
            "Haxorus",
            "Cubchoo",
            "Beartic",
            "Cryogonal",
            "Shelmet",
            "Accelgor",
            "Stunfisk",
            "Mienfoo",
            "Mienshao",
            "Druddigon",
            "Golett",
            "Golurk",
            "Pawniard",
            "Bisharp",
            "Bouffalant",
            "Rufflet",
            "Braviary",
            "Vullaby",
            "Mandibuzz",
            "Heatmor",
            "Durant",
            "Deino",
            "Zweilous",
            "Hydreigon",
            "Larvesta",
            "Volcarona",
            "Cobalion",
            "Terrakion",
            "Virizion",
            "Tornadus",
            "Thundurus",
            "Reshiram",
            "Zekrom",
            "Landorus",
            "Kyurem",
            "Keldeo",
            "Meloetta",
            "Genesect"});
        this.CB_HordeB1.Location = new System.Drawing.Point(312, 29);
        this.CB_HordeB1.Name = "CB_HordeB1";
        this.CB_HordeB1.Size = new System.Drawing.Size(121, 21);
        this.CB_HordeB1.TabIndex = 273;
        // 
        // NUP_HordeAMin3
        // 
        this.NUP_HordeAMin3.Location = new System.Drawing.Point(190, 84);
        this.NUP_HordeAMin3.Name = "NUP_HordeAMin3";
        this.NUP_HordeAMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMin3.TabIndex = 283;
        // 
        // NUP_HordeAMax3
        // 
        this.NUP_HordeAMax3.Location = new System.Drawing.Point(237, 84);
        this.NUP_HordeAMax3.Name = "NUP_HordeAMax3";
        this.NUP_HordeAMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_HordeAMax3.TabIndex = 284;
        // 
        // tabPage1
        // 
        this.tabPage1.Controls.Add(this.NUP_RedForme11);
        this.tabPage1.Controls.Add(this.NUP_RedMin11);
        this.tabPage1.Controls.Add(this.NUP_RedMax11);
        this.tabPage1.Controls.Add(this.NUP_RedForme12);
        this.tabPage1.Controls.Add(this.NUP_RedMin12);
        this.tabPage1.Controls.Add(this.NUP_RedMax12);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme11);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin11);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax11);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme12);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin12);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax12);
        this.tabPage1.Controls.Add(this.NUP_YellowForme11);
        this.tabPage1.Controls.Add(this.NUP_YellowMin11);
        this.tabPage1.Controls.Add(this.NUP_YellowMax11);
        this.tabPage1.Controls.Add(this.NUP_YellowForme12);
        this.tabPage1.Controls.Add(this.NUP_YellowMin12);
        this.tabPage1.Controls.Add(this.NUP_YellowMax12);
        this.tabPage1.Controls.Add(this.NUP_RedForme1);
        this.tabPage1.Controls.Add(this.NUP_RedMin1);
        this.tabPage1.Controls.Add(this.label82);
        this.tabPage1.Controls.Add(this.NUP_RedMax1);
        this.tabPage1.Controls.Add(this.label83);
        this.tabPage1.Controls.Add(this.NUP_RedForme2);
        this.tabPage1.Controls.Add(this.label84);
        this.tabPage1.Controls.Add(this.NUP_RedMin2);
        this.tabPage1.Controls.Add(this.label85);
        this.tabPage1.Controls.Add(this.NUP_RedMax2);
        this.tabPage1.Controls.Add(this.CB_Purple12);
        this.tabPage1.Controls.Add(this.NUP_RedForme3);
        this.tabPage1.Controls.Add(this.CB_Purple11);
        this.tabPage1.Controls.Add(this.NUP_RedMin3);
        this.tabPage1.Controls.Add(this.CB_Purple10);
        this.tabPage1.Controls.Add(this.NUP_RedMax3);
        this.tabPage1.Controls.Add(this.CB_Purple9);
        this.tabPage1.Controls.Add(this.NUP_RedForme4);
        this.tabPage1.Controls.Add(this.CB_Purple8);
        this.tabPage1.Controls.Add(this.NUP_RedMin4);
        this.tabPage1.Controls.Add(this.CB_Purple7);
        this.tabPage1.Controls.Add(this.NUP_RedMax4);
        this.tabPage1.Controls.Add(this.CB_Purple6);
        this.tabPage1.Controls.Add(this.NUP_RedForme5);
        this.tabPage1.Controls.Add(this.CB_Purple5);
        this.tabPage1.Controls.Add(this.NUP_RedMin5);
        this.tabPage1.Controls.Add(this.CB_Purple4);
        this.tabPage1.Controls.Add(this.NUP_RedMax5);
        this.tabPage1.Controls.Add(this.CB_Purple3);
        this.tabPage1.Controls.Add(this.NUP_RedForme6);
        this.tabPage1.Controls.Add(this.CB_Purple2);
        this.tabPage1.Controls.Add(this.NUP_RedMin6);
        this.tabPage1.Controls.Add(this.CB_Purple1);
        this.tabPage1.Controls.Add(this.NUP_RedMax6);
        this.tabPage1.Controls.Add(this.label86);
        this.tabPage1.Controls.Add(this.NUP_RedForme7);
        this.tabPage1.Controls.Add(this.label87);
        this.tabPage1.Controls.Add(this.NUP_RedMin7);
        this.tabPage1.Controls.Add(this.label88);
        this.tabPage1.Controls.Add(this.NUP_RedMax7);
        this.tabPage1.Controls.Add(this.label89);
        this.tabPage1.Controls.Add(this.NUP_RedForme8);
        this.tabPage1.Controls.Add(this.label90);
        this.tabPage1.Controls.Add(this.NUP_RedMin8);
        this.tabPage1.Controls.Add(this.label91);
        this.tabPage1.Controls.Add(this.NUP_RedMax8);
        this.tabPage1.Controls.Add(this.label92);
        this.tabPage1.Controls.Add(this.NUP_RedForme9);
        this.tabPage1.Controls.Add(this.label93);
        this.tabPage1.Controls.Add(this.NUP_RedMin9);
        this.tabPage1.Controls.Add(this.label94);
        this.tabPage1.Controls.Add(this.NUP_RedMax9);
        this.tabPage1.Controls.Add(this.label95);
        this.tabPage1.Controls.Add(this.NUP_RedForme10);
        this.tabPage1.Controls.Add(this.label96);
        this.tabPage1.Controls.Add(this.NUP_RedMin10);
        this.tabPage1.Controls.Add(this.label97);
        this.tabPage1.Controls.Add(this.NUP_RedMax10);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme1);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin1);
        this.tabPage1.Controls.Add(this.label66);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax1);
        this.tabPage1.Controls.Add(this.label67);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme2);
        this.tabPage1.Controls.Add(this.label68);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin2);
        this.tabPage1.Controls.Add(this.label69);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax2);
        this.tabPage1.Controls.Add(this.CB_Red12);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme3);
        this.tabPage1.Controls.Add(this.CB_Red11);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin3);
        this.tabPage1.Controls.Add(this.CB_Red10);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax3);
        this.tabPage1.Controls.Add(this.CB_Red9);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme4);
        this.tabPage1.Controls.Add(this.CB_Red8);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin4);
        this.tabPage1.Controls.Add(this.CB_Red7);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax4);
        this.tabPage1.Controls.Add(this.CB_Red6);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme5);
        this.tabPage1.Controls.Add(this.CB_Red5);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin5);
        this.tabPage1.Controls.Add(this.CB_Red4);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax5);
        this.tabPage1.Controls.Add(this.CB_Red3);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme6);
        this.tabPage1.Controls.Add(this.CB_Red2);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin6);
        this.tabPage1.Controls.Add(this.CB_Red1);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax6);
        this.tabPage1.Controls.Add(this.label70);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme7);
        this.tabPage1.Controls.Add(this.label71);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin7);
        this.tabPage1.Controls.Add(this.label72);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax7);
        this.tabPage1.Controls.Add(this.label73);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme8);
        this.tabPage1.Controls.Add(this.label74);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin8);
        this.tabPage1.Controls.Add(this.label75);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax8);
        this.tabPage1.Controls.Add(this.label76);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme9);
        this.tabPage1.Controls.Add(this.label77);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin9);
        this.tabPage1.Controls.Add(this.label78);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax9);
        this.tabPage1.Controls.Add(this.label79);
        this.tabPage1.Controls.Add(this.NUP_PurpleForme10);
        this.tabPage1.Controls.Add(this.label80);
        this.tabPage1.Controls.Add(this.NUP_PurpleMin10);
        this.tabPage1.Controls.Add(this.label81);
        this.tabPage1.Controls.Add(this.NUP_PurpleMax10);
        this.tabPage1.Controls.Add(this.NUP_YellowForme1);
        this.tabPage1.Controls.Add(this.NUP_YellowMin1);
        this.tabPage1.Controls.Add(this.label50);
        this.tabPage1.Controls.Add(this.NUP_YellowMax1);
        this.tabPage1.Controls.Add(this.label51);
        this.tabPage1.Controls.Add(this.NUP_YellowForme2);
        this.tabPage1.Controls.Add(this.label52);
        this.tabPage1.Controls.Add(this.NUP_YellowMin2);
        this.tabPage1.Controls.Add(this.label53);
        this.tabPage1.Controls.Add(this.NUP_YellowMax2);
        this.tabPage1.Controls.Add(this.CB_Yellow12);
        this.tabPage1.Controls.Add(this.NUP_YellowForme3);
        this.tabPage1.Controls.Add(this.CB_Yellow11);
        this.tabPage1.Controls.Add(this.NUP_YellowMin3);
        this.tabPage1.Controls.Add(this.CB_Yellow10);
        this.tabPage1.Controls.Add(this.NUP_YellowMax3);
        this.tabPage1.Controls.Add(this.CB_Yellow9);
        this.tabPage1.Controls.Add(this.NUP_YellowForme4);
        this.tabPage1.Controls.Add(this.CB_Yellow8);
        this.tabPage1.Controls.Add(this.NUP_YellowMin4);
        this.tabPage1.Controls.Add(this.CB_Yellow7);
        this.tabPage1.Controls.Add(this.NUP_YellowMax4);
        this.tabPage1.Controls.Add(this.CB_Yellow6);
        this.tabPage1.Controls.Add(this.NUP_YellowForme5);
        this.tabPage1.Controls.Add(this.CB_Yellow5);
        this.tabPage1.Controls.Add(this.NUP_YellowMin5);
        this.tabPage1.Controls.Add(this.CB_Yellow4);
        this.tabPage1.Controls.Add(this.NUP_YellowMax5);
        this.tabPage1.Controls.Add(this.CB_Yellow3);
        this.tabPage1.Controls.Add(this.NUP_YellowForme6);
        this.tabPage1.Controls.Add(this.CB_Yellow2);
        this.tabPage1.Controls.Add(this.NUP_YellowMin6);
        this.tabPage1.Controls.Add(this.CB_Yellow1);
        this.tabPage1.Controls.Add(this.NUP_YellowMax6);
        this.tabPage1.Controls.Add(this.label54);
        this.tabPage1.Controls.Add(this.NUP_YellowForme7);
        this.tabPage1.Controls.Add(this.label55);
        this.tabPage1.Controls.Add(this.NUP_YellowMin7);
        this.tabPage1.Controls.Add(this.label56);
        this.tabPage1.Controls.Add(this.NUP_YellowMax7);
        this.tabPage1.Controls.Add(this.label57);
        this.tabPage1.Controls.Add(this.NUP_YellowForme8);
        this.tabPage1.Controls.Add(this.label58);
        this.tabPage1.Controls.Add(this.NUP_YellowMin8);
        this.tabPage1.Controls.Add(this.label59);
        this.tabPage1.Controls.Add(this.NUP_YellowMax8);
        this.tabPage1.Controls.Add(this.label60);
        this.tabPage1.Controls.Add(this.NUP_YellowForme9);
        this.tabPage1.Controls.Add(this.label61);
        this.tabPage1.Controls.Add(this.NUP_YellowMin9);
        this.tabPage1.Controls.Add(this.label62);
        this.tabPage1.Controls.Add(this.NUP_YellowMax9);
        this.tabPage1.Controls.Add(this.label63);
        this.tabPage1.Controls.Add(this.NUP_YellowForme10);
        this.tabPage1.Controls.Add(this.label64);
        this.tabPage1.Controls.Add(this.NUP_YellowMin10);
        this.tabPage1.Controls.Add(this.label65);
        this.tabPage1.Controls.Add(this.NUP_YellowMax10);
        this.tabPage1.Location = new System.Drawing.Point(4, 22);
        this.tabPage1.Name = "tabPage1";
        this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
        this.tabPage1.Size = new System.Drawing.Size(918, 369);
        this.tabPage1.TabIndex = 3;
        this.tabPage1.Text = "Flowers";
        this.tabPage1.UseVisualStyleBackColor = true;
        // 
        // NUP_RedForme11
        // 
        this.NUP_RedForme11.Location = new System.Drawing.Point(773, 300);
        this.NUP_RedForme11.Name = "NUP_RedForme11";
        this.NUP_RedForme11.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme11.TabIndex = 646;
        // 
        // NUP_RedMin11
        // 
        this.NUP_RedMin11.Location = new System.Drawing.Point(820, 300);
        this.NUP_RedMin11.Name = "NUP_RedMin11";
        this.NUP_RedMin11.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin11.TabIndex = 647;
        // 
        // NUP_RedMax11
        // 
        this.NUP_RedMax11.Location = new System.Drawing.Point(867, 300);
        this.NUP_RedMax11.Name = "NUP_RedMax11";
        this.NUP_RedMax11.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax11.TabIndex = 648;
        // 
        // NUP_RedForme12
        // 
        this.NUP_RedForme12.Location = new System.Drawing.Point(773, 326);
        this.NUP_RedForme12.Name = "NUP_RedForme12";
        this.NUP_RedForme12.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme12.TabIndex = 649;
        // 
        // NUP_RedMin12
        // 
        this.NUP_RedMin12.Location = new System.Drawing.Point(820, 326);
        this.NUP_RedMin12.Name = "NUP_RedMin12";
        this.NUP_RedMin12.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin12.TabIndex = 650;
        // 
        // NUP_RedMax12
        // 
        this.NUP_RedMax12.Location = new System.Drawing.Point(867, 326);
        this.NUP_RedMax12.Name = "NUP_RedMax12";
        this.NUP_RedMax12.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax12.TabIndex = 651;
        // 
        // NUP_PurpleForme11
        // 
        this.NUP_PurpleForme11.Location = new System.Drawing.Point(472, 300);
        this.NUP_PurpleForme11.Name = "NUP_PurpleForme11";
        this.NUP_PurpleForme11.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme11.TabIndex = 640;
        // 
        // NUP_PurpleMin11
        // 
        this.NUP_PurpleMin11.Location = new System.Drawing.Point(519, 300);
        this.NUP_PurpleMin11.Name = "NUP_PurpleMin11";
        this.NUP_PurpleMin11.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin11.TabIndex = 641;
        // 
        // NUP_PurpleMax11
        // 
        this.NUP_PurpleMax11.Location = new System.Drawing.Point(566, 300);
        this.NUP_PurpleMax11.Name = "NUP_PurpleMax11";
        this.NUP_PurpleMax11.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax11.TabIndex = 642;
        // 
        // NUP_PurpleForme12
        // 
        this.NUP_PurpleForme12.Location = new System.Drawing.Point(472, 326);
        this.NUP_PurpleForme12.Name = "NUP_PurpleForme12";
        this.NUP_PurpleForme12.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme12.TabIndex = 643;
        // 
        // NUP_PurpleMin12
        // 
        this.NUP_PurpleMin12.Location = new System.Drawing.Point(519, 326);
        this.NUP_PurpleMin12.Name = "NUP_PurpleMin12";
        this.NUP_PurpleMin12.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin12.TabIndex = 644;
        // 
        // NUP_PurpleMax12
        // 
        this.NUP_PurpleMax12.Location = new System.Drawing.Point(566, 326);
        this.NUP_PurpleMax12.Name = "NUP_PurpleMax12";
        this.NUP_PurpleMax12.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax12.TabIndex = 645;
        // 
        // NUP_YellowForme11
        // 
        this.NUP_YellowForme11.Location = new System.Drawing.Point(169, 298);
        this.NUP_YellowForme11.Name = "NUP_YellowForme11";
        this.NUP_YellowForme11.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme11.TabIndex = 634;
        // 
        // NUP_YellowMin11
        // 
        this.NUP_YellowMin11.Location = new System.Drawing.Point(216, 298);
        this.NUP_YellowMin11.Name = "NUP_YellowMin11";
        this.NUP_YellowMin11.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin11.TabIndex = 635;
        // 
        // NUP_YellowMax11
        // 
        this.NUP_YellowMax11.Location = new System.Drawing.Point(263, 298);
        this.NUP_YellowMax11.Name = "NUP_YellowMax11";
        this.NUP_YellowMax11.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax11.TabIndex = 636;
        // 
        // NUP_YellowForme12
        // 
        this.NUP_YellowForme12.Location = new System.Drawing.Point(169, 324);
        this.NUP_YellowForme12.Name = "NUP_YellowForme12";
        this.NUP_YellowForme12.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme12.TabIndex = 637;
        // 
        // NUP_YellowMin12
        // 
        this.NUP_YellowMin12.Location = new System.Drawing.Point(216, 324);
        this.NUP_YellowMin12.Name = "NUP_YellowMin12";
        this.NUP_YellowMin12.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin12.TabIndex = 638;
        // 
        // NUP_YellowMax12
        // 
        this.NUP_YellowMax12.Location = new System.Drawing.Point(263, 324);
        this.NUP_YellowMax12.Name = "NUP_YellowMax12";
        this.NUP_YellowMax12.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax12.TabIndex = 639;
        // 
        // NUP_RedForme1
        // 
        this.NUP_RedForme1.Location = new System.Drawing.Point(773, 35);
        this.NUP_RedForme1.Name = "NUP_RedForme1";
        this.NUP_RedForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme1.TabIndex = 571;
        // 
        // NUP_RedMin1
        // 
        this.NUP_RedMin1.Location = new System.Drawing.Point(820, 35);
        this.NUP_RedMin1.Name = "NUP_RedMin1";
        this.NUP_RedMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin1.TabIndex = 572;
        // 
        // label82
        // 
        this.label82.AutoSize = true;
        this.label82.Location = new System.Drawing.Point(772, 19);
        this.label82.Name = "label82";
        this.label82.Size = new System.Drawing.Size(36, 13);
        this.label82.TabIndex = 631;
        this.label82.Text = "Forme";
        // 
        // NUP_RedMax1
        // 
        this.NUP_RedMax1.Location = new System.Drawing.Point(867, 35);
        this.NUP_RedMax1.Name = "NUP_RedMax1";
        this.NUP_RedMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax1.TabIndex = 573;
        // 
        // label83
        // 
        this.label83.AutoSize = true;
        this.label83.Location = new System.Drawing.Point(819, 19);
        this.label83.Name = "label83";
        this.label83.Size = new System.Drawing.Size(24, 13);
        this.label83.TabIndex = 632;
        this.label83.Text = "Min";
        // 
        // NUP_RedForme2
        // 
        this.NUP_RedForme2.Location = new System.Drawing.Point(773, 62);
        this.NUP_RedForme2.Name = "NUP_RedForme2";
        this.NUP_RedForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme2.TabIndex = 574;
        // 
        // label84
        // 
        this.label84.AutoSize = true;
        this.label84.Location = new System.Drawing.Point(866, 19);
        this.label84.Name = "label84";
        this.label84.Size = new System.Drawing.Size(27, 13);
        this.label84.TabIndex = 633;
        this.label84.Text = "Max";
        // 
        // NUP_RedMin2
        // 
        this.NUP_RedMin2.Location = new System.Drawing.Point(820, 62);
        this.NUP_RedMin2.Name = "NUP_RedMin2";
        this.NUP_RedMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin2.TabIndex = 575;
        // 
        // label85
        // 
        this.label85.AutoSize = true;
        this.label85.Location = new System.Drawing.Point(646, 18);
        this.label85.Name = "label85";
        this.label85.Size = new System.Drawing.Size(66, 13);
        this.label85.TabIndex = 630;
        this.label85.Text = "Red Flowers";
        // 
        // NUP_RedMax2
        // 
        this.NUP_RedMax2.Location = new System.Drawing.Point(867, 62);
        this.NUP_RedMax2.Name = "NUP_RedMax2";
        this.NUP_RedMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax2.TabIndex = 576;
        // 
        // CB_Purple12
        // 
        this.CB_Purple12.FormattingEnabled = true;
        this.CB_Purple12.Location = new System.Drawing.Point(344, 326);
        this.CB_Purple12.Name = "CB_Purple12";
        this.CB_Purple12.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple12.TabIndex = 629;
        // 
        // NUP_RedForme3
        // 
        this.NUP_RedForme3.Location = new System.Drawing.Point(773, 89);
        this.NUP_RedForme3.Name = "NUP_RedForme3";
        this.NUP_RedForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme3.TabIndex = 577;
        // 
        // CB_Purple11
        // 
        this.CB_Purple11.FormattingEnabled = true;
        this.CB_Purple11.Location = new System.Drawing.Point(344, 300);
        this.CB_Purple11.Name = "CB_Purple11";
        this.CB_Purple11.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple11.TabIndex = 628;
        // 
        // NUP_RedMin3
        // 
        this.NUP_RedMin3.Location = new System.Drawing.Point(820, 89);
        this.NUP_RedMin3.Name = "NUP_RedMin3";
        this.NUP_RedMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin3.TabIndex = 578;
        // 
        // CB_Purple10
        // 
        this.CB_Purple10.FormattingEnabled = true;
        this.CB_Purple10.Location = new System.Drawing.Point(344, 273);
        this.CB_Purple10.Name = "CB_Purple10";
        this.CB_Purple10.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple10.TabIndex = 627;
        // 
        // NUP_RedMax3
        // 
        this.NUP_RedMax3.Location = new System.Drawing.Point(867, 89);
        this.NUP_RedMax3.Name = "NUP_RedMax3";
        this.NUP_RedMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax3.TabIndex = 579;
        // 
        // CB_Purple9
        // 
        this.CB_Purple9.FormattingEnabled = true;
        this.CB_Purple9.Location = new System.Drawing.Point(344, 247);
        this.CB_Purple9.Name = "CB_Purple9";
        this.CB_Purple9.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple9.TabIndex = 626;
        // 
        // NUP_RedForme4
        // 
        this.NUP_RedForme4.Location = new System.Drawing.Point(773, 115);
        this.NUP_RedForme4.Name = "NUP_RedForme4";
        this.NUP_RedForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme4.TabIndex = 580;
        // 
        // CB_Purple8
        // 
        this.CB_Purple8.FormattingEnabled = true;
        this.CB_Purple8.Location = new System.Drawing.Point(344, 220);
        this.CB_Purple8.Name = "CB_Purple8";
        this.CB_Purple8.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple8.TabIndex = 625;
        // 
        // NUP_RedMin4
        // 
        this.NUP_RedMin4.Location = new System.Drawing.Point(820, 115);
        this.NUP_RedMin4.Name = "NUP_RedMin4";
        this.NUP_RedMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin4.TabIndex = 581;
        // 
        // CB_Purple7
        // 
        this.CB_Purple7.FormattingEnabled = true;
        this.CB_Purple7.Location = new System.Drawing.Point(344, 194);
        this.CB_Purple7.Name = "CB_Purple7";
        this.CB_Purple7.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple7.TabIndex = 624;
        // 
        // NUP_RedMax4
        // 
        this.NUP_RedMax4.Location = new System.Drawing.Point(867, 115);
        this.NUP_RedMax4.Name = "NUP_RedMax4";
        this.NUP_RedMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax4.TabIndex = 582;
        // 
        // CB_Purple6
        // 
        this.CB_Purple6.FormattingEnabled = true;
        this.CB_Purple6.Location = new System.Drawing.Point(344, 167);
        this.CB_Purple6.Name = "CB_Purple6";
        this.CB_Purple6.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple6.TabIndex = 623;
        // 
        // NUP_RedForme5
        // 
        this.NUP_RedForme5.Location = new System.Drawing.Point(773, 142);
        this.NUP_RedForme5.Name = "NUP_RedForme5";
        this.NUP_RedForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme5.TabIndex = 583;
        // 
        // CB_Purple5
        // 
        this.CB_Purple5.FormattingEnabled = true;
        this.CB_Purple5.Location = new System.Drawing.Point(344, 141);
        this.CB_Purple5.Name = "CB_Purple5";
        this.CB_Purple5.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple5.TabIndex = 622;
        // 
        // NUP_RedMin5
        // 
        this.NUP_RedMin5.Location = new System.Drawing.Point(820, 142);
        this.NUP_RedMin5.Name = "NUP_RedMin5";
        this.NUP_RedMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin5.TabIndex = 584;
        // 
        // CB_Purple4
        // 
        this.CB_Purple4.FormattingEnabled = true;
        this.CB_Purple4.Location = new System.Drawing.Point(344, 114);
        this.CB_Purple4.Name = "CB_Purple4";
        this.CB_Purple4.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple4.TabIndex = 621;
        // 
        // NUP_RedMax5
        // 
        this.NUP_RedMax5.Location = new System.Drawing.Point(867, 142);
        this.NUP_RedMax5.Name = "NUP_RedMax5";
        this.NUP_RedMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax5.TabIndex = 585;
        // 
        // CB_Purple3
        // 
        this.CB_Purple3.FormattingEnabled = true;
        this.CB_Purple3.Location = new System.Drawing.Point(344, 88);
        this.CB_Purple3.Name = "CB_Purple3";
        this.CB_Purple3.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple3.TabIndex = 620;
        // 
        // NUP_RedForme6
        // 
        this.NUP_RedForme6.Location = new System.Drawing.Point(773, 169);
        this.NUP_RedForme6.Name = "NUP_RedForme6";
        this.NUP_RedForme6.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme6.TabIndex = 586;
        // 
        // CB_Purple2
        // 
        this.CB_Purple2.FormattingEnabled = true;
        this.CB_Purple2.Location = new System.Drawing.Point(344, 61);
        this.CB_Purple2.Name = "CB_Purple2";
        this.CB_Purple2.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple2.TabIndex = 619;
        // 
        // NUP_RedMin6
        // 
        this.NUP_RedMin6.Location = new System.Drawing.Point(820, 169);
        this.NUP_RedMin6.Name = "NUP_RedMin6";
        this.NUP_RedMin6.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin6.TabIndex = 587;
        // 
        // CB_Purple1
        // 
        this.CB_Purple1.FormattingEnabled = true;
        this.CB_Purple1.Location = new System.Drawing.Point(344, 35);
        this.CB_Purple1.Name = "CB_Purple1";
        this.CB_Purple1.Size = new System.Drawing.Size(121, 21);
        this.CB_Purple1.TabIndex = 570;
        // 
        // NUP_RedMax6
        // 
        this.NUP_RedMax6.Location = new System.Drawing.Point(867, 169);
        this.NUP_RedMax6.Name = "NUP_RedMax6";
        this.NUP_RedMax6.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax6.TabIndex = 588;
        // 
        // label86
        // 
        this.label86.AutoSize = true;
        this.label86.Location = new System.Drawing.Point(613, 38);
        this.label86.Name = "label86";
        this.label86.Size = new System.Drawing.Size(27, 13);
        this.label86.TabIndex = 607;
        this.label86.Text = "10%";
        // 
        // NUP_RedForme7
        // 
        this.NUP_RedForme7.Location = new System.Drawing.Point(773, 195);
        this.NUP_RedForme7.Name = "NUP_RedForme7";
        this.NUP_RedForme7.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme7.TabIndex = 589;
        // 
        // label87
        // 
        this.label87.AutoSize = true;
        this.label87.Location = new System.Drawing.Point(619, 331);
        this.label87.Name = "label87";
        this.label87.Size = new System.Drawing.Size(21, 13);
        this.label87.TabIndex = 618;
        this.label87.Text = "1%";
        // 
        // NUP_RedMin7
        // 
        this.NUP_RedMin7.Location = new System.Drawing.Point(820, 195);
        this.NUP_RedMin7.Name = "NUP_RedMin7";
        this.NUP_RedMin7.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin7.TabIndex = 590;
        // 
        // label88
        // 
        this.label88.AutoSize = true;
        this.label88.Location = new System.Drawing.Point(619, 304);
        this.label88.Name = "label88";
        this.label88.Size = new System.Drawing.Size(21, 13);
        this.label88.TabIndex = 617;
        this.label88.Text = "4%";
        // 
        // NUP_RedMax7
        // 
        this.NUP_RedMax7.Location = new System.Drawing.Point(867, 195);
        this.NUP_RedMax7.Name = "NUP_RedMax7";
        this.NUP_RedMax7.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax7.TabIndex = 591;
        // 
        // label89
        // 
        this.label89.AutoSize = true;
        this.label89.Location = new System.Drawing.Point(619, 277);
        this.label89.Name = "label89";
        this.label89.Size = new System.Drawing.Size(21, 13);
        this.label89.TabIndex = 616;
        this.label89.Text = "5%";
        // 
        // NUP_RedForme8
        // 
        this.NUP_RedForme8.Location = new System.Drawing.Point(773, 222);
        this.NUP_RedForme8.Name = "NUP_RedForme8";
        this.NUP_RedForme8.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme8.TabIndex = 592;
        // 
        // label90
        // 
        this.label90.AutoSize = true;
        this.label90.Location = new System.Drawing.Point(612, 251);
        this.label90.Name = "label90";
        this.label90.Size = new System.Drawing.Size(27, 13);
        this.label90.TabIndex = 615;
        this.label90.Text = "10%";
        // 
        // NUP_RedMin8
        // 
        this.NUP_RedMin8.Location = new System.Drawing.Point(820, 222);
        this.NUP_RedMin8.Name = "NUP_RedMin8";
        this.NUP_RedMin8.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin8.TabIndex = 593;
        // 
        // label91
        // 
        this.label91.AutoSize = true;
        this.label91.Location = new System.Drawing.Point(612, 227);
        this.label91.Name = "label91";
        this.label91.Size = new System.Drawing.Size(27, 13);
        this.label91.TabIndex = 614;
        this.label91.Text = "10%";
        // 
        // NUP_RedMax8
        // 
        this.NUP_RedMax8.Location = new System.Drawing.Point(867, 222);
        this.NUP_RedMax8.Name = "NUP_RedMax8";
        this.NUP_RedMax8.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax8.TabIndex = 594;
        // 
        // label92
        // 
        this.label92.AutoSize = true;
        this.label92.Location = new System.Drawing.Point(612, 200);
        this.label92.Name = "label92";
        this.label92.Size = new System.Drawing.Size(27, 13);
        this.label92.TabIndex = 613;
        this.label92.Text = "10%";
        // 
        // NUP_RedForme9
        // 
        this.NUP_RedForme9.Location = new System.Drawing.Point(773, 249);
        this.NUP_RedForme9.Name = "NUP_RedForme9";
        this.NUP_RedForme9.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme9.TabIndex = 595;
        // 
        // label93
        // 
        this.label93.AutoSize = true;
        this.label93.Location = new System.Drawing.Point(613, 173);
        this.label93.Name = "label93";
        this.label93.Size = new System.Drawing.Size(27, 13);
        this.label93.TabIndex = 612;
        this.label93.Text = "10%";
        // 
        // NUP_RedMin9
        // 
        this.NUP_RedMin9.Location = new System.Drawing.Point(820, 249);
        this.NUP_RedMin9.Name = "NUP_RedMin9";
        this.NUP_RedMin9.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin9.TabIndex = 596;
        // 
        // label94
        // 
        this.label94.AutoSize = true;
        this.label94.Location = new System.Drawing.Point(613, 146);
        this.label94.Name = "label94";
        this.label94.Size = new System.Drawing.Size(27, 13);
        this.label94.TabIndex = 611;
        this.label94.Text = "10%";
        // 
        // NUP_RedMax9
        // 
        this.NUP_RedMax9.Location = new System.Drawing.Point(867, 249);
        this.NUP_RedMax9.Name = "NUP_RedMax9";
        this.NUP_RedMax9.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax9.TabIndex = 597;
        // 
        // label95
        // 
        this.label95.AutoSize = true;
        this.label95.Location = new System.Drawing.Point(613, 119);
        this.label95.Name = "label95";
        this.label95.Size = new System.Drawing.Size(27, 13);
        this.label95.TabIndex = 610;
        this.label95.Text = "10%";
        // 
        // NUP_RedForme10
        // 
        this.NUP_RedForme10.Location = new System.Drawing.Point(773, 275);
        this.NUP_RedForme10.Name = "NUP_RedForme10";
        this.NUP_RedForme10.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedForme10.TabIndex = 598;
        // 
        // label96
        // 
        this.label96.AutoSize = true;
        this.label96.Location = new System.Drawing.Point(613, 92);
        this.label96.Name = "label96";
        this.label96.Size = new System.Drawing.Size(27, 13);
        this.label96.TabIndex = 609;
        this.label96.Text = "10%";
        // 
        // NUP_RedMin10
        // 
        this.NUP_RedMin10.Location = new System.Drawing.Point(820, 275);
        this.NUP_RedMin10.Name = "NUP_RedMin10";
        this.NUP_RedMin10.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMin10.TabIndex = 599;
        // 
        // label97
        // 
        this.label97.AutoSize = true;
        this.label97.Location = new System.Drawing.Point(613, 65);
        this.label97.Name = "label97";
        this.label97.Size = new System.Drawing.Size(27, 13);
        this.label97.TabIndex = 608;
        this.label97.Text = "10%";
        // 
        // NUP_RedMax10
        // 
        this.NUP_RedMax10.Location = new System.Drawing.Point(867, 275);
        this.NUP_RedMax10.Name = "NUP_RedMax10";
        this.NUP_RedMax10.Size = new System.Drawing.Size(41, 20);
        this.NUP_RedMax10.TabIndex = 600;
        // 
        // NUP_PurpleForme1
        // 
        this.NUP_PurpleForme1.Location = new System.Drawing.Point(472, 35);
        this.NUP_PurpleForme1.Name = "NUP_PurpleForme1";
        this.NUP_PurpleForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme1.TabIndex = 507;
        // 
        // NUP_PurpleMin1
        // 
        this.NUP_PurpleMin1.Location = new System.Drawing.Point(519, 35);
        this.NUP_PurpleMin1.Name = "NUP_PurpleMin1";
        this.NUP_PurpleMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin1.TabIndex = 508;
        // 
        // label66
        // 
        this.label66.AutoSize = true;
        this.label66.Location = new System.Drawing.Point(471, 19);
        this.label66.Name = "label66";
        this.label66.Size = new System.Drawing.Size(36, 13);
        this.label66.TabIndex = 567;
        this.label66.Text = "Forme";
        // 
        // NUP_PurpleMax1
        // 
        this.NUP_PurpleMax1.Location = new System.Drawing.Point(566, 35);
        this.NUP_PurpleMax1.Name = "NUP_PurpleMax1";
        this.NUP_PurpleMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax1.TabIndex = 509;
        // 
        // label67
        // 
        this.label67.AutoSize = true;
        this.label67.Location = new System.Drawing.Point(518, 19);
        this.label67.Name = "label67";
        this.label67.Size = new System.Drawing.Size(24, 13);
        this.label67.TabIndex = 568;
        this.label67.Text = "Min";
        // 
        // NUP_PurpleForme2
        // 
        this.NUP_PurpleForme2.Location = new System.Drawing.Point(472, 62);
        this.NUP_PurpleForme2.Name = "NUP_PurpleForme2";
        this.NUP_PurpleForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme2.TabIndex = 510;
        // 
        // label68
        // 
        this.label68.AutoSize = true;
        this.label68.Location = new System.Drawing.Point(565, 19);
        this.label68.Name = "label68";
        this.label68.Size = new System.Drawing.Size(27, 13);
        this.label68.TabIndex = 569;
        this.label68.Text = "Max";
        // 
        // NUP_PurpleMin2
        // 
        this.NUP_PurpleMin2.Location = new System.Drawing.Point(519, 62);
        this.NUP_PurpleMin2.Name = "NUP_PurpleMin2";
        this.NUP_PurpleMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin2.TabIndex = 511;
        // 
        // label69
        // 
        this.label69.AutoSize = true;
        this.label69.Location = new System.Drawing.Point(344, 18);
        this.label69.Name = "label69";
        this.label69.Size = new System.Drawing.Size(76, 13);
        this.label69.TabIndex = 566;
        this.label69.Text = "Purple Flowers";
        // 
        // NUP_PurpleMax2
        // 
        this.NUP_PurpleMax2.Location = new System.Drawing.Point(566, 62);
        this.NUP_PurpleMax2.Name = "NUP_PurpleMax2";
        this.NUP_PurpleMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax2.TabIndex = 512;
        // 
        // CB_Red12
        // 
        this.CB_Red12.FormattingEnabled = true;
        this.CB_Red12.Location = new System.Drawing.Point(646, 327);
        this.CB_Red12.Name = "CB_Red12";
        this.CB_Red12.Size = new System.Drawing.Size(121, 21);
        this.CB_Red12.TabIndex = 565;
        // 
        // NUP_PurpleForme3
        // 
        this.NUP_PurpleForme3.Location = new System.Drawing.Point(472, 89);
        this.NUP_PurpleForme3.Name = "NUP_PurpleForme3";
        this.NUP_PurpleForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme3.TabIndex = 513;
        // 
        // CB_Red11
        // 
        this.CB_Red11.FormattingEnabled = true;
        this.CB_Red11.Location = new System.Drawing.Point(646, 301);
        this.CB_Red11.Name = "CB_Red11";
        this.CB_Red11.Size = new System.Drawing.Size(121, 21);
        this.CB_Red11.TabIndex = 564;
        // 
        // NUP_PurpleMin3
        // 
        this.NUP_PurpleMin3.Location = new System.Drawing.Point(519, 89);
        this.NUP_PurpleMin3.Name = "NUP_PurpleMin3";
        this.NUP_PurpleMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin3.TabIndex = 514;
        // 
        // CB_Red10
        // 
        this.CB_Red10.FormattingEnabled = true;
        this.CB_Red10.Location = new System.Drawing.Point(646, 274);
        this.CB_Red10.Name = "CB_Red10";
        this.CB_Red10.Size = new System.Drawing.Size(121, 21);
        this.CB_Red10.TabIndex = 563;
        // 
        // NUP_PurpleMax3
        // 
        this.NUP_PurpleMax3.Location = new System.Drawing.Point(566, 89);
        this.NUP_PurpleMax3.Name = "NUP_PurpleMax3";
        this.NUP_PurpleMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax3.TabIndex = 515;
        // 
        // CB_Red9
        // 
        this.CB_Red9.FormattingEnabled = true;
        this.CB_Red9.Location = new System.Drawing.Point(646, 248);
        this.CB_Red9.Name = "CB_Red9";
        this.CB_Red9.Size = new System.Drawing.Size(121, 21);
        this.CB_Red9.TabIndex = 562;
        // 
        // NUP_PurpleForme4
        // 
        this.NUP_PurpleForme4.Location = new System.Drawing.Point(472, 115);
        this.NUP_PurpleForme4.Name = "NUP_PurpleForme4";
        this.NUP_PurpleForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme4.TabIndex = 516;
        // 
        // CB_Red8
        // 
        this.CB_Red8.FormattingEnabled = true;
        this.CB_Red8.Location = new System.Drawing.Point(646, 221);
        this.CB_Red8.Name = "CB_Red8";
        this.CB_Red8.Size = new System.Drawing.Size(121, 21);
        this.CB_Red8.TabIndex = 561;
        // 
        // NUP_PurpleMin4
        // 
        this.NUP_PurpleMin4.Location = new System.Drawing.Point(519, 115);
        this.NUP_PurpleMin4.Name = "NUP_PurpleMin4";
        this.NUP_PurpleMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin4.TabIndex = 517;
        // 
        // CB_Red7
        // 
        this.CB_Red7.FormattingEnabled = true;
        this.CB_Red7.Location = new System.Drawing.Point(646, 195);
        this.CB_Red7.Name = "CB_Red7";
        this.CB_Red7.Size = new System.Drawing.Size(121, 21);
        this.CB_Red7.TabIndex = 560;
        // 
        // NUP_PurpleMax4
        // 
        this.NUP_PurpleMax4.Location = new System.Drawing.Point(566, 115);
        this.NUP_PurpleMax4.Name = "NUP_PurpleMax4";
        this.NUP_PurpleMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax4.TabIndex = 518;
        // 
        // CB_Red6
        // 
        this.CB_Red6.FormattingEnabled = true;
        this.CB_Red6.Location = new System.Drawing.Point(646, 168);
        this.CB_Red6.Name = "CB_Red6";
        this.CB_Red6.Size = new System.Drawing.Size(121, 21);
        this.CB_Red6.TabIndex = 559;
        // 
        // NUP_PurpleForme5
        // 
        this.NUP_PurpleForme5.Location = new System.Drawing.Point(472, 142);
        this.NUP_PurpleForme5.Name = "NUP_PurpleForme5";
        this.NUP_PurpleForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme5.TabIndex = 519;
        // 
        // CB_Red5
        // 
        this.CB_Red5.FormattingEnabled = true;
        this.CB_Red5.Location = new System.Drawing.Point(646, 142);
        this.CB_Red5.Name = "CB_Red5";
        this.CB_Red5.Size = new System.Drawing.Size(121, 21);
        this.CB_Red5.TabIndex = 558;
        // 
        // NUP_PurpleMin5
        // 
        this.NUP_PurpleMin5.Location = new System.Drawing.Point(519, 142);
        this.NUP_PurpleMin5.Name = "NUP_PurpleMin5";
        this.NUP_PurpleMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin5.TabIndex = 520;
        // 
        // CB_Red4
        // 
        this.CB_Red4.FormattingEnabled = true;
        this.CB_Red4.Location = new System.Drawing.Point(646, 115);
        this.CB_Red4.Name = "CB_Red4";
        this.CB_Red4.Size = new System.Drawing.Size(121, 21);
        this.CB_Red4.TabIndex = 557;
        // 
        // NUP_PurpleMax5
        // 
        this.NUP_PurpleMax5.Location = new System.Drawing.Point(566, 142);
        this.NUP_PurpleMax5.Name = "NUP_PurpleMax5";
        this.NUP_PurpleMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax5.TabIndex = 521;
        // 
        // CB_Red3
        // 
        this.CB_Red3.FormattingEnabled = true;
        this.CB_Red3.Location = new System.Drawing.Point(646, 89);
        this.CB_Red3.Name = "CB_Red3";
        this.CB_Red3.Size = new System.Drawing.Size(121, 21);
        this.CB_Red3.TabIndex = 556;
        // 
        // NUP_PurpleForme6
        // 
        this.NUP_PurpleForme6.Location = new System.Drawing.Point(472, 169);
        this.NUP_PurpleForme6.Name = "NUP_PurpleForme6";
        this.NUP_PurpleForme6.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme6.TabIndex = 522;
        // 
        // CB_Red2
        // 
        this.CB_Red2.FormattingEnabled = true;
        this.CB_Red2.Location = new System.Drawing.Point(646, 62);
        this.CB_Red2.Name = "CB_Red2";
        this.CB_Red2.Size = new System.Drawing.Size(121, 21);
        this.CB_Red2.TabIndex = 555;
        // 
        // NUP_PurpleMin6
        // 
        this.NUP_PurpleMin6.Location = new System.Drawing.Point(519, 169);
        this.NUP_PurpleMin6.Name = "NUP_PurpleMin6";
        this.NUP_PurpleMin6.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin6.TabIndex = 523;
        // 
        // CB_Red1
        // 
        this.CB_Red1.FormattingEnabled = true;
        this.CB_Red1.Location = new System.Drawing.Point(646, 36);
        this.CB_Red1.Name = "CB_Red1";
        this.CB_Red1.Size = new System.Drawing.Size(121, 21);
        this.CB_Red1.TabIndex = 506;
        // 
        // NUP_PurpleMax6
        // 
        this.NUP_PurpleMax6.Location = new System.Drawing.Point(566, 169);
        this.NUP_PurpleMax6.Name = "NUP_PurpleMax6";
        this.NUP_PurpleMax6.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax6.TabIndex = 524;
        // 
        // label70
        // 
        this.label70.AutoSize = true;
        this.label70.Location = new System.Drawing.Point(312, 38);
        this.label70.Name = "label70";
        this.label70.Size = new System.Drawing.Size(27, 13);
        this.label70.TabIndex = 543;
        this.label70.Text = "10%";
        // 
        // NUP_PurpleForme7
        // 
        this.NUP_PurpleForme7.Location = new System.Drawing.Point(472, 195);
        this.NUP_PurpleForme7.Name = "NUP_PurpleForme7";
        this.NUP_PurpleForme7.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme7.TabIndex = 525;
        // 
        // label71
        // 
        this.label71.AutoSize = true;
        this.label71.Location = new System.Drawing.Point(318, 331);
        this.label71.Name = "label71";
        this.label71.Size = new System.Drawing.Size(21, 13);
        this.label71.TabIndex = 554;
        this.label71.Text = "1%";
        // 
        // NUP_PurpleMin7
        // 
        this.NUP_PurpleMin7.Location = new System.Drawing.Point(519, 195);
        this.NUP_PurpleMin7.Name = "NUP_PurpleMin7";
        this.NUP_PurpleMin7.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin7.TabIndex = 526;
        // 
        // label72
        // 
        this.label72.AutoSize = true;
        this.label72.Location = new System.Drawing.Point(318, 304);
        this.label72.Name = "label72";
        this.label72.Size = new System.Drawing.Size(21, 13);
        this.label72.TabIndex = 553;
        this.label72.Text = "4%";
        // 
        // NUP_PurpleMax7
        // 
        this.NUP_PurpleMax7.Location = new System.Drawing.Point(566, 195);
        this.NUP_PurpleMax7.Name = "NUP_PurpleMax7";
        this.NUP_PurpleMax7.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax7.TabIndex = 527;
        // 
        // label73
        // 
        this.label73.AutoSize = true;
        this.label73.Location = new System.Drawing.Point(318, 277);
        this.label73.Name = "label73";
        this.label73.Size = new System.Drawing.Size(21, 13);
        this.label73.TabIndex = 552;
        this.label73.Text = "5%";
        // 
        // NUP_PurpleForme8
        // 
        this.NUP_PurpleForme8.Location = new System.Drawing.Point(472, 222);
        this.NUP_PurpleForme8.Name = "NUP_PurpleForme8";
        this.NUP_PurpleForme8.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme8.TabIndex = 528;
        // 
        // label74
        // 
        this.label74.AutoSize = true;
        this.label74.Location = new System.Drawing.Point(311, 251);
        this.label74.Name = "label74";
        this.label74.Size = new System.Drawing.Size(27, 13);
        this.label74.TabIndex = 551;
        this.label74.Text = "10%";
        // 
        // NUP_PurpleMin8
        // 
        this.NUP_PurpleMin8.Location = new System.Drawing.Point(519, 222);
        this.NUP_PurpleMin8.Name = "NUP_PurpleMin8";
        this.NUP_PurpleMin8.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin8.TabIndex = 529;
        // 
        // label75
        // 
        this.label75.AutoSize = true;
        this.label75.Location = new System.Drawing.Point(311, 227);
        this.label75.Name = "label75";
        this.label75.Size = new System.Drawing.Size(27, 13);
        this.label75.TabIndex = 550;
        this.label75.Text = "10%";
        // 
        // NUP_PurpleMax8
        // 
        this.NUP_PurpleMax8.Location = new System.Drawing.Point(566, 222);
        this.NUP_PurpleMax8.Name = "NUP_PurpleMax8";
        this.NUP_PurpleMax8.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax8.TabIndex = 530;
        // 
        // label76
        // 
        this.label76.AutoSize = true;
        this.label76.Location = new System.Drawing.Point(311, 200);
        this.label76.Name = "label76";
        this.label76.Size = new System.Drawing.Size(27, 13);
        this.label76.TabIndex = 549;
        this.label76.Text = "10%";
        // 
        // NUP_PurpleForme9
        // 
        this.NUP_PurpleForme9.Location = new System.Drawing.Point(472, 249);
        this.NUP_PurpleForme9.Name = "NUP_PurpleForme9";
        this.NUP_PurpleForme9.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme9.TabIndex = 531;
        // 
        // label77
        // 
        this.label77.AutoSize = true;
        this.label77.Location = new System.Drawing.Point(312, 173);
        this.label77.Name = "label77";
        this.label77.Size = new System.Drawing.Size(27, 13);
        this.label77.TabIndex = 548;
        this.label77.Text = "10%";
        // 
        // NUP_PurpleMin9
        // 
        this.NUP_PurpleMin9.Location = new System.Drawing.Point(519, 249);
        this.NUP_PurpleMin9.Name = "NUP_PurpleMin9";
        this.NUP_PurpleMin9.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin9.TabIndex = 532;
        // 
        // label78
        // 
        this.label78.AutoSize = true;
        this.label78.Location = new System.Drawing.Point(312, 146);
        this.label78.Name = "label78";
        this.label78.Size = new System.Drawing.Size(27, 13);
        this.label78.TabIndex = 547;
        this.label78.Text = "10%";
        // 
        // NUP_PurpleMax9
        // 
        this.NUP_PurpleMax9.Location = new System.Drawing.Point(566, 249);
        this.NUP_PurpleMax9.Name = "NUP_PurpleMax9";
        this.NUP_PurpleMax9.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax9.TabIndex = 533;
        // 
        // label79
        // 
        this.label79.AutoSize = true;
        this.label79.Location = new System.Drawing.Point(312, 119);
        this.label79.Name = "label79";
        this.label79.Size = new System.Drawing.Size(27, 13);
        this.label79.TabIndex = 546;
        this.label79.Text = "10%";
        // 
        // NUP_PurpleForme10
        // 
        this.NUP_PurpleForme10.Location = new System.Drawing.Point(472, 275);
        this.NUP_PurpleForme10.Name = "NUP_PurpleForme10";
        this.NUP_PurpleForme10.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleForme10.TabIndex = 534;
        // 
        // label80
        // 
        this.label80.AutoSize = true;
        this.label80.Location = new System.Drawing.Point(312, 92);
        this.label80.Name = "label80";
        this.label80.Size = new System.Drawing.Size(27, 13);
        this.label80.TabIndex = 545;
        this.label80.Text = "10%";
        // 
        // NUP_PurpleMin10
        // 
        this.NUP_PurpleMin10.Location = new System.Drawing.Point(519, 275);
        this.NUP_PurpleMin10.Name = "NUP_PurpleMin10";
        this.NUP_PurpleMin10.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMin10.TabIndex = 535;
        // 
        // label81
        // 
        this.label81.AutoSize = true;
        this.label81.Location = new System.Drawing.Point(312, 65);
        this.label81.Name = "label81";
        this.label81.Size = new System.Drawing.Size(27, 13);
        this.label81.TabIndex = 544;
        this.label81.Text = "10%";
        // 
        // NUP_PurpleMax10
        // 
        this.NUP_PurpleMax10.Location = new System.Drawing.Point(566, 275);
        this.NUP_PurpleMax10.Name = "NUP_PurpleMax10";
        this.NUP_PurpleMax10.Size = new System.Drawing.Size(41, 20);
        this.NUP_PurpleMax10.TabIndex = 536;
        // 
        // NUP_YellowForme1
        // 
        this.NUP_YellowForme1.Location = new System.Drawing.Point(169, 33);
        this.NUP_YellowForme1.Name = "NUP_YellowForme1";
        this.NUP_YellowForme1.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme1.TabIndex = 443;
        // 
        // NUP_YellowMin1
        // 
        this.NUP_YellowMin1.Location = new System.Drawing.Point(216, 33);
        this.NUP_YellowMin1.Name = "NUP_YellowMin1";
        this.NUP_YellowMin1.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin1.TabIndex = 444;
        // 
        // label50
        // 
        this.label50.AutoSize = true;
        this.label50.Location = new System.Drawing.Point(168, 17);
        this.label50.Name = "label50";
        this.label50.Size = new System.Drawing.Size(36, 13);
        this.label50.TabIndex = 503;
        this.label50.Text = "Forme";
        // 
        // NUP_YellowMax1
        // 
        this.NUP_YellowMax1.Location = new System.Drawing.Point(263, 33);
        this.NUP_YellowMax1.Name = "NUP_YellowMax1";
        this.NUP_YellowMax1.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax1.TabIndex = 445;
        // 
        // label51
        // 
        this.label51.AutoSize = true;
        this.label51.Location = new System.Drawing.Point(215, 17);
        this.label51.Name = "label51";
        this.label51.Size = new System.Drawing.Size(24, 13);
        this.label51.TabIndex = 504;
        this.label51.Text = "Min";
        // 
        // NUP_YellowForme2
        // 
        this.NUP_YellowForme2.Location = new System.Drawing.Point(169, 60);
        this.NUP_YellowForme2.Name = "NUP_YellowForme2";
        this.NUP_YellowForme2.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme2.TabIndex = 446;
        // 
        // label52
        // 
        this.label52.AutoSize = true;
        this.label52.Location = new System.Drawing.Point(262, 17);
        this.label52.Name = "label52";
        this.label52.Size = new System.Drawing.Size(27, 13);
        this.label52.TabIndex = 505;
        this.label52.Text = "Max";
        // 
        // NUP_YellowMin2
        // 
        this.NUP_YellowMin2.Location = new System.Drawing.Point(216, 60);
        this.NUP_YellowMin2.Name = "NUP_YellowMin2";
        this.NUP_YellowMin2.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin2.TabIndex = 447;
        // 
        // label53
        // 
        this.label53.AutoSize = true;
        this.label53.Location = new System.Drawing.Point(42, 17);
        this.label53.Name = "label53";
        this.label53.Size = new System.Drawing.Size(77, 13);
        this.label53.TabIndex = 502;
        this.label53.Text = "Yellow Flowers";
        // 
        // NUP_YellowMax2
        // 
        this.NUP_YellowMax2.Location = new System.Drawing.Point(263, 60);
        this.NUP_YellowMax2.Name = "NUP_YellowMax2";
        this.NUP_YellowMax2.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax2.TabIndex = 448;
        // 
        // CB_Yellow12
        // 
        this.CB_Yellow12.FormattingEnabled = true;
        this.CB_Yellow12.Location = new System.Drawing.Point(42, 324);
        this.CB_Yellow12.Name = "CB_Yellow12";
        this.CB_Yellow12.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow12.TabIndex = 501;
        // 
        // NUP_YellowForme3
        // 
        this.NUP_YellowForme3.Location = new System.Drawing.Point(169, 87);
        this.NUP_YellowForme3.Name = "NUP_YellowForme3";
        this.NUP_YellowForme3.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme3.TabIndex = 449;
        // 
        // CB_Yellow11
        // 
        this.CB_Yellow11.FormattingEnabled = true;
        this.CB_Yellow11.Location = new System.Drawing.Point(42, 298);
        this.CB_Yellow11.Name = "CB_Yellow11";
        this.CB_Yellow11.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow11.TabIndex = 500;
        // 
        // NUP_YellowMin3
        // 
        this.NUP_YellowMin3.Location = new System.Drawing.Point(216, 87);
        this.NUP_YellowMin3.Name = "NUP_YellowMin3";
        this.NUP_YellowMin3.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin3.TabIndex = 450;
        // 
        // CB_Yellow10
        // 
        this.CB_Yellow10.FormattingEnabled = true;
        this.CB_Yellow10.Location = new System.Drawing.Point(42, 271);
        this.CB_Yellow10.Name = "CB_Yellow10";
        this.CB_Yellow10.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow10.TabIndex = 499;
        // 
        // NUP_YellowMax3
        // 
        this.NUP_YellowMax3.Location = new System.Drawing.Point(263, 87);
        this.NUP_YellowMax3.Name = "NUP_YellowMax3";
        this.NUP_YellowMax3.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax3.TabIndex = 451;
        // 
        // CB_Yellow9
        // 
        this.CB_Yellow9.FormattingEnabled = true;
        this.CB_Yellow9.Location = new System.Drawing.Point(42, 245);
        this.CB_Yellow9.Name = "CB_Yellow9";
        this.CB_Yellow9.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow9.TabIndex = 498;
        // 
        // NUP_YellowForme4
        // 
        this.NUP_YellowForme4.Location = new System.Drawing.Point(169, 113);
        this.NUP_YellowForme4.Name = "NUP_YellowForme4";
        this.NUP_YellowForme4.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme4.TabIndex = 452;
        // 
        // CB_Yellow8
        // 
        this.CB_Yellow8.FormattingEnabled = true;
        this.CB_Yellow8.Location = new System.Drawing.Point(42, 218);
        this.CB_Yellow8.Name = "CB_Yellow8";
        this.CB_Yellow8.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow8.TabIndex = 497;
        // 
        // NUP_YellowMin4
        // 
        this.NUP_YellowMin4.Location = new System.Drawing.Point(216, 113);
        this.NUP_YellowMin4.Name = "NUP_YellowMin4";
        this.NUP_YellowMin4.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin4.TabIndex = 453;
        // 
        // CB_Yellow7
        // 
        this.CB_Yellow7.FormattingEnabled = true;
        this.CB_Yellow7.Location = new System.Drawing.Point(42, 192);
        this.CB_Yellow7.Name = "CB_Yellow7";
        this.CB_Yellow7.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow7.TabIndex = 496;
        // 
        // NUP_YellowMax4
        // 
        this.NUP_YellowMax4.Location = new System.Drawing.Point(263, 113);
        this.NUP_YellowMax4.Name = "NUP_YellowMax4";
        this.NUP_YellowMax4.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax4.TabIndex = 454;
        // 
        // CB_Yellow6
        // 
        this.CB_Yellow6.FormattingEnabled = true;
        this.CB_Yellow6.Location = new System.Drawing.Point(42, 165);
        this.CB_Yellow6.Name = "CB_Yellow6";
        this.CB_Yellow6.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow6.TabIndex = 495;
        // 
        // NUP_YellowForme5
        // 
        this.NUP_YellowForme5.Location = new System.Drawing.Point(169, 140);
        this.NUP_YellowForme5.Name = "NUP_YellowForme5";
        this.NUP_YellowForme5.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme5.TabIndex = 455;
        // 
        // CB_Yellow5
        // 
        this.CB_Yellow5.FormattingEnabled = true;
        this.CB_Yellow5.Location = new System.Drawing.Point(42, 139);
        this.CB_Yellow5.Name = "CB_Yellow5";
        this.CB_Yellow5.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow5.TabIndex = 494;
        // 
        // NUP_YellowMin5
        // 
        this.NUP_YellowMin5.Location = new System.Drawing.Point(216, 140);
        this.NUP_YellowMin5.Name = "NUP_YellowMin5";
        this.NUP_YellowMin5.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin5.TabIndex = 456;
        // 
        // CB_Yellow4
        // 
        this.CB_Yellow4.FormattingEnabled = true;
        this.CB_Yellow4.Location = new System.Drawing.Point(42, 112);
        this.CB_Yellow4.Name = "CB_Yellow4";
        this.CB_Yellow4.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow4.TabIndex = 493;
        // 
        // NUP_YellowMax5
        // 
        this.NUP_YellowMax5.Location = new System.Drawing.Point(263, 140);
        this.NUP_YellowMax5.Name = "NUP_YellowMax5";
        this.NUP_YellowMax5.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax5.TabIndex = 457;
        // 
        // CB_Yellow3
        // 
        this.CB_Yellow3.FormattingEnabled = true;
        this.CB_Yellow3.Location = new System.Drawing.Point(42, 86);
        this.CB_Yellow3.Name = "CB_Yellow3";
        this.CB_Yellow3.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow3.TabIndex = 492;
        // 
        // NUP_YellowForme6
        // 
        this.NUP_YellowForme6.Location = new System.Drawing.Point(169, 167);
        this.NUP_YellowForme6.Name = "NUP_YellowForme6";
        this.NUP_YellowForme6.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme6.TabIndex = 458;
        // 
        // CB_Yellow2
        // 
        this.CB_Yellow2.FormattingEnabled = true;
        this.CB_Yellow2.Location = new System.Drawing.Point(42, 59);
        this.CB_Yellow2.Name = "CB_Yellow2";
        this.CB_Yellow2.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow2.TabIndex = 491;
        // 
        // NUP_YellowMin6
        // 
        this.NUP_YellowMin6.Location = new System.Drawing.Point(216, 167);
        this.NUP_YellowMin6.Name = "NUP_YellowMin6";
        this.NUP_YellowMin6.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin6.TabIndex = 459;
        // 
        // CB_Yellow1
        // 
        this.CB_Yellow1.FormattingEnabled = true;
        this.CB_Yellow1.Location = new System.Drawing.Point(42, 33);
        this.CB_Yellow1.Name = "CB_Yellow1";
        this.CB_Yellow1.Size = new System.Drawing.Size(121, 21);
        this.CB_Yellow1.TabIndex = 442;
        // 
        // NUP_YellowMax6
        // 
        this.NUP_YellowMax6.Location = new System.Drawing.Point(263, 167);
        this.NUP_YellowMax6.Name = "NUP_YellowMax6";
        this.NUP_YellowMax6.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax6.TabIndex = 460;
        // 
        // label54
        // 
        this.label54.AutoSize = true;
        this.label54.Location = new System.Drawing.Point(9, 36);
        this.label54.Name = "label54";
        this.label54.Size = new System.Drawing.Size(27, 13);
        this.label54.TabIndex = 479;
        this.label54.Text = "10%";
        // 
        // NUP_YellowForme7
        // 
        this.NUP_YellowForme7.Location = new System.Drawing.Point(169, 193);
        this.NUP_YellowForme7.Name = "NUP_YellowForme7";
        this.NUP_YellowForme7.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme7.TabIndex = 461;
        // 
        // label55
        // 
        this.label55.AutoSize = true;
        this.label55.Location = new System.Drawing.Point(15, 329);
        this.label55.Name = "label55";
        this.label55.Size = new System.Drawing.Size(21, 13);
        this.label55.TabIndex = 490;
        this.label55.Text = "1%";
        // 
        // NUP_YellowMin7
        // 
        this.NUP_YellowMin7.Location = new System.Drawing.Point(216, 193);
        this.NUP_YellowMin7.Name = "NUP_YellowMin7";
        this.NUP_YellowMin7.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin7.TabIndex = 462;
        // 
        // label56
        // 
        this.label56.AutoSize = true;
        this.label56.Location = new System.Drawing.Point(15, 302);
        this.label56.Name = "label56";
        this.label56.Size = new System.Drawing.Size(21, 13);
        this.label56.TabIndex = 489;
        this.label56.Text = "4%";
        // 
        // NUP_YellowMax7
        // 
        this.NUP_YellowMax7.Location = new System.Drawing.Point(263, 193);
        this.NUP_YellowMax7.Name = "NUP_YellowMax7";
        this.NUP_YellowMax7.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax7.TabIndex = 463;
        // 
        // label57
        // 
        this.label57.AutoSize = true;
        this.label57.Location = new System.Drawing.Point(15, 275);
        this.label57.Name = "label57";
        this.label57.Size = new System.Drawing.Size(21, 13);
        this.label57.TabIndex = 488;
        this.label57.Text = "5%";
        // 
        // NUP_YellowForme8
        // 
        this.NUP_YellowForme8.Location = new System.Drawing.Point(169, 220);
        this.NUP_YellowForme8.Name = "NUP_YellowForme8";
        this.NUP_YellowForme8.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme8.TabIndex = 464;
        // 
        // label58
        // 
        this.label58.AutoSize = true;
        this.label58.Location = new System.Drawing.Point(8, 249);
        this.label58.Name = "label58";
        this.label58.Size = new System.Drawing.Size(27, 13);
        this.label58.TabIndex = 487;
        this.label58.Text = "10%";
        // 
        // NUP_YellowMin8
        // 
        this.NUP_YellowMin8.Location = new System.Drawing.Point(216, 220);
        this.NUP_YellowMin8.Name = "NUP_YellowMin8";
        this.NUP_YellowMin8.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin8.TabIndex = 465;
        // 
        // label59
        // 
        this.label59.AutoSize = true;
        this.label59.Location = new System.Drawing.Point(8, 225);
        this.label59.Name = "label59";
        this.label59.Size = new System.Drawing.Size(27, 13);
        this.label59.TabIndex = 486;
        this.label59.Text = "10%";
        // 
        // NUP_YellowMax8
        // 
        this.NUP_YellowMax8.Location = new System.Drawing.Point(263, 220);
        this.NUP_YellowMax8.Name = "NUP_YellowMax8";
        this.NUP_YellowMax8.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax8.TabIndex = 466;
        // 
        // label60
        // 
        this.label60.AutoSize = true;
        this.label60.Location = new System.Drawing.Point(8, 198);
        this.label60.Name = "label60";
        this.label60.Size = new System.Drawing.Size(27, 13);
        this.label60.TabIndex = 485;
        this.label60.Text = "10%";
        // 
        // NUP_YellowForme9
        // 
        this.NUP_YellowForme9.Location = new System.Drawing.Point(169, 247);
        this.NUP_YellowForme9.Name = "NUP_YellowForme9";
        this.NUP_YellowForme9.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme9.TabIndex = 467;
        // 
        // label61
        // 
        this.label61.AutoSize = true;
        this.label61.Location = new System.Drawing.Point(9, 171);
        this.label61.Name = "label61";
        this.label61.Size = new System.Drawing.Size(27, 13);
        this.label61.TabIndex = 484;
        this.label61.Text = "10%";
        // 
        // NUP_YellowMin9
        // 
        this.NUP_YellowMin9.Location = new System.Drawing.Point(216, 247);
        this.NUP_YellowMin9.Name = "NUP_YellowMin9";
        this.NUP_YellowMin9.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin9.TabIndex = 468;
        // 
        // label62
        // 
        this.label62.AutoSize = true;
        this.label62.Location = new System.Drawing.Point(9, 144);
        this.label62.Name = "label62";
        this.label62.Size = new System.Drawing.Size(27, 13);
        this.label62.TabIndex = 483;
        this.label62.Text = "10%";
        // 
        // NUP_YellowMax9
        // 
        this.NUP_YellowMax9.Location = new System.Drawing.Point(263, 247);
        this.NUP_YellowMax9.Name = "NUP_YellowMax9";
        this.NUP_YellowMax9.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax9.TabIndex = 469;
        // 
        // label63
        // 
        this.label63.AutoSize = true;
        this.label63.Location = new System.Drawing.Point(9, 117);
        this.label63.Name = "label63";
        this.label63.Size = new System.Drawing.Size(27, 13);
        this.label63.TabIndex = 482;
        this.label63.Text = "10%";
        // 
        // NUP_YellowForme10
        // 
        this.NUP_YellowForme10.Location = new System.Drawing.Point(169, 273);
        this.NUP_YellowForme10.Name = "NUP_YellowForme10";
        this.NUP_YellowForme10.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowForme10.TabIndex = 470;
        // 
        // label64
        // 
        this.label64.AutoSize = true;
        this.label64.Location = new System.Drawing.Point(9, 90);
        this.label64.Name = "label64";
        this.label64.Size = new System.Drawing.Size(27, 13);
        this.label64.TabIndex = 481;
        this.label64.Text = "10%";
        // 
        // NUP_YellowMin10
        // 
        this.NUP_YellowMin10.Location = new System.Drawing.Point(216, 273);
        this.NUP_YellowMin10.Name = "NUP_YellowMin10";
        this.NUP_YellowMin10.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMin10.TabIndex = 471;
        // 
        // label65
        // 
        this.label65.AutoSize = true;
        this.label65.Location = new System.Drawing.Point(9, 63);
        this.label65.Name = "label65";
        this.label65.Size = new System.Drawing.Size(27, 13);
        this.label65.TabIndex = 480;
        this.label65.Text = "10%";
        // 
        // NUP_YellowMax10
        // 
        this.NUP_YellowMax10.Location = new System.Drawing.Point(263, 273);
        this.NUP_YellowMax10.Name = "NUP_YellowMax10";
        this.NUP_YellowMax10.Size = new System.Drawing.Size(41, 20);
        this.NUP_YellowMax10.TabIndex = 472;
        // 
        // CB_LocationID
        // 
        this.CB_LocationID.Enabled = false;
        this.CB_LocationID.FormattingEnabled = true;
        this.CB_LocationID.Location = new System.Drawing.Point(233, 8);
        this.CB_LocationID.Name = "CB_LocationID";
        this.CB_LocationID.Size = new System.Drawing.Size(164, 21);
        this.CB_LocationID.TabIndex = 407;
        this.CB_LocationID.SelectedIndexChanged += new System.EventHandler(this.CB_LocationID_SelectedIndexChanged);
        // 
        // B_Save
        // 
        this.B_Save.Enabled = false;
        this.B_Save.Location = new System.Drawing.Point(403, 7);
        this.B_Save.Name = "B_Save";
        this.B_Save.Size = new System.Drawing.Size(135, 23);
        this.B_Save.TabIndex = 410;
        this.B_Save.Text = "Save Current Encounters";
        this.B_Save.UseVisualStyleBackColor = true;
        this.B_Save.Click += new System.EventHandler(this.B_Save_Click);
        // 
        // label134
        // 
        this.label134.AutoSize = true;
        this.label134.Location = new System.Drawing.Point(201, 12);
        this.label134.Name = "label134";
        this.label134.Size = new System.Drawing.Size(28, 13);
        this.label134.TabIndex = 411;
        this.label134.Text = "Loc:";
        // 
        // label136
        // 
        this.label136.AutoSize = true;
        this.label136.Location = new System.Drawing.Point(752, 12);
        this.label136.Name = "label136";
        this.label136.Size = new System.Drawing.Size(58, 13);
        this.label136.TabIndex = 414;
        this.label136.Text = "Forme List:";
        // 
        // CB_FormeList
        // 
        this.CB_FormeList.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_FormeList.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_FormeList.DropDownWidth = 150;
        this.CB_FormeList.FormattingEnabled = true;
        this.CB_FormeList.Items.AddRange(new object[] {
            "Unown-A - 0",
            "Unown-B - 1",
            "Unown-C - 2",
            "Unown-D - 3",
            "Unown-E - 4",
            "Unown-F - 5",
            "Unown-G - 6",
            "Unown-H - 7",
            "Unown-I - 8",
            "Unown-J - 9",
            "Unown-K - 10",
            "Unown-L - 11",
            "Unown-M - 12",
            "Unown-N - 13",
            "Unown-O - 14",
            "Unown-P - 15",
            "Unown-Q - 16",
            "Unown-R - 17",
            "Unown-S - 18",
            "Unown-T - 19",
            "Unown-U - 20",
            "Unown-V - 21",
            "Unown-W - 22",
            "Unown-X - 23",
            "Unown-Y - 24",
            "Unown-Z - 25",
            "Unown-! - 26",
            "Unown-? - 27",
            "",
            "Castform-Normal - 0",
            "Castform-Sunny - 1",
            "Castform-Rainy - 2",
            "Castform-Snowy - 3",
            "",
            "Deoxys-Normal - 0",
            "Deoxys-Attack - 1",
            "Deoxys-Defense - 2",
            "Deoxys-Speed - 3",
            "",
            "Burmy-Plant Cloak - 0",
            "Burmy-Sandy Cloak - 1",
            "Burmy-Trash Cloak - 2",
            "",
            "Wormadam-Plant Cloak - 0",
            "Wormadam-Sandy Cloak - 1",
            "Wormadam-Trash Cloak - 2",
            "",
            "Cherrim-Overcast - 0",
            "Cherrim-Sunshine - 1",
            "",
            "Shellos-West Sea - 0",
            "Shellos-East Sea - 1",
            "",
            "Gastrodon-West Sea - 0",
            "Gastrodon-East Sea - 1",
            "",
            "Rotom-Normal - 0",
            "Rotom-Heat - 1",
            "Rotom-Wash - 2",
            "Rotom-Frost - 3",
            "Rotom-Fan - 4",
            "Rotom-Mow - 5",
            "",
            "Giratina-Altered - 0",
            "Giratina-Origin - 1",
            "",
            "Shaymin-Land - 0",
            "Shaymin-Sky - 1",
            "",
            "Arceus-Normal - 0",
            "Arceus-Fighting - 1",
            "Arceus-Flying - 2",
            "Arceus-Poison - 3",
            "Arceus-Ground - 4",
            "Arceus-Rock - 5",
            "Arceus-Bug - 6",
            "Arceus-Ghost - 7",
            "Arceus-Steel - 8",
            "Arceus-Fire - 9",
            "Arceus-Water - 10",
            "Arceus-Grass - 11",
            "Arceus-Electric - 12",
            "Arceus-Psychic - 13",
            "Arceus-Ice - 14",
            "Arceus-Dragon - 15",
            "Arceus-Dark - 16",
            "",
            "Basculin-Red-Striped - 0",
            "Basculin-Blue-Striped - 1",
            "",
            "Darmanitan-Standard Mode - 0",
            "Darmanitan-Zen Mode - 1",
            "",
            "Deerling-Spring - 0",
            "Deerling-Summer - 1",
            "Deerling-Autumn - 2",
            "Deerling-Winter - 3",
            "",
            "Sawsbuck-Spring - 0",
            "Sawsbuck-Summer - 1",
            "Sawsbuck-Autumn - 2",
            "Sawsbuck-Winter - 3",
            "",
            "Tornadus-Incarnate - 0",
            "Tornadus-Therian - 1",
            "",
            "Thundurus-Incarnate - 0",
            "Thundurus-Therian - 1",
            "",
            "Landorus-Incarnate - 0",
            "Landorus-Therian - 1",
            "",
            "Kyurem-Normal - 0",
            "Kyurem-White - 1",
            "Kyurem-Black - 2",
            "",
            "Keldeo-Usual - 0",
            "Keldeo-Resolution - 1",
            "",
            "Meloetta-Aria - 0",
            "Meloetta-Pirouette - 1",
            "",
            "Genesect-Normal - 0",
            "Genesect-Water - 1",
            "Genesect-Electric - 2",
            "Genesect-Fire - 3",
            "Genesect-Ice - 4"});
        this.CB_FormeList.Location = new System.Drawing.Point(816, 8);
        this.CB_FormeList.Name = "CB_FormeList";
        this.CB_FormeList.Size = new System.Drawing.Size(108, 21);
        this.CB_FormeList.TabIndex = 413;
        // 
        // B_Randomize
        // 
        this.B_Randomize.Enabled = false;
        this.B_Randomize.Location = new System.Drawing.Point(544, 7);
        this.B_Randomize.Name = "B_Randomize";
        this.B_Randomize.Size = new System.Drawing.Size(95, 23);
        this.B_Randomize.TabIndex = 417;
        this.B_Randomize.Text = "Randomize All";
        this.B_Randomize.UseVisualStyleBackColor = true;
        this.B_Randomize.Click += new System.EventHandler(this.B_Randomize_Click);
        // 
        // B_Dump
        // 
        this.B_Dump.Enabled = false;
        this.B_Dump.Location = new System.Drawing.Point(645, 7);
        this.B_Dump.Name = "B_Dump";
        this.B_Dump.Size = new System.Drawing.Size(95, 23);
        this.B_Dump.TabIndex = 418;
        this.B_Dump.Text = "Dump Tables";
        this.B_Dump.UseVisualStyleBackColor = true;
        this.B_Dump.Click += new System.EventHandler(this.B_Dump_Click);
        // 
        // XYWE
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(948, 415);
        this.Controls.Add(this.B_Dump);
        this.Controls.Add(this.B_Randomize);
        this.Controls.Add(this.label136);
        this.Controls.Add(this.CB_FormeList);
        this.Controls.Add(this.label134);
        this.Controls.Add(this.B_Save);
        this.Controls.Add(this.CB_LocationID);
        this.Controls.Add(this.TabControl_EncounterData);
        this.MaximizeBox = false;
        this.MaximumSize = new System.Drawing.Size(964, 454);
        this.MinimumSize = new System.Drawing.Size(964, 454);
        this.Name = "XYWE";
        this.Text = "XY Wild Editor";
        this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.XYWE_FormClosing);
        this.Load += new System.EventHandler(this.PreloadTabs);
        this.TabControl_EncounterData.ResumeLayout(false);
        this.TabPage_Land.ResumeLayout(false);
        this.TabPage_Land.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RockSmashMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTForme12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMin12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RTMax12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMin11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassForme12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GrassMax11)).EndInit();
        this.TabPage_Water.ResumeLayout(false);
        this.TabPage_Water.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SuperMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_SurfForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_GoodMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_OldMax3)).EndInit();
        this.TabPage_Horde.ResumeLayout(false);
        this.TabPage_Horde.PerformLayout();
        this.GB_Tweak.ResumeLayout(false);
        this.GB_Tweak.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_LevelAmp)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeCForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeBForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_HordeAMax3)).EndInit();
        this.tabPage1.ResumeLayout(false);
        this.tabPage1.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedForme10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMin10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_RedMax10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleForme10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMin10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_PurpleMax10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowForme10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMin10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_YellowMax10)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TabControl TabControl_EncounterData;
    private System.Windows.Forms.TabPage TabPage_Land;
    private System.Windows.Forms.NumericUpDown NUP_RTForme1;
    private System.Windows.Forms.NumericUpDown NUP_RTMin1;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.NumericUpDown NUP_RTMax1;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.NumericUpDown NUP_RTForme2;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.NumericUpDown NUP_RTMin2;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.NumericUpDown NUP_RTMax2;
    private System.Windows.Forms.ComboBox CB_RT12;
    private System.Windows.Forms.NumericUpDown NUP_RTForme3;
    private System.Windows.Forms.ComboBox CB_RT11;
    private System.Windows.Forms.NumericUpDown NUP_RTMin3;
    private System.Windows.Forms.ComboBox CB_RT10;
    private System.Windows.Forms.NumericUpDown NUP_RTMax3;
    private System.Windows.Forms.ComboBox CB_RT9;
    private System.Windows.Forms.NumericUpDown NUP_RTForme4;
    private System.Windows.Forms.ComboBox CB_RT8;
    private System.Windows.Forms.NumericUpDown NUP_RTMin4;
    private System.Windows.Forms.ComboBox CB_RT7;
    private System.Windows.Forms.NumericUpDown NUP_RTMax4;
    private System.Windows.Forms.ComboBox CB_RT6;
    private System.Windows.Forms.NumericUpDown NUP_RTForme5;
    private System.Windows.Forms.ComboBox CB_RT5;
    private System.Windows.Forms.NumericUpDown NUP_RTMin5;
    private System.Windows.Forms.ComboBox CB_RT4;
    private System.Windows.Forms.NumericUpDown NUP_RTMax5;
    private System.Windows.Forms.ComboBox CB_RT3;
    private System.Windows.Forms.NumericUpDown NUP_RTForme6;
    private System.Windows.Forms.ComboBox CB_RT2;
    private System.Windows.Forms.NumericUpDown NUP_RTMin6;
    private System.Windows.Forms.ComboBox CB_RT1;
    private System.Windows.Forms.NumericUpDown NUP_RTMax6;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.NumericUpDown NUP_RTForme7;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.NumericUpDown NUP_RTMin7;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.NumericUpDown NUP_RTMax7;
    private System.Windows.Forms.Label label13;
    private System.Windows.Forms.NumericUpDown NUP_RTForme8;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.NumericUpDown NUP_RTMin8;
    private System.Windows.Forms.Label label15;
    private System.Windows.Forms.NumericUpDown NUP_RTMax8;
    private System.Windows.Forms.Label label16;
    private System.Windows.Forms.NumericUpDown NUP_RTForme9;
    private System.Windows.Forms.Label label17;
    private System.Windows.Forms.NumericUpDown NUP_RTMin9;
    private System.Windows.Forms.Label label18;
    private System.Windows.Forms.NumericUpDown NUP_RTMax9;
    private System.Windows.Forms.Label label19;
    private System.Windows.Forms.NumericUpDown NUP_RTForme10;
    private System.Windows.Forms.Label label20;
    private System.Windows.Forms.NumericUpDown NUP_RTMin10;
    private System.Windows.Forms.Label label21;
    private System.Windows.Forms.NumericUpDown NUP_RTMax10;
    private System.Windows.Forms.NumericUpDown NUP_RTForme11;
    private System.Windows.Forms.NumericUpDown NUP_RTMin11;
    private System.Windows.Forms.NumericUpDown NUP_RTMax11;
    private System.Windows.Forms.NumericUpDown NUP_RTForme12;
    private System.Windows.Forms.NumericUpDown NUP_RTMin12;
    private System.Windows.Forms.NumericUpDown NUP_RTMax12;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme1;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin1;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax1;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme2;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin2;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax2;
    private System.Windows.Forms.ComboBox CB_Grass12;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme3;
    private System.Windows.Forms.ComboBox CB_Grass11;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin3;
    private System.Windows.Forms.ComboBox CB_Grass10;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax3;
    private System.Windows.Forms.ComboBox CB_Grass9;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme4;
    private System.Windows.Forms.ComboBox CB_Grass8;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin4;
    private System.Windows.Forms.ComboBox CB_Grass7;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax4;
    private System.Windows.Forms.ComboBox CB_Grass6;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme5;
    private System.Windows.Forms.ComboBox CB_Grass5;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin5;
    private System.Windows.Forms.ComboBox CB_Grass4;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax5;
    private System.Windows.Forms.ComboBox CB_Grass3;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme6;
    private System.Windows.Forms.ComboBox CB_Grass2;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin6;
    private System.Windows.Forms.ComboBox CB_Grass1;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax6;
    private System.Windows.Forms.Label label31;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme7;
    private System.Windows.Forms.Label label41;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin7;
    private System.Windows.Forms.Label label42;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax7;
    private System.Windows.Forms.Label label40;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme8;
    private System.Windows.Forms.Label label39;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin8;
    private System.Windows.Forms.Label label38;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax8;
    private System.Windows.Forms.Label label37;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme9;
    private System.Windows.Forms.Label label36;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin9;
    private System.Windows.Forms.Label label35;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax9;
    private System.Windows.Forms.Label label34;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme10;
    private System.Windows.Forms.Label label33;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin10;
    private System.Windows.Forms.Label label32;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax10;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax12;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme11;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin12;
    private System.Windows.Forms.NumericUpDown NUP_GrassMin11;
    private System.Windows.Forms.NumericUpDown NUP_GrassForme12;
    private System.Windows.Forms.NumericUpDown NUP_GrassMax11;
    private System.Windows.Forms.TabPage TabPage_Water;
    private System.Windows.Forms.TabPage TabPage_Horde;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.NumericUpDown NUP_RedForme1;
    private System.Windows.Forms.NumericUpDown NUP_RedMin1;
    private System.Windows.Forms.Label label82;
    private System.Windows.Forms.NumericUpDown NUP_RedMax1;
    private System.Windows.Forms.Label label83;
    private System.Windows.Forms.NumericUpDown NUP_RedForme2;
    private System.Windows.Forms.Label label84;
    private System.Windows.Forms.NumericUpDown NUP_RedMin2;
    private System.Windows.Forms.Label label85;
    private System.Windows.Forms.NumericUpDown NUP_RedMax2;
    private System.Windows.Forms.ComboBox CB_Purple12;
    private System.Windows.Forms.NumericUpDown NUP_RedForme3;
    private System.Windows.Forms.ComboBox CB_Purple11;
    private System.Windows.Forms.NumericUpDown NUP_RedMin3;
    private System.Windows.Forms.ComboBox CB_Purple10;
    private System.Windows.Forms.NumericUpDown NUP_RedMax3;
    private System.Windows.Forms.ComboBox CB_Purple9;
    private System.Windows.Forms.NumericUpDown NUP_RedForme4;
    private System.Windows.Forms.ComboBox CB_Purple8;
    private System.Windows.Forms.NumericUpDown NUP_RedMin4;
    private System.Windows.Forms.ComboBox CB_Purple7;
    private System.Windows.Forms.NumericUpDown NUP_RedMax4;
    private System.Windows.Forms.ComboBox CB_Purple6;
    private System.Windows.Forms.NumericUpDown NUP_RedForme5;
    private System.Windows.Forms.ComboBox CB_Purple5;
    private System.Windows.Forms.NumericUpDown NUP_RedMin5;
    private System.Windows.Forms.ComboBox CB_Purple4;
    private System.Windows.Forms.NumericUpDown NUP_RedMax5;
    private System.Windows.Forms.ComboBox CB_Purple3;
    private System.Windows.Forms.NumericUpDown NUP_RedForme6;
    private System.Windows.Forms.ComboBox CB_Purple2;
    private System.Windows.Forms.NumericUpDown NUP_RedMin6;
    private System.Windows.Forms.ComboBox CB_Purple1;
    private System.Windows.Forms.NumericUpDown NUP_RedMax6;
    private System.Windows.Forms.Label label86;
    private System.Windows.Forms.NumericUpDown NUP_RedForme7;
    private System.Windows.Forms.Label label87;
    private System.Windows.Forms.NumericUpDown NUP_RedMin7;
    private System.Windows.Forms.Label label88;
    private System.Windows.Forms.NumericUpDown NUP_RedMax7;
    private System.Windows.Forms.Label label89;
    private System.Windows.Forms.NumericUpDown NUP_RedForme8;
    private System.Windows.Forms.Label label90;
    private System.Windows.Forms.NumericUpDown NUP_RedMin8;
    private System.Windows.Forms.Label label91;
    private System.Windows.Forms.NumericUpDown NUP_RedMax8;
    private System.Windows.Forms.Label label92;
    private System.Windows.Forms.NumericUpDown NUP_RedForme9;
    private System.Windows.Forms.Label label93;
    private System.Windows.Forms.NumericUpDown NUP_RedMin9;
    private System.Windows.Forms.Label label94;
    private System.Windows.Forms.NumericUpDown NUP_RedMax9;
    private System.Windows.Forms.Label label95;
    private System.Windows.Forms.NumericUpDown NUP_RedForme10;
    private System.Windows.Forms.Label label96;
    private System.Windows.Forms.NumericUpDown NUP_RedMin10;
    private System.Windows.Forms.Label label97;
    private System.Windows.Forms.NumericUpDown NUP_RedMax10;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme1;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin1;
    private System.Windows.Forms.Label label66;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax1;
    private System.Windows.Forms.Label label67;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme2;
    private System.Windows.Forms.Label label68;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin2;
    private System.Windows.Forms.Label label69;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax2;
    private System.Windows.Forms.ComboBox CB_Red12;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme3;
    private System.Windows.Forms.ComboBox CB_Red11;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin3;
    private System.Windows.Forms.ComboBox CB_Red10;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax3;
    private System.Windows.Forms.ComboBox CB_Red9;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme4;
    private System.Windows.Forms.ComboBox CB_Red8;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin4;
    private System.Windows.Forms.ComboBox CB_Red7;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax4;
    private System.Windows.Forms.ComboBox CB_Red6;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme5;
    private System.Windows.Forms.ComboBox CB_Red5;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin5;
    private System.Windows.Forms.ComboBox CB_Red4;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax5;
    private System.Windows.Forms.ComboBox CB_Red3;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme6;
    private System.Windows.Forms.ComboBox CB_Red2;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin6;
    private System.Windows.Forms.ComboBox CB_Red1;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax6;
    private System.Windows.Forms.Label label70;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme7;
    private System.Windows.Forms.Label label71;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin7;
    private System.Windows.Forms.Label label72;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax7;
    private System.Windows.Forms.Label label73;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme8;
    private System.Windows.Forms.Label label74;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin8;
    private System.Windows.Forms.Label label75;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax8;
    private System.Windows.Forms.Label label76;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme9;
    private System.Windows.Forms.Label label77;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin9;
    private System.Windows.Forms.Label label78;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax9;
    private System.Windows.Forms.Label label79;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme10;
    private System.Windows.Forms.Label label80;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin10;
    private System.Windows.Forms.Label label81;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax10;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme1;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin1;
    private System.Windows.Forms.Label label50;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax1;
    private System.Windows.Forms.Label label51;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme2;
    private System.Windows.Forms.Label label52;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin2;
    private System.Windows.Forms.Label label53;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax2;
    private System.Windows.Forms.ComboBox CB_Yellow12;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme3;
    private System.Windows.Forms.ComboBox CB_Yellow11;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin3;
    private System.Windows.Forms.ComboBox CB_Yellow10;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax3;
    private System.Windows.Forms.ComboBox CB_Yellow9;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme4;
    private System.Windows.Forms.ComboBox CB_Yellow8;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin4;
    private System.Windows.Forms.ComboBox CB_Yellow7;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax4;
    private System.Windows.Forms.ComboBox CB_Yellow6;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme5;
    private System.Windows.Forms.ComboBox CB_Yellow5;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin5;
    private System.Windows.Forms.ComboBox CB_Yellow4;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax5;
    private System.Windows.Forms.ComboBox CB_Yellow3;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme6;
    private System.Windows.Forms.ComboBox CB_Yellow2;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin6;
    private System.Windows.Forms.ComboBox CB_Yellow1;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax6;
    private System.Windows.Forms.Label label54;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme7;
    private System.Windows.Forms.Label label55;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin7;
    private System.Windows.Forms.Label label56;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax7;
    private System.Windows.Forms.Label label57;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme8;
    private System.Windows.Forms.Label label58;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin8;
    private System.Windows.Forms.Label label59;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax8;
    private System.Windows.Forms.Label label60;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme9;
    private System.Windows.Forms.Label label61;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin9;
    private System.Windows.Forms.Label label62;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax9;
    private System.Windows.Forms.Label label63;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme10;
    private System.Windows.Forms.Label label64;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin10;
    private System.Windows.Forms.Label label65;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax10;
    private System.Windows.Forms.NumericUpDown NUP_RedForme11;
    private System.Windows.Forms.NumericUpDown NUP_RedMin11;
    private System.Windows.Forms.NumericUpDown NUP_RedMax11;
    private System.Windows.Forms.NumericUpDown NUP_RedForme12;
    private System.Windows.Forms.NumericUpDown NUP_RedMin12;
    private System.Windows.Forms.NumericUpDown NUP_RedMax12;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme11;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin11;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax11;
    private System.Windows.Forms.NumericUpDown NUP_PurpleForme12;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMin12;
    private System.Windows.Forms.NumericUpDown NUP_PurpleMax12;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme11;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin11;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax11;
    private System.Windows.Forms.NumericUpDown NUP_YellowForme12;
    private System.Windows.Forms.NumericUpDown NUP_YellowMin12;
    private System.Windows.Forms.NumericUpDown NUP_YellowMax12;
    private System.Windows.Forms.Label label22;
    private System.Windows.Forms.ComboBox CB_Old1;
    private System.Windows.Forms.NumericUpDown NUP_OldForme1;
    private System.Windows.Forms.NumericUpDown NUP_OldMin1;
    private System.Windows.Forms.NumericUpDown NUP_OldMax1;
    private System.Windows.Forms.ComboBox CB_Old2;
    private System.Windows.Forms.NumericUpDown NUP_OldForme2;
    private System.Windows.Forms.NumericUpDown NUP_OldMin2;
    private System.Windows.Forms.NumericUpDown NUP_OldMax2;
    private System.Windows.Forms.ComboBox CB_Old3;
    private System.Windows.Forms.NumericUpDown NUP_OldForme3;
    private System.Windows.Forms.NumericUpDown NUP_OldMin3;
    private System.Windows.Forms.NumericUpDown NUP_OldMax3;
    private System.Windows.Forms.Label label45;
    private System.Windows.Forms.Label label44;
    private System.Windows.Forms.Label label43;
    private System.Windows.Forms.Label label23;
    private System.Windows.Forms.Label label24;
    private System.Windows.Forms.Label label25;
    private System.Windows.Forms.Label label103;
    private System.Windows.Forms.Label label48;
    private System.Windows.Forms.Label label104;
    private System.Windows.Forms.ComboBox CB_Super1;
    private System.Windows.Forms.Label label105;
    private System.Windows.Forms.NumericUpDown NUP_SuperForme1;
    private System.Windows.Forms.Label label106;
    private System.Windows.Forms.ComboBox CB_Surf1;
    private System.Windows.Forms.NumericUpDown NUP_SuperMin1;
    private System.Windows.Forms.NumericUpDown NUP_SurfForme1;
    private System.Windows.Forms.NumericUpDown NUP_SuperMax1;
    private System.Windows.Forms.NumericUpDown NUP_SurfMin1;
    private System.Windows.Forms.ComboBox CB_Super2;
    private System.Windows.Forms.NumericUpDown NUP_SurfMax1;
    private System.Windows.Forms.NumericUpDown NUP_SuperForme2;
    private System.Windows.Forms.ComboBox CB_Surf2;
    private System.Windows.Forms.NumericUpDown NUP_SuperMin2;
    private System.Windows.Forms.NumericUpDown NUP_SurfForme2;
    private System.Windows.Forms.NumericUpDown NUP_SuperMax2;
    private System.Windows.Forms.NumericUpDown NUP_SurfMin2;
    private System.Windows.Forms.ComboBox CB_Super3;
    private System.Windows.Forms.NumericUpDown NUP_SurfMax5;
    private System.Windows.Forms.NumericUpDown NUP_SuperForme3;
    private System.Windows.Forms.NumericUpDown NUP_SurfMax2;
    private System.Windows.Forms.NumericUpDown NUP_SuperMin3;
    private System.Windows.Forms.NumericUpDown NUP_SurfMin5;
    private System.Windows.Forms.NumericUpDown NUP_SuperMax3;
    private System.Windows.Forms.ComboBox CB_Surf3;
    private System.Windows.Forms.Label label49;
    private System.Windows.Forms.NumericUpDown NUP_SurfForme5;
    private System.Windows.Forms.Label label98;
    private System.Windows.Forms.NumericUpDown NUP_SurfForme3;
    private System.Windows.Forms.Label label99;
    private System.Windows.Forms.ComboBox CB_Surf5;
    private System.Windows.Forms.Label label100;
    private System.Windows.Forms.NumericUpDown NUP_SurfMin3;
    private System.Windows.Forms.Label label101;
    private System.Windows.Forms.NumericUpDown NUP_SurfMax4;
    private System.Windows.Forms.Label label102;
    private System.Windows.Forms.NumericUpDown NUP_SurfMax3;
    private System.Windows.Forms.Label label26;
    private System.Windows.Forms.NumericUpDown NUP_SurfMin4;
    private System.Windows.Forms.ComboBox CB_Good1;
    private System.Windows.Forms.ComboBox CB_Surf4;
    private System.Windows.Forms.NumericUpDown NUP_GoodForme1;
    private System.Windows.Forms.NumericUpDown NUP_SurfForme4;
    private System.Windows.Forms.NumericUpDown NUP_GoodMin1;
    private System.Windows.Forms.NumericUpDown NUP_GoodMax1;
    private System.Windows.Forms.ComboBox CB_Good2;
    private System.Windows.Forms.NumericUpDown NUP_GoodForme2;
    private System.Windows.Forms.NumericUpDown NUP_GoodMin2;
    private System.Windows.Forms.NumericUpDown NUP_GoodMax2;
    private System.Windows.Forms.ComboBox CB_Good3;
    private System.Windows.Forms.NumericUpDown NUP_GoodForme3;
    private System.Windows.Forms.NumericUpDown NUP_GoodMin3;
    private System.Windows.Forms.NumericUpDown NUP_GoodMax3;
    private System.Windows.Forms.Label label27;
    private System.Windows.Forms.Label label28;
    private System.Windows.Forms.Label label29;
    private System.Windows.Forms.Label label30;
    private System.Windows.Forms.Label label46;
    private System.Windows.Forms.Label label47;
    private System.Windows.Forms.Label label116;
    private System.Windows.Forms.Label label117;
    private System.Windows.Forms.Label label118;
    private System.Windows.Forms.Label label119;
    private System.Windows.Forms.Label label120;
    private System.Windows.Forms.Label label107;
    private System.Windows.Forms.Label label115;
    private System.Windows.Forms.Label label108;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMax5;
    private System.Windows.Forms.Label label109;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMin5;
    private System.Windows.Forms.Label label110;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashForme5;
    private System.Windows.Forms.Label label111;
    private System.Windows.Forms.ComboBox CB_RockSmash5;
    private System.Windows.Forms.ComboBox CB_RockSmash1;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMax4;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashForme1;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMin4;
    private System.Windows.Forms.Label label112;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashForme4;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMin1;
    private System.Windows.Forms.ComboBox CB_RockSmash4;
    private System.Windows.Forms.Label label113;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMax3;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMax1;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMin3;
    private System.Windows.Forms.Label label114;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashForme3;
    private System.Windows.Forms.ComboBox CB_RockSmash2;
    private System.Windows.Forms.ComboBox CB_RockSmash3;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMax2;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashForme2;
    private System.Windows.Forms.NumericUpDown NUP_RockSmashMin2;
    private System.Windows.Forms.Label label121;
    private System.Windows.Forms.Label label124;
    private System.Windows.Forms.Label label122;
    private System.Windows.Forms.ComboBox CB_HordeA1;
    private System.Windows.Forms.Label label123;
    private System.Windows.Forms.NumericUpDown NUP_HordeAForme1;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMin1;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMax5;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMax1;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMin5;
    private System.Windows.Forms.ComboBox CB_HordeA2;
    private System.Windows.Forms.NumericUpDown NUP_HordeAForme5;
    private System.Windows.Forms.NumericUpDown NUP_HordeAForme2;
    private System.Windows.Forms.ComboBox CB_HordeA5;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMin2;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMax4;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMax2;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMin4;
    private System.Windows.Forms.ComboBox CB_HordeA3;
    private System.Windows.Forms.NumericUpDown NUP_HordeAForme4;
    private System.Windows.Forms.NumericUpDown NUP_HordeAForme3;
    private System.Windows.Forms.ComboBox CB_HordeA4;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMin3;
    private System.Windows.Forms.NumericUpDown NUP_HordeAMax3;
    private System.Windows.Forms.Label label125;
    private System.Windows.Forms.Label label126;
    private System.Windows.Forms.Label label127;
    private System.Windows.Forms.Label label128;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMax5;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMin5;
    private System.Windows.Forms.NumericUpDown NUP_HordeBForme5;
    private System.Windows.Forms.ComboBox CB_HordeB5;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMax4;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMin4;
    private System.Windows.Forms.NumericUpDown NUP_HordeBForme4;
    private System.Windows.Forms.ComboBox CB_HordeB4;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMax3;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMin3;
    private System.Windows.Forms.NumericUpDown NUP_HordeBForme3;
    private System.Windows.Forms.ComboBox CB_HordeB3;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMax2;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMin2;
    private System.Windows.Forms.NumericUpDown NUP_HordeBForme2;
    private System.Windows.Forms.ComboBox CB_HordeB2;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMax1;
    private System.Windows.Forms.NumericUpDown NUP_HordeBMin1;
    private System.Windows.Forms.NumericUpDown NUP_HordeBForme1;
    private System.Windows.Forms.ComboBox CB_HordeB1;
    private System.Windows.Forms.Label label129;
    private System.Windows.Forms.Label label130;
    private System.Windows.Forms.Label label131;
    private System.Windows.Forms.Label label132;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMax5;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMin5;
    private System.Windows.Forms.NumericUpDown NUP_HordeCForme5;
    private System.Windows.Forms.ComboBox CB_HordeC5;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMax4;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMin4;
    private System.Windows.Forms.NumericUpDown NUP_HordeCForme4;
    private System.Windows.Forms.ComboBox CB_HordeC4;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMax3;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMin3;
    private System.Windows.Forms.NumericUpDown NUP_HordeCForme3;
    private System.Windows.Forms.ComboBox CB_HordeC3;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMax2;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMin2;
    private System.Windows.Forms.NumericUpDown NUP_HordeCForme2;
    private System.Windows.Forms.ComboBox CB_HordeC2;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMax1;
    private System.Windows.Forms.NumericUpDown NUP_HordeCMin1;
    private System.Windows.Forms.NumericUpDown NUP_HordeCForme1;
    private System.Windows.Forms.ComboBox CB_HordeC1;
    private System.Windows.Forms.ComboBox CB_LocationID;
    private System.Windows.Forms.Button B_Save;
    private System.Windows.Forms.Label label134;
    private System.Windows.Forms.Label label136;
    private System.Windows.Forms.ComboBox CB_FormeList;
    private System.Windows.Forms.Button B_Randomize;
    private System.Windows.Forms.Button B_Dump;
    private System.Windows.Forms.GroupBox GB_Tweak;
    private System.Windows.Forms.Label L_RandOpt;
    private System.Windows.Forms.CheckBox CHK_BST;
    private System.Windows.Forms.CheckBox CHK_E;
    private System.Windows.Forms.CheckBox CHK_L;
    private System.Windows.Forms.CheckBox CHK_G6;
    private System.Windows.Forms.CheckBox CHK_G5;
    private System.Windows.Forms.CheckBox CHK_G4;
    private System.Windows.Forms.CheckBox CHK_G3;
    private System.Windows.Forms.CheckBox CHK_G2;
    private System.Windows.Forms.CheckBox CHK_G1;
    private System.Windows.Forms.Button B_LevelPlus;
    private System.Windows.Forms.NumericUpDown NUD_LevelAmp;
    private System.Windows.Forms.CheckBox CHK_Level;
    private System.Windows.Forms.CheckBox CHK_MegaForm;
    private System.Windows.Forms.CheckBox CHK_HomogeneousHordes;
}