﻿namespace pk3DS.WinForms;

partial class StarterEditor6
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.PB_G1_0 = new System.Windows.Forms.PictureBox();
        this.CB_G1_0 = new System.Windows.Forms.ComboBox();
        this.CB_G1_1 = new System.Windows.Forms.ComboBox();
        this.PB_G1_1 = new System.Windows.Forms.PictureBox();
        this.CB_G1_2 = new System.Windows.Forms.ComboBox();
        this.PB_G1_2 = new System.Windows.Forms.PictureBox();
        this.CB_G2_2 = new System.Windows.Forms.ComboBox();
        this.PB_G2_2 = new System.Windows.Forms.PictureBox();
        this.CB_G2_1 = new System.Windows.Forms.ComboBox();
        this.PB_G2_1 = new System.Windows.Forms.PictureBox();
        this.CB_G2_0 = new System.Windows.Forms.ComboBox();
        this.PB_G2_0 = new System.Windows.Forms.PictureBox();
        this.CB_G3_2 = new System.Windows.Forms.ComboBox();
        this.PB_G3_2 = new System.Windows.Forms.PictureBox();
        this.CB_G3_1 = new System.Windows.Forms.ComboBox();
        this.PB_G3_1 = new System.Windows.Forms.PictureBox();
        this.CB_G3_0 = new System.Windows.Forms.ComboBox();
        this.PB_G3_0 = new System.Windows.Forms.PictureBox();
        this.CB_G4_2 = new System.Windows.Forms.ComboBox();
        this.PB_G4_2 = new System.Windows.Forms.PictureBox();
        this.CB_G4_1 = new System.Windows.Forms.ComboBox();
        this.PB_G4_1 = new System.Windows.Forms.PictureBox();
        this.CB_G4_0 = new System.Windows.Forms.ComboBox();
        this.PB_G4_0 = new System.Windows.Forms.PictureBox();
        this.B_Save = new System.Windows.Forms.Button();
        this.B_Randomize = new System.Windows.Forms.Button();
        this.L_Set1 = new System.Windows.Forms.Label();
        this.L_Set3 = new System.Windows.Forms.Label();
        this.L_Set4 = new System.Windows.Forms.Label();
        this.L_Set2 = new System.Windows.Forms.Label();
        this.CHK_Gen = new System.Windows.Forms.CheckBox();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.CHK_E = new System.Windows.Forms.CheckBox();
        this.CHK_L = new System.Windows.Forms.CheckBox();
        this.CHK_BasicStarter = new System.Windows.Forms.CheckBox();
        this.B_Cancel = new System.Windows.Forms.Button();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G1_0)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G1_1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G1_2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G2_2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G2_1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G2_0)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G3_2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G3_1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G3_0)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G4_2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G4_1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G4_0)).BeginInit();
        this.groupBox1.SuspendLayout();
        this.SuspendLayout();
        // 
        // PB_G1_0
        // 
        this.PB_G1_0.Location = new System.Drawing.Point(12, 20);
        this.PB_G1_0.Name = "PB_G1_0";
        this.PB_G1_0.Size = new System.Drawing.Size(120, 90);
        this.PB_G1_0.TabIndex = 440;
        this.PB_G1_0.TabStop = false;
        // 
        // CB_G1_0
        // 
        this.CB_G1_0.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G1_0.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G1_0.FormattingEnabled = true;
        this.CB_G1_0.Location = new System.Drawing.Point(12, 116);
        this.CB_G1_0.Name = "CB_G1_0";
        this.CB_G1_0.Size = new System.Drawing.Size(120, 21);
        this.CB_G1_0.TabIndex = 441;
        this.CB_G1_0.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // CB_G1_1
        // 
        this.CB_G1_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G1_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G1_1.FormattingEnabled = true;
        this.CB_G1_1.Location = new System.Drawing.Point(138, 116);
        this.CB_G1_1.Name = "CB_G1_1";
        this.CB_G1_1.Size = new System.Drawing.Size(120, 21);
        this.CB_G1_1.TabIndex = 443;
        this.CB_G1_1.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G1_1
        // 
        this.PB_G1_1.Location = new System.Drawing.Point(138, 20);
        this.PB_G1_1.Name = "PB_G1_1";
        this.PB_G1_1.Size = new System.Drawing.Size(120, 90);
        this.PB_G1_1.TabIndex = 442;
        this.PB_G1_1.TabStop = false;
        // 
        // CB_G1_2
        // 
        this.CB_G1_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G1_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G1_2.FormattingEnabled = true;
        this.CB_G1_2.Location = new System.Drawing.Point(264, 116);
        this.CB_G1_2.Name = "CB_G1_2";
        this.CB_G1_2.Size = new System.Drawing.Size(120, 21);
        this.CB_G1_2.TabIndex = 445;
        this.CB_G1_2.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G1_2
        // 
        this.PB_G1_2.Location = new System.Drawing.Point(264, 20);
        this.PB_G1_2.Name = "PB_G1_2";
        this.PB_G1_2.Size = new System.Drawing.Size(120, 90);
        this.PB_G1_2.TabIndex = 444;
        this.PB_G1_2.TabStop = false;
        // 
        // CB_G2_2
        // 
        this.CB_G2_2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
        this.CB_G2_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G2_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G2_2.FormattingEnabled = true;
        this.CB_G2_2.Location = new System.Drawing.Point(264, 254);
        this.CB_G2_2.Name = "CB_G2_2";
        this.CB_G2_2.Size = new System.Drawing.Size(120, 21);
        this.CB_G2_2.TabIndex = 451;
        this.CB_G2_2.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G2_2
        // 
        this.PB_G2_2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
        this.PB_G2_2.Location = new System.Drawing.Point(264, 158);
        this.PB_G2_2.Name = "PB_G2_2";
        this.PB_G2_2.Size = new System.Drawing.Size(120, 90);
        this.PB_G2_2.TabIndex = 450;
        this.PB_G2_2.TabStop = false;
        // 
        // CB_G2_1
        // 
        this.CB_G2_1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
        this.CB_G2_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G2_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G2_1.FormattingEnabled = true;
        this.CB_G2_1.Location = new System.Drawing.Point(138, 254);
        this.CB_G2_1.Name = "CB_G2_1";
        this.CB_G2_1.Size = new System.Drawing.Size(120, 21);
        this.CB_G2_1.TabIndex = 449;
        this.CB_G2_1.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G2_1
        // 
        this.PB_G2_1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
        this.PB_G2_1.Location = new System.Drawing.Point(138, 158);
        this.PB_G2_1.Name = "PB_G2_1";
        this.PB_G2_1.Size = new System.Drawing.Size(120, 90);
        this.PB_G2_1.TabIndex = 448;
        this.PB_G2_1.TabStop = false;
        // 
        // CB_G2_0
        // 
        this.CB_G2_0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
        this.CB_G2_0.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G2_0.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G2_0.FormattingEnabled = true;
        this.CB_G2_0.Location = new System.Drawing.Point(12, 254);
        this.CB_G2_0.Name = "CB_G2_0";
        this.CB_G2_0.Size = new System.Drawing.Size(120, 21);
        this.CB_G2_0.TabIndex = 447;
        this.CB_G2_0.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G2_0
        // 
        this.PB_G2_0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
        this.PB_G2_0.Location = new System.Drawing.Point(12, 158);
        this.PB_G2_0.Name = "PB_G2_0";
        this.PB_G2_0.Size = new System.Drawing.Size(120, 90);
        this.PB_G2_0.TabIndex = 446;
        this.PB_G2_0.TabStop = false;
        // 
        // CB_G3_2
        // 
        this.CB_G3_2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.CB_G3_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G3_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G3_2.FormattingEnabled = true;
        this.CB_G3_2.Location = new System.Drawing.Point(672, 116);
        this.CB_G3_2.Name = "CB_G3_2";
        this.CB_G3_2.Size = new System.Drawing.Size(120, 21);
        this.CB_G3_2.TabIndex = 457;
        this.CB_G3_2.Visible = false;
        this.CB_G3_2.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G3_2
        // 
        this.PB_G3_2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.PB_G3_2.Location = new System.Drawing.Point(672, 20);
        this.PB_G3_2.Name = "PB_G3_2";
        this.PB_G3_2.Size = new System.Drawing.Size(120, 90);
        this.PB_G3_2.TabIndex = 456;
        this.PB_G3_2.TabStop = false;
        this.PB_G3_2.Visible = false;
        // 
        // CB_G3_1
        // 
        this.CB_G3_1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.CB_G3_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G3_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G3_1.FormattingEnabled = true;
        this.CB_G3_1.Location = new System.Drawing.Point(546, 116);
        this.CB_G3_1.Name = "CB_G3_1";
        this.CB_G3_1.Size = new System.Drawing.Size(120, 21);
        this.CB_G3_1.TabIndex = 455;
        this.CB_G3_1.Visible = false;
        this.CB_G3_1.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G3_1
        // 
        this.PB_G3_1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.PB_G3_1.Location = new System.Drawing.Point(546, 20);
        this.PB_G3_1.Name = "PB_G3_1";
        this.PB_G3_1.Size = new System.Drawing.Size(120, 90);
        this.PB_G3_1.TabIndex = 454;
        this.PB_G3_1.TabStop = false;
        this.PB_G3_1.Visible = false;
        // 
        // CB_G3_0
        // 
        this.CB_G3_0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.CB_G3_0.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G3_0.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G3_0.FormattingEnabled = true;
        this.CB_G3_0.Location = new System.Drawing.Point(420, 116);
        this.CB_G3_0.Name = "CB_G3_0";
        this.CB_G3_0.Size = new System.Drawing.Size(120, 21);
        this.CB_G3_0.TabIndex = 453;
        this.CB_G3_0.Visible = false;
        this.CB_G3_0.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G3_0
        // 
        this.PB_G3_0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.PB_G3_0.Location = new System.Drawing.Point(420, 20);
        this.PB_G3_0.Name = "PB_G3_0";
        this.PB_G3_0.Size = new System.Drawing.Size(120, 90);
        this.PB_G3_0.TabIndex = 452;
        this.PB_G3_0.TabStop = false;
        this.PB_G3_0.Visible = false;
        // 
        // CB_G4_2
        // 
        this.CB_G4_2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.CB_G4_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G4_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G4_2.FormattingEnabled = true;
        this.CB_G4_2.Location = new System.Drawing.Point(672, 254);
        this.CB_G4_2.Name = "CB_G4_2";
        this.CB_G4_2.Size = new System.Drawing.Size(120, 21);
        this.CB_G4_2.TabIndex = 463;
        this.CB_G4_2.Visible = false;
        this.CB_G4_2.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G4_2
        // 
        this.PB_G4_2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.PB_G4_2.Location = new System.Drawing.Point(672, 158);
        this.PB_G4_2.Name = "PB_G4_2";
        this.PB_G4_2.Size = new System.Drawing.Size(120, 90);
        this.PB_G4_2.TabIndex = 462;
        this.PB_G4_2.TabStop = false;
        this.PB_G4_2.Visible = false;
        // 
        // CB_G4_1
        // 
        this.CB_G4_1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.CB_G4_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G4_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G4_1.FormattingEnabled = true;
        this.CB_G4_1.Location = new System.Drawing.Point(546, 254);
        this.CB_G4_1.Name = "CB_G4_1";
        this.CB_G4_1.Size = new System.Drawing.Size(120, 21);
        this.CB_G4_1.TabIndex = 461;
        this.CB_G4_1.Visible = false;
        this.CB_G4_1.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G4_1
        // 
        this.PB_G4_1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.PB_G4_1.Location = new System.Drawing.Point(546, 158);
        this.PB_G4_1.Name = "PB_G4_1";
        this.PB_G4_1.Size = new System.Drawing.Size(120, 90);
        this.PB_G4_1.TabIndex = 460;
        this.PB_G4_1.TabStop = false;
        this.PB_G4_1.Visible = false;
        // 
        // CB_G4_0
        // 
        this.CB_G4_0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.CB_G4_0.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_G4_0.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_G4_0.FormattingEnabled = true;
        this.CB_G4_0.Location = new System.Drawing.Point(420, 254);
        this.CB_G4_0.Name = "CB_G4_0";
        this.CB_G4_0.Size = new System.Drawing.Size(120, 21);
        this.CB_G4_0.TabIndex = 459;
        this.CB_G4_0.Visible = false;
        this.CB_G4_0.SelectedIndexChanged += new System.EventHandler(this.ChangeSpecies);
        // 
        // PB_G4_0
        // 
        this.PB_G4_0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.PB_G4_0.Location = new System.Drawing.Point(420, 158);
        this.PB_G4_0.Name = "PB_G4_0";
        this.PB_G4_0.Size = new System.Drawing.Size(120, 90);
        this.PB_G4_0.TabIndex = 458;
        this.PB_G4_0.TabStop = false;
        this.PB_G4_0.Visible = false;
        // 
        // B_Save
        // 
        this.B_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.B_Save.Location = new System.Drawing.Point(722, 308);
        this.B_Save.Name = "B_Save";
        this.B_Save.Size = new System.Drawing.Size(75, 23);
        this.B_Save.TabIndex = 464;
        this.B_Save.Text = "Save";
        this.B_Save.UseVisualStyleBackColor = true;
        this.B_Save.Click += new System.EventHandler(this.B_Save_Click);
        // 
        // B_Randomize
        // 
        this.B_Randomize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
        this.B_Randomize.Location = new System.Drawing.Point(22, 299);
        this.B_Randomize.Name = "B_Randomize";
        this.B_Randomize.Size = new System.Drawing.Size(87, 35);
        this.B_Randomize.TabIndex = 466;
        this.B_Randomize.Text = "Randomize\nAll Starters";
        this.B_Randomize.UseVisualStyleBackColor = true;
        this.B_Randomize.Click += new System.EventHandler(this.B_Randomize_Click);
        // 
        // L_Set1
        // 
        this.L_Set1.AutoSize = true;
        this.L_Set1.ForeColor = System.Drawing.Color.Red;
        this.L_Set1.Location = new System.Drawing.Point(9, 4);
        this.L_Set1.Name = "L_Set1";
        this.L_Set1.Size = new System.Drawing.Size(32, 13);
        this.L_Set1.TabIndex = 467;
        this.L_Set1.Text = "Set 1";
        // 
        // L_Set3
        // 
        this.L_Set3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.L_Set3.AutoSize = true;
        this.L_Set3.ForeColor = System.Drawing.Color.Green;
        this.L_Set3.Location = new System.Drawing.Point(416, 4);
        this.L_Set3.Name = "L_Set3";
        this.L_Set3.Size = new System.Drawing.Size(32, 13);
        this.L_Set3.TabIndex = 468;
        this.L_Set3.Text = "Set 3";
        this.L_Set3.Visible = false;
        // 
        // L_Set4
        // 
        this.L_Set4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.L_Set4.AutoSize = true;
        this.L_Set4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
        this.L_Set4.Location = new System.Drawing.Point(416, 142);
        this.L_Set4.Name = "L_Set4";
        this.L_Set4.Size = new System.Drawing.Size(32, 13);
        this.L_Set4.TabIndex = 469;
        this.L_Set4.Text = "Set 4";
        this.L_Set4.Visible = false;
        // 
        // L_Set2
        // 
        this.L_Set2.AutoSize = true;
        this.L_Set2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
        this.L_Set2.Location = new System.Drawing.Point(9, 142);
        this.L_Set2.Name = "L_Set2";
        this.L_Set2.Size = new System.Drawing.Size(32, 13);
        this.L_Set2.TabIndex = 470;
        this.L_Set2.Text = "Set 2";
        // 
        // CHK_Gen
        // 
        this.CHK_Gen.AutoSize = true;
        this.CHK_Gen.Location = new System.Drawing.Point(16, 15);
        this.CHK_Gen.Name = "CHK_Gen";
        this.CHK_Gen.Size = new System.Drawing.Size(104, 17);
        this.CHK_Gen.TabIndex = 471;
        this.CHK_Gen.Text = "Keep Same Gen";
        this.CHK_Gen.UseVisualStyleBackColor = true;
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.CHK_E);
        this.groupBox1.Controls.Add(this.CHK_L);
        this.groupBox1.Controls.Add(this.CHK_BasicStarter);
        this.groupBox1.Controls.Add(this.CHK_Gen);
        this.groupBox1.Location = new System.Drawing.Point(124, 280);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(153, 77);
        this.groupBox1.TabIndex = 473;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Randomizer Settings";
        // 
        // CHK_E
        // 
        this.CHK_E.AutoSize = true;
        this.CHK_E.Location = new System.Drawing.Point(16, 57);
        this.CHK_E.Name = "CHK_E";
        this.CHK_E.Size = new System.Drawing.Size(98, 17);
        this.CHK_E.TabIndex = 476;
        this.CHK_E.Text = "Event Legends";
        this.CHK_E.UseVisualStyleBackColor = true;
        // 
        // CHK_L
        // 
        this.CHK_L.AutoSize = true;
        this.CHK_L.Location = new System.Drawing.Point(16, 43);
        this.CHK_L.Name = "CHK_L";
        this.CHK_L.Size = new System.Drawing.Size(98, 17);
        this.CHK_L.TabIndex = 475;
        this.CHK_L.Text = "Game Legends";
        this.CHK_L.UseVisualStyleBackColor = true;
        // 
        // CHK_BasicStarter
        // 
        this.CHK_BasicStarter.AutoSize = true;
        this.CHK_BasicStarter.Checked = true;
        this.CHK_BasicStarter.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_BasicStarter.Location = new System.Drawing.Point(16, 29);
        this.CHK_BasicStarter.Name = "CHK_BasicStarter";
        this.CHK_BasicStarter.Size = new System.Drawing.Size(134, 17);
        this.CHK_BasicStarter.TabIndex = 474;
        this.CHK_BasicStarter.Text = "Basic Starter Pokémon";
        this.CHK_BasicStarter.UseVisualStyleBackColor = true;
        // 
        // B_Cancel
        // 
        this.B_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        this.B_Cancel.Location = new System.Drawing.Point(722, 330);
        this.B_Cancel.Name = "B_Cancel";
        this.B_Cancel.Size = new System.Drawing.Size(75, 23);
        this.B_Cancel.TabIndex = 465;
        this.B_Cancel.Text = "Cancel";
        this.B_Cancel.UseVisualStyleBackColor = true;
        this.B_Cancel.Click += new System.EventHandler(this.B_Cancel_Click);
        // 
        // StarterEditor6
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(804, 352);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.L_Set2);
        this.Controls.Add(this.L_Set4);
        this.Controls.Add(this.L_Set3);
        this.Controls.Add(this.L_Set1);
        this.Controls.Add(this.B_Randomize);
        this.Controls.Add(this.B_Cancel);
        this.Controls.Add(this.B_Save);
        this.Controls.Add(this.CB_G4_2);
        this.Controls.Add(this.PB_G4_2);
        this.Controls.Add(this.CB_G4_1);
        this.Controls.Add(this.PB_G4_1);
        this.Controls.Add(this.CB_G4_0);
        this.Controls.Add(this.PB_G4_0);
        this.Controls.Add(this.CB_G3_2);
        this.Controls.Add(this.PB_G3_2);
        this.Controls.Add(this.CB_G3_1);
        this.Controls.Add(this.PB_G3_1);
        this.Controls.Add(this.CB_G3_0);
        this.Controls.Add(this.PB_G3_0);
        this.Controls.Add(this.CB_G2_2);
        this.Controls.Add(this.PB_G2_2);
        this.Controls.Add(this.CB_G2_1);
        this.Controls.Add(this.PB_G2_1);
        this.Controls.Add(this.CB_G2_0);
        this.Controls.Add(this.PB_G2_0);
        this.Controls.Add(this.CB_G1_2);
        this.Controls.Add(this.PB_G1_2);
        this.Controls.Add(this.CB_G1_1);
        this.Controls.Add(this.PB_G1_1);
        this.Controls.Add(this.CB_G1_0);
        this.Controls.Add(this.PB_G1_0);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.MinimumSize = new System.Drawing.Size(410, 390);
        this.Name = "StarterEditor6";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
        this.Text = "Starter Editor";
        ((System.ComponentModel.ISupportInitialize)(this.PB_G1_0)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G1_1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G1_2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G2_2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G2_1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G2_0)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G3_2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G3_1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G3_0)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G4_2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G4_1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_G4_0)).EndInit();
        this.groupBox1.ResumeLayout(false);
        this.groupBox1.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.PictureBox PB_G1_0;
    private System.Windows.Forms.ComboBox CB_G1_0;
    private System.Windows.Forms.ComboBox CB_G1_1;
    private System.Windows.Forms.PictureBox PB_G1_1;
    private System.Windows.Forms.ComboBox CB_G1_2;
    private System.Windows.Forms.PictureBox PB_G1_2;
    private System.Windows.Forms.ComboBox CB_G2_2;
    private System.Windows.Forms.PictureBox PB_G2_2;
    private System.Windows.Forms.ComboBox CB_G2_1;
    private System.Windows.Forms.PictureBox PB_G2_1;
    private System.Windows.Forms.ComboBox CB_G2_0;
    private System.Windows.Forms.PictureBox PB_G2_0;
    private System.Windows.Forms.ComboBox CB_G3_2;
    private System.Windows.Forms.PictureBox PB_G3_2;
    private System.Windows.Forms.ComboBox CB_G3_1;
    private System.Windows.Forms.PictureBox PB_G3_1;
    private System.Windows.Forms.ComboBox CB_G3_0;
    private System.Windows.Forms.PictureBox PB_G3_0;
    private System.Windows.Forms.ComboBox CB_G4_2;
    private System.Windows.Forms.PictureBox PB_G4_2;
    private System.Windows.Forms.ComboBox CB_G4_1;
    private System.Windows.Forms.PictureBox PB_G4_1;
    private System.Windows.Forms.ComboBox CB_G4_0;
    private System.Windows.Forms.PictureBox PB_G4_0;
    private System.Windows.Forms.Button B_Save;
    private System.Windows.Forms.Button B_Randomize;
    private System.Windows.Forms.Label L_Set1;
    private System.Windows.Forms.Label L_Set3;
    private System.Windows.Forms.Label L_Set4;
    private System.Windows.Forms.Label L_Set2;
    private System.Windows.Forms.CheckBox CHK_Gen;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.CheckBox CHK_BasicStarter;
    private System.Windows.Forms.CheckBox CHK_E;
    private System.Windows.Forms.CheckBox CHK_L;
    private System.Windows.Forms.Button B_Cancel;
}