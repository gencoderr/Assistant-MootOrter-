﻿namespace pk3DS.WinForms;

partial class MegaEvoEditor6
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.LBL_Item1 = new System.Windows.Forms.Label();
        this.LBL_Forme1 = new System.Windows.Forms.Label();
        this.GB_MEvo1 = new System.Windows.Forms.GroupBox();
        this.LBL_Into1 = new System.Windows.Forms.Label();
        this.PB_M1 = new System.Windows.Forms.PictureBox();
        this.PB_S1 = new System.Windows.Forms.PictureBox();
        this.CB_Forme1 = new System.Windows.Forms.ComboBox();
        this.CB_Item1 = new System.Windows.Forms.ComboBox();
        this.GB_MEvo2 = new System.Windows.Forms.GroupBox();
        this.LBL_Into2 = new System.Windows.Forms.Label();
        this.PB_M2 = new System.Windows.Forms.PictureBox();
        this.CB_Forme2 = new System.Windows.Forms.ComboBox();
        this.PB_S2 = new System.Windows.Forms.PictureBox();
        this.CB_Item2 = new System.Windows.Forms.ComboBox();
        this.LBL_Forme2 = new System.Windows.Forms.Label();
        this.LBL_Item2 = new System.Windows.Forms.Label();
        this.CHK_MEvo1 = new System.Windows.Forms.CheckBox();
        this.CHK_MEvo2 = new System.Windows.Forms.CheckBox();
        this.CB_Species = new System.Windows.Forms.ComboBox();
        this.GB_MEvo3 = new System.Windows.Forms.GroupBox();
        this.LBL_Into3 = new System.Windows.Forms.Label();
        this.PB_M3 = new System.Windows.Forms.PictureBox();
        this.CB_Forme3 = new System.Windows.Forms.ComboBox();
        this.PB_S3 = new System.Windows.Forms.PictureBox();
        this.CB_Item3 = new System.Windows.Forms.ComboBox();
        this.LBL_Forme3 = new System.Windows.Forms.Label();
        this.LBL_Item3 = new System.Windows.Forms.Label();
        this.CHK_MEvo3 = new System.Windows.Forms.CheckBox();
        this.bpkx = new System.Windows.Forms.PictureBox();
        this.B_Dump = new System.Windows.Forms.Button();
        this.GB_MEvo1.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.PB_M1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_S1)).BeginInit();
        this.GB_MEvo2.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.PB_M2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_S2)).BeginInit();
        this.GB_MEvo3.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.PB_M3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_S3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.bpkx)).BeginInit();
        this.SuspendLayout();
        // 
        // LBL_Item1
        // 
        this.LBL_Item1.AutoSize = true;
        this.LBL_Item1.Location = new System.Drawing.Point(6, 20);
        this.LBL_Item1.Name = "LBL_Item1";
        this.LBL_Item1.Size = new System.Drawing.Size(27, 13);
        this.LBL_Item1.TabIndex = 9;
        this.LBL_Item1.Text = "Item";
        // 
        // LBL_Forme1
        // 
        this.LBL_Forme1.AutoSize = true;
        this.LBL_Forme1.Location = new System.Drawing.Point(6, 65);
        this.LBL_Forme1.Name = "LBL_Forme1";
        this.LBL_Forme1.Size = new System.Drawing.Size(85, 13);
        this.LBL_Forme1.TabIndex = 10;
        this.LBL_Forme1.Text = "Alt Forme (if any)";
        // 
        // GB_MEvo1
        // 
        this.GB_MEvo1.Controls.Add(this.LBL_Into1);
        this.GB_MEvo1.Controls.Add(this.PB_M1);
        this.GB_MEvo1.Controls.Add(this.PB_S1);
        this.GB_MEvo1.Controls.Add(this.CB_Forme1);
        this.GB_MEvo1.Controls.Add(this.CB_Item1);
        this.GB_MEvo1.Controls.Add(this.LBL_Forme1);
        this.GB_MEvo1.Controls.Add(this.LBL_Item1);
        this.GB_MEvo1.Enabled = false;
        this.GB_MEvo1.Location = new System.Drawing.Point(12, 62);
        this.GB_MEvo1.Name = "GB_MEvo1";
        this.GB_MEvo1.Size = new System.Drawing.Size(126, 142);
        this.GB_MEvo1.TabIndex = 11;
        this.GB_MEvo1.TabStop = false;
        this.GB_MEvo1.Text = "Evolution 1";
        // 
        // LBL_Into1
        // 
        this.LBL_Into1.AutoSize = true;
        this.LBL_Into1.Location = new System.Drawing.Point(51, 117);
        this.LBL_Into1.Name = "LBL_Into1";
        this.LBL_Into1.Size = new System.Drawing.Size(28, 13);
        this.LBL_Into1.TabIndex = 34;
        this.LBL_Into1.Text = "Into:";
        // 
        // PB_M1
        // 
        this.PB_M1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_M1.Location = new System.Drawing.Point(81, 106);
        this.PB_M1.Name = "PB_M1";
        this.PB_M1.Size = new System.Drawing.Size(42, 32);
        this.PB_M1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
        this.PB_M1.TabIndex = 33;
        this.PB_M1.TabStop = false;
        // 
        // PB_S1
        // 
        this.PB_S1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_S1.Location = new System.Drawing.Point(5, 106);
        this.PB_S1.Name = "PB_S1";
        this.PB_S1.Size = new System.Drawing.Size(42, 32);
        this.PB_S1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
        this.PB_S1.TabIndex = 32;
        this.PB_S1.TabStop = false;
        // 
        // CB_Forme1
        // 
        this.CB_Forme1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Forme1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Forme1.FormattingEnabled = true;
        this.CB_Forme1.Location = new System.Drawing.Point(5, 82);
        this.CB_Forme1.Name = "CB_Forme1";
        this.CB_Forme1.Size = new System.Drawing.Size(121, 21);
        this.CB_Forme1.TabIndex = 18;
        this.CB_Forme1.SelectedIndexChanged += new System.EventHandler(this.Update_PBs);
        // 
        // CB_Item1
        // 
        this.CB_Item1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Item1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Item1.FormattingEnabled = true;
        this.CB_Item1.Location = new System.Drawing.Point(2, 35);
        this.CB_Item1.Name = "CB_Item1";
        this.CB_Item1.Size = new System.Drawing.Size(121, 21);
        this.CB_Item1.TabIndex = 12;
        this.CB_Item1.SelectedValueChanged += new System.EventHandler(this.Update_PBs);
        // 
        // GB_MEvo2
        // 
        this.GB_MEvo2.Controls.Add(this.LBL_Into2);
        this.GB_MEvo2.Controls.Add(this.PB_M2);
        this.GB_MEvo2.Controls.Add(this.CB_Forme2);
        this.GB_MEvo2.Controls.Add(this.PB_S2);
        this.GB_MEvo2.Controls.Add(this.CB_Item2);
        this.GB_MEvo2.Controls.Add(this.LBL_Forme2);
        this.GB_MEvo2.Controls.Add(this.LBL_Item2);
        this.GB_MEvo2.Enabled = false;
        this.GB_MEvo2.Location = new System.Drawing.Point(144, 62);
        this.GB_MEvo2.Name = "GB_MEvo2";
        this.GB_MEvo2.Size = new System.Drawing.Size(126, 142);
        this.GB_MEvo2.TabIndex = 12;
        this.GB_MEvo2.TabStop = false;
        this.GB_MEvo2.Text = "Evolution 2";
        // 
        // LBL_Into2
        // 
        this.LBL_Into2.AutoSize = true;
        this.LBL_Into2.Location = new System.Drawing.Point(52, 117);
        this.LBL_Into2.Name = "LBL_Into2";
        this.LBL_Into2.Size = new System.Drawing.Size(28, 13);
        this.LBL_Into2.TabIndex = 35;
        this.LBL_Into2.Text = "Into:";
        // 
        // PB_M2
        // 
        this.PB_M2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_M2.Location = new System.Drawing.Point(80, 106);
        this.PB_M2.Name = "PB_M2";
        this.PB_M2.Size = new System.Drawing.Size(42, 32);
        this.PB_M2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
        this.PB_M2.TabIndex = 35;
        this.PB_M2.TabStop = false;
        // 
        // CB_Forme2
        // 
        this.CB_Forme2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Forme2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Forme2.FormattingEnabled = true;
        this.CB_Forme2.Location = new System.Drawing.Point(2, 82);
        this.CB_Forme2.Name = "CB_Forme2";
        this.CB_Forme2.Size = new System.Drawing.Size(121, 21);
        this.CB_Forme2.TabIndex = 19;
        this.CB_Forme2.SelectedIndexChanged += new System.EventHandler(this.Update_PBs);
        // 
        // PB_S2
        // 
        this.PB_S2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_S2.Location = new System.Drawing.Point(4, 106);
        this.PB_S2.Name = "PB_S2";
        this.PB_S2.Size = new System.Drawing.Size(42, 32);
        this.PB_S2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
        this.PB_S2.TabIndex = 34;
        this.PB_S2.TabStop = false;
        // 
        // CB_Item2
        // 
        this.CB_Item2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Item2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Item2.FormattingEnabled = true;
        this.CB_Item2.Location = new System.Drawing.Point(2, 36);
        this.CB_Item2.Name = "CB_Item2";
        this.CB_Item2.Size = new System.Drawing.Size(121, 21);
        this.CB_Item2.TabIndex = 13;
        this.CB_Item2.SelectedValueChanged += new System.EventHandler(this.Update_PBs);
        // 
        // LBL_Forme2
        // 
        this.LBL_Forme2.AutoSize = true;
        this.LBL_Forme2.Location = new System.Drawing.Point(6, 65);
        this.LBL_Forme2.Name = "LBL_Forme2";
        this.LBL_Forme2.Size = new System.Drawing.Size(85, 13);
        this.LBL_Forme2.TabIndex = 10;
        this.LBL_Forme2.Text = "Alt Forme (if any)";
        // 
        // LBL_Item2
        // 
        this.LBL_Item2.AutoSize = true;
        this.LBL_Item2.Location = new System.Drawing.Point(6, 20);
        this.LBL_Item2.Name = "LBL_Item2";
        this.LBL_Item2.Size = new System.Drawing.Size(27, 13);
        this.LBL_Item2.TabIndex = 9;
        this.LBL_Item2.Text = "Item";
        // 
        // CHK_MEvo1
        // 
        this.CHK_MEvo1.AutoSize = true;
        this.CHK_MEvo1.Location = new System.Drawing.Point(12, 39);
        this.CHK_MEvo1.Name = "CHK_MEvo1";
        this.CHK_MEvo1.Size = new System.Drawing.Size(65, 17);
        this.CHK_MEvo1.TabIndex = 13;
        this.CHK_MEvo1.Text = "Enabled";
        this.CHK_MEvo1.UseVisualStyleBackColor = true;
        this.CHK_MEvo1.CheckedChanged += new System.EventHandler(this.CHK_Changed);
        // 
        // CHK_MEvo2
        // 
        this.CHK_MEvo2.AutoSize = true;
        this.CHK_MEvo2.Location = new System.Drawing.Point(144, 39);
        this.CHK_MEvo2.Name = "CHK_MEvo2";
        this.CHK_MEvo2.Size = new System.Drawing.Size(65, 17);
        this.CHK_MEvo2.TabIndex = 14;
        this.CHK_MEvo2.Text = "Enabled";
        this.CHK_MEvo2.UseVisualStyleBackColor = true;
        this.CHK_MEvo2.CheckedChanged += new System.EventHandler(this.CHK_Changed);
        // 
        // CB_Species
        // 
        this.CB_Species.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Species.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Species.FormattingEnabled = true;
        this.CB_Species.Location = new System.Drawing.Point(12, 12);
        this.CB_Species.Name = "CB_Species";
        this.CB_Species.Size = new System.Drawing.Size(181, 21);
        this.CB_Species.TabIndex = 15;
        this.CB_Species.SelectedIndexChanged += new System.EventHandler(this.ChangeIndex);
        // 
        // GB_MEvo3
        // 
        this.GB_MEvo3.Controls.Add(this.LBL_Into3);
        this.GB_MEvo3.Controls.Add(this.PB_M3);
        this.GB_MEvo3.Controls.Add(this.CB_Forme3);
        this.GB_MEvo3.Controls.Add(this.PB_S3);
        this.GB_MEvo3.Controls.Add(this.CB_Item3);
        this.GB_MEvo3.Controls.Add(this.LBL_Forme3);
        this.GB_MEvo3.Controls.Add(this.LBL_Item3);
        this.GB_MEvo3.Enabled = false;
        this.GB_MEvo3.Location = new System.Drawing.Point(276, 62);
        this.GB_MEvo3.Name = "GB_MEvo3";
        this.GB_MEvo3.Size = new System.Drawing.Size(126, 142);
        this.GB_MEvo3.TabIndex = 13;
        this.GB_MEvo3.TabStop = false;
        this.GB_MEvo3.Text = "Evolution 3";
        // 
        // LBL_Into3
        // 
        this.LBL_Into3.AutoSize = true;
        this.LBL_Into3.Location = new System.Drawing.Point(48, 117);
        this.LBL_Into3.Name = "LBL_Into3";
        this.LBL_Into3.Size = new System.Drawing.Size(28, 13);
        this.LBL_Into3.TabIndex = 36;
        this.LBL_Into3.Text = "Into:";
        // 
        // PB_M3
        // 
        this.PB_M3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_M3.Location = new System.Drawing.Point(79, 106);
        this.PB_M3.Name = "PB_M3";
        this.PB_M3.Size = new System.Drawing.Size(42, 32);
        this.PB_M3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
        this.PB_M3.TabIndex = 35;
        this.PB_M3.TabStop = false;
        // 
        // CB_Forme3
        // 
        this.CB_Forme3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Forme3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Forme3.FormattingEnabled = true;
        this.CB_Forme3.Location = new System.Drawing.Point(3, 82);
        this.CB_Forme3.Name = "CB_Forme3";
        this.CB_Forme3.Size = new System.Drawing.Size(121, 21);
        this.CB_Forme3.TabIndex = 20;
        this.CB_Forme3.SelectedIndexChanged += new System.EventHandler(this.Update_PBs);
        // 
        // PB_S3
        // 
        this.PB_S3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_S3.Location = new System.Drawing.Point(3, 106);
        this.PB_S3.Name = "PB_S3";
        this.PB_S3.Size = new System.Drawing.Size(42, 32);
        this.PB_S3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
        this.PB_S3.TabIndex = 34;
        this.PB_S3.TabStop = false;
        // 
        // CB_Item3
        // 
        this.CB_Item3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Item3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Item3.FormattingEnabled = true;
        this.CB_Item3.Location = new System.Drawing.Point(3, 36);
        this.CB_Item3.Name = "CB_Item3";
        this.CB_Item3.Size = new System.Drawing.Size(121, 21);
        this.CB_Item3.TabIndex = 18;
        this.CB_Item3.SelectedValueChanged += new System.EventHandler(this.Update_PBs);
        // 
        // LBL_Forme3
        // 
        this.LBL_Forme3.AutoSize = true;
        this.LBL_Forme3.Location = new System.Drawing.Point(6, 65);
        this.LBL_Forme3.Name = "LBL_Forme3";
        this.LBL_Forme3.Size = new System.Drawing.Size(85, 13);
        this.LBL_Forme3.TabIndex = 10;
        this.LBL_Forme3.Text = "Alt Forme (if any)";
        // 
        // LBL_Item3
        // 
        this.LBL_Item3.AutoSize = true;
        this.LBL_Item3.Location = new System.Drawing.Point(6, 20);
        this.LBL_Item3.Name = "LBL_Item3";
        this.LBL_Item3.Size = new System.Drawing.Size(27, 13);
        this.LBL_Item3.TabIndex = 9;
        this.LBL_Item3.Text = "Item";
        // 
        // CHK_MEvo3
        // 
        this.CHK_MEvo3.AutoSize = true;
        this.CHK_MEvo3.Location = new System.Drawing.Point(285, 39);
        this.CHK_MEvo3.Name = "CHK_MEvo3";
        this.CHK_MEvo3.Size = new System.Drawing.Size(65, 17);
        this.CHK_MEvo3.TabIndex = 16;
        this.CHK_MEvo3.Text = "Enabled";
        this.CHK_MEvo3.UseVisualStyleBackColor = true;
        this.CHK_MEvo3.CheckedChanged += new System.EventHandler(this.CHK_Changed);
        // 
        // bpkx
        // 
        this.bpkx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.bpkx.Location = new System.Drawing.Point(308, 99);
        this.bpkx.Name = "bpkx";
        this.bpkx.Size = new System.Drawing.Size(42, 32);
        this.bpkx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
        this.bpkx.TabIndex = 31;
        this.bpkx.TabStop = false;
        // 
        // B_Dump
        // 
        this.B_Dump.Location = new System.Drawing.Point(327, 5);
        this.B_Dump.Name = "B_Dump";
        this.B_Dump.Size = new System.Drawing.Size(75, 23);
        this.B_Dump.TabIndex = 18;
        this.B_Dump.Text = "Dump";
        this.B_Dump.UseVisualStyleBackColor = true;
        this.B_Dump.Click += new System.EventHandler(this.B_Dump_Click);
        // 
        // MEE
        // 
        this.AllowDrop = true;
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(414, 212);
        this.Controls.Add(this.B_Dump);
        this.Controls.Add(this.CHK_MEvo3);
        this.Controls.Add(this.GB_MEvo3);
        this.Controls.Add(this.CB_Species);
        this.Controls.Add(this.CHK_MEvo2);
        this.Controls.Add(this.CHK_MEvo1);
        this.Controls.Add(this.GB_MEvo2);
        this.Controls.Add(this.GB_MEvo1);
        this.MaximizeBox = false;
        this.MaximumSize = new System.Drawing.Size(430, 250);
        this.MinimumSize = new System.Drawing.Size(430, 250);
        this.Name = "MegaEvoEditor6";
        this.Text = "Mega Evo Editor";
        this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Closing);
        this.GB_MEvo1.ResumeLayout(false);
        this.GB_MEvo1.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.PB_M1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_S1)).EndInit();
        this.GB_MEvo2.ResumeLayout(false);
        this.GB_MEvo2.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.PB_M2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_S2)).EndInit();
        this.GB_MEvo3.ResumeLayout(false);
        this.GB_MEvo3.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.PB_M3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_S3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.bpkx)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label LBL_Item1;
    private System.Windows.Forms.Label LBL_Forme1;
    private System.Windows.Forms.GroupBox GB_MEvo1;
    private System.Windows.Forms.GroupBox GB_MEvo2;
    private System.Windows.Forms.Label LBL_Forme2;
    private System.Windows.Forms.Label LBL_Item2;
    private System.Windows.Forms.CheckBox CHK_MEvo1;
    private System.Windows.Forms.CheckBox CHK_MEvo2;
    private System.Windows.Forms.ComboBox CB_Species;
    private System.Windows.Forms.GroupBox GB_MEvo3;
    private System.Windows.Forms.Label LBL_Forme3;
    private System.Windows.Forms.Label LBL_Item3;
    private System.Windows.Forms.CheckBox CHK_MEvo3;
    private System.Windows.Forms.ComboBox CB_Item1;
    private System.Windows.Forms.ComboBox CB_Item2;
    private System.Windows.Forms.ComboBox CB_Item3;
    private System.Windows.Forms.ComboBox CB_Forme1;
    private System.Windows.Forms.ComboBox CB_Forme2;
    private System.Windows.Forms.ComboBox CB_Forme3;
    private System.Windows.Forms.PictureBox PB_M1;
    private System.Windows.Forms.PictureBox PB_S1;
    private System.Windows.Forms.PictureBox PB_M2;
    private System.Windows.Forms.PictureBox PB_S2;
    private System.Windows.Forms.PictureBox PB_M3;
    private System.Windows.Forms.PictureBox PB_S3;
    private System.Windows.Forms.PictureBox bpkx;
    private System.Windows.Forms.Label LBL_Into1;
    private System.Windows.Forms.Label LBL_Into2;
    private System.Windows.Forms.Label LBL_Into3;
    private System.Windows.Forms.Button B_Dump;
}