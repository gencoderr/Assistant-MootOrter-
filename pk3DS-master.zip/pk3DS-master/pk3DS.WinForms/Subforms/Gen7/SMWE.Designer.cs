﻿namespace pk3DS.WinForms;

partial class SMWE
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.B_Randomize = new System.Windows.Forms.Button();
        this.B_Dump = new System.Windows.Forms.Button();
        this.L_Location = new System.Windows.Forms.Label();
        this.B_Save = new System.Windows.Forms.Button();
        this.CB_LocationID = new System.Windows.Forms.ComboBox();
        this.NUP_Min = new System.Windows.Forms.NumericUpDown();
        this.NUP_Max = new System.Windows.Forms.NumericUpDown();
        this.L_Min = new System.Windows.Forms.Label();
        this.L_Max = new System.Windows.Forms.Label();
        this.L_Table = new System.Windows.Forms.Label();
        this.GB_Encounters = new System.Windows.Forms.GroupBox();
        this.L_Sand = new System.Windows.Forms.Label();
        this.L_Hail = new System.Windows.Forms.Label();
        this.L_Rain = new System.Windows.Forms.Label();
        this.L_Weather1 = new System.Windows.Forms.Label();
        this.L_Weather0 = new System.Windows.Forms.Label();
        this.B_PasteAll = new System.Windows.Forms.Button();
        this.B_Paste = new System.Windows.Forms.Button();
        this.B_Copy = new System.Windows.Forms.Button();
        this.GB_Tweak = new System.Windows.Forms.GroupBox();
        this.CB_SlotRand = new System.Windows.Forms.ComboBox();
        this.L_SOS = new System.Windows.Forms.Label();
        this.CHK_G7 = new System.Windows.Forms.CheckBox();
        this.CHK_MegaForm = new System.Windows.Forms.CheckBox();
        this.L_RandOpt = new System.Windows.Forms.Label();
        this.CHK_BST = new System.Windows.Forms.CheckBox();
        this.CHK_E = new System.Windows.Forms.CheckBox();
        this.CHK_L = new System.Windows.Forms.CheckBox();
        this.CHK_G6 = new System.Windows.Forms.CheckBox();
        this.CHK_G5 = new System.Windows.Forms.CheckBox();
        this.CHK_G4 = new System.Windows.Forms.CheckBox();
        this.CHK_G3 = new System.Windows.Forms.CheckBox();
        this.CHK_G2 = new System.Windows.Forms.CheckBox();
        this.CHK_G1 = new System.Windows.Forms.CheckBox();
        this.B_LevelPlus = new System.Windows.Forms.Button();
        this.NUD_LevelAmp = new System.Windows.Forms.NumericUpDown();
        this.CHK_Level = new System.Windows.Forms.CheckBox();
        this.PB_NightIcon = new System.Windows.Forms.PictureBox();
        this.PB_DayIcon = new System.Windows.Forms.PictureBox();
        this.NUP_WeatherForme6 = new System.Windows.Forms.NumericUpDown();
        this.NUP_WeatherForme3 = new System.Windows.Forms.NumericUpDown();
        this.CB_WeatherEnc6 = new System.Windows.Forms.ComboBox();
        this.NUP_WeatherForme5 = new System.Windows.Forms.NumericUpDown();
        this.CB_WeatherEnc5 = new System.Windows.Forms.ComboBox();
        this.NUP_WeatherForme4 = new System.Windows.Forms.NumericUpDown();
        this.CB_WeatherEnc4 = new System.Windows.Forms.ComboBox();
        this.CB_WeatherEnc3 = new System.Windows.Forms.ComboBox();
        this.NUP_WeatherForme2 = new System.Windows.Forms.NumericUpDown();
        this.CB_WeatherEnc2 = new System.Windows.Forms.ComboBox();
        this.NUP_WeatherForme1 = new System.Windows.Forms.NumericUpDown();
        this.CB_WeatherEnc1 = new System.Windows.Forms.ComboBox();
        this.L_AddSOS = new System.Windows.Forms.Label();
        this.PB_NightTable = new System.Windows.Forms.PictureBox();
        this.PB_DayTable = new System.Windows.Forms.PictureBox();
        this.NUP_Forme80 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc80 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme79 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc79 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme78 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc78 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme77 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc77 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme76 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc76 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme75 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc75 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme74 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc74 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme73 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc73 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme72 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc72 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme71 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc71 = new System.Windows.Forms.ComboBox();
        this.L_SOS7 = new System.Windows.Forms.Label();
        this.NUP_Forme70 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc70 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme69 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc69 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme68 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc68 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme67 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc67 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme66 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc66 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme65 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc65 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme64 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc64 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme63 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc63 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme62 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc62 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme61 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc61 = new System.Windows.Forms.ComboBox();
        this.L_SOS6 = new System.Windows.Forms.Label();
        this.NUP_Forme60 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc60 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme59 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc59 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme58 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc58 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme57 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc57 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme56 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc56 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme55 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc55 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme54 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc54 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme53 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc53 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme52 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc52 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme51 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc51 = new System.Windows.Forms.ComboBox();
        this.L_SOS5 = new System.Windows.Forms.Label();
        this.NUP_Forme50 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc50 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme49 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc49 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme48 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc48 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme47 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc47 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme46 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc46 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme45 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc45 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme44 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc44 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme43 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc43 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme42 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc42 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme41 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc41 = new System.Windows.Forms.ComboBox();
        this.L_SOS4 = new System.Windows.Forms.Label();
        this.NUP_Forme40 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc40 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme39 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc39 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme38 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc38 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme37 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc37 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme36 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc36 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme35 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc35 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme34 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc34 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme33 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc33 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme32 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc32 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme31 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc31 = new System.Windows.Forms.ComboBox();
        this.L_SOS3 = new System.Windows.Forms.Label();
        this.NUP_Forme30 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc30 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme29 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc29 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme28 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc28 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme27 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc27 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme26 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc26 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme25 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc25 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme24 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc24 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme23 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc23 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme22 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc22 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme21 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc21 = new System.Windows.Forms.ComboBox();
        this.L_SOS2 = new System.Windows.Forms.Label();
        this.NUP_Forme20 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc20 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme19 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc19 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme18 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc18 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme17 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc17 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme16 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc16 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme15 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc15 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme14 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc14 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme13 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc13 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme12 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc12 = new System.Windows.Forms.ComboBox();
        this.NUP_Forme11 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc11 = new System.Windows.Forms.ComboBox();
        this.L_SOS1 = new System.Windows.Forms.Label();
        this.label1 = new System.Windows.Forms.Label();
        this.NUP_Forme10 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc10 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate10 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme09 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc09 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate9 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme08 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc08 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate8 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme07 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc07 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate7 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme06 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc06 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate6 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme05 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc05 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate5 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme04 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc04 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate4 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme03 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc03 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate3 = new System.Windows.Forms.NumericUpDown();
        this.NUP_Forme02 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc02 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate2 = new System.Windows.Forms.NumericUpDown();
        this.L_Rate = new System.Windows.Forms.Label();
        this.NUP_Forme01 = new System.Windows.Forms.NumericUpDown();
        this.CB_Enc01 = new System.Windows.Forms.ComboBox();
        this.NUP_Rate1 = new System.Windows.Forms.NumericUpDown();
        this.CB_TableID = new System.Windows.Forms.ComboBox();
        this.B_Export = new System.Windows.Forms.Button();
        this.CopySOS = new System.Windows.Forms.Button();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Min)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Max)).BeginInit();
        this.GB_Encounters.SuspendLayout();
        this.GB_Tweak.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_LevelAmp)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_NightIcon)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_DayIcon)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_NightTable)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_DayTable)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme80)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme79)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme78)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme77)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme76)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme75)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme74)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme73)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme72)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme71)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme70)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme69)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme68)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme67)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme66)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme65)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme64)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme63)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme62)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme61)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme60)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme59)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme58)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme57)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme56)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme55)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme54)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme53)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme52)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme51)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme50)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme49)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme48)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme47)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme46)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme45)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme44)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme43)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme42)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme41)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme40)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme39)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme38)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme37)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme36)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme35)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme34)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme33)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme32)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme31)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme30)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme29)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme28)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme27)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme26)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme25)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme24)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme23)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme22)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme21)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme20)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme19)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme18)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme17)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme16)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme15)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme14)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme13)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme12)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme11)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate10)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme09)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate9)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme08)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme07)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme06)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme05)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme04)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme03)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme02)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme01)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate1)).BeginInit();
        this.SuspendLayout();
        // 
        // B_Randomize
        // 
        this.B_Randomize.Location = new System.Drawing.Point(812, 11);
        this.B_Randomize.Name = "B_Randomize";
        this.B_Randomize.Size = new System.Drawing.Size(102, 23);
        this.B_Randomize.TabIndex = 421;
        this.B_Randomize.Text = "Randomize All";
        this.B_Randomize.UseVisualStyleBackColor = true;
        this.B_Randomize.Click += new System.EventHandler(this.B_Randomize_Click);
        // 
        // B_Dump
        // 
        this.B_Dump.Location = new System.Drawing.Point(920, 11);
        this.B_Dump.Name = "B_Dump";
        this.B_Dump.Size = new System.Drawing.Size(108, 23);
        this.B_Dump.TabIndex = 420;
        this.B_Dump.Text = "Dump Tables";
        this.B_Dump.UseVisualStyleBackColor = true;
        this.B_Dump.Click += new System.EventHandler(this.DumpTables);
        // 
        // L_Location
        // 
        this.L_Location.AutoSize = true;
        this.L_Location.Location = new System.Drawing.Point(38, 16);
        this.L_Location.Name = "L_Location";
        this.L_Location.Size = new System.Drawing.Size(28, 13);
        this.L_Location.TabIndex = 419;
        this.L_Location.Text = "Loc:";
        // 
        // B_Save
        // 
        this.B_Save.Location = new System.Drawing.Point(558, 11);
        this.B_Save.Name = "B_Save";
        this.B_Save.Size = new System.Drawing.Size(135, 23);
        this.B_Save.TabIndex = 418;
        this.B_Save.Text = "Save Current Table";
        this.B_Save.UseVisualStyleBackColor = true;
        this.B_Save.Click += new System.EventHandler(this.B_Save_Click);
        // 
        // CB_LocationID
        // 
        this.CB_LocationID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
        this.CB_LocationID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_LocationID.DropDownWidth = 350;
        this.CB_LocationID.FormattingEnabled = true;
        this.CB_LocationID.Location = new System.Drawing.Point(67, 12);
        this.CB_LocationID.Name = "CB_LocationID";
        this.CB_LocationID.Size = new System.Drawing.Size(164, 21);
        this.CB_LocationID.TabIndex = 417;
        this.CB_LocationID.SelectedIndexChanged += new System.EventHandler(this.ChangeMap);
        // 
        // NUP_Min
        // 
        this.NUP_Min.Location = new System.Drawing.Point(434, 14);
        this.NUP_Min.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
        this.NUP_Min.Name = "NUP_Min";
        this.NUP_Min.Size = new System.Drawing.Size(41, 20);
        this.NUP_Min.TabIndex = 423;
        this.NUP_Min.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
        this.NUP_Min.ValueChanged += new System.EventHandler(this.UpdateMinMax);
        // 
        // NUP_Max
        // 
        this.NUP_Max.Location = new System.Drawing.Point(505, 14);
        this.NUP_Max.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
        this.NUP_Max.Name = "NUP_Max";
        this.NUP_Max.Size = new System.Drawing.Size(41, 20);
        this.NUP_Max.TabIndex = 424;
        this.NUP_Max.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
        this.NUP_Max.ValueChanged += new System.EventHandler(this.UpdateMinMax);
        // 
        // L_Min
        // 
        this.L_Min.AutoSize = true;
        this.L_Min.Location = new System.Drawing.Point(406, 16);
        this.L_Min.Name = "L_Min";
        this.L_Min.Size = new System.Drawing.Size(24, 13);
        this.L_Min.TabIndex = 425;
        this.L_Min.Text = "Min";
        // 
        // L_Max
        // 
        this.L_Max.AutoSize = true;
        this.L_Max.Location = new System.Drawing.Point(478, 16);
        this.L_Max.Name = "L_Max";
        this.L_Max.Size = new System.Drawing.Size(27, 13);
        this.L_Max.TabIndex = 426;
        this.L_Max.Text = "Max";
        // 
        // L_Table
        // 
        this.L_Table.AutoSize = true;
        this.L_Table.Location = new System.Drawing.Point(236, 16);
        this.L_Table.Name = "L_Table";
        this.L_Table.Size = new System.Drawing.Size(34, 13);
        this.L_Table.TabIndex = 428;
        this.L_Table.Text = "Table";
        // 
        // GB_Encounters
        // 
        this.GB_Encounters.Controls.Add(this.L_Sand);
        this.GB_Encounters.Controls.Add(this.L_Hail);
        this.GB_Encounters.Controls.Add(this.L_Rain);
        this.GB_Encounters.Controls.Add(this.L_Weather1);
        this.GB_Encounters.Controls.Add(this.L_Weather0);
        this.GB_Encounters.Controls.Add(this.B_PasteAll);
        this.GB_Encounters.Controls.Add(this.B_Paste);
        this.GB_Encounters.Controls.Add(this.B_Copy);
        this.GB_Encounters.Controls.Add(this.GB_Tweak);
        this.GB_Encounters.Controls.Add(this.PB_NightIcon);
        this.GB_Encounters.Controls.Add(this.PB_DayIcon);
        this.GB_Encounters.Controls.Add(this.NUP_WeatherForme6);
        this.GB_Encounters.Controls.Add(this.NUP_WeatherForme3);
        this.GB_Encounters.Controls.Add(this.CB_WeatherEnc6);
        this.GB_Encounters.Controls.Add(this.NUP_WeatherForme5);
        this.GB_Encounters.Controls.Add(this.CB_WeatherEnc5);
        this.GB_Encounters.Controls.Add(this.NUP_WeatherForme4);
        this.GB_Encounters.Controls.Add(this.CB_WeatherEnc4);
        this.GB_Encounters.Controls.Add(this.CB_WeatherEnc3);
        this.GB_Encounters.Controls.Add(this.NUP_WeatherForme2);
        this.GB_Encounters.Controls.Add(this.CB_WeatherEnc2);
        this.GB_Encounters.Controls.Add(this.NUP_WeatherForme1);
        this.GB_Encounters.Controls.Add(this.CB_WeatherEnc1);
        this.GB_Encounters.Controls.Add(this.L_AddSOS);
        this.GB_Encounters.Controls.Add(this.PB_NightTable);
        this.GB_Encounters.Controls.Add(this.PB_DayTable);
        this.GB_Encounters.Controls.Add(this.NUP_Forme80);
        this.GB_Encounters.Controls.Add(this.CB_Enc80);
        this.GB_Encounters.Controls.Add(this.NUP_Forme79);
        this.GB_Encounters.Controls.Add(this.CB_Enc79);
        this.GB_Encounters.Controls.Add(this.NUP_Forme78);
        this.GB_Encounters.Controls.Add(this.CB_Enc78);
        this.GB_Encounters.Controls.Add(this.NUP_Forme77);
        this.GB_Encounters.Controls.Add(this.CB_Enc77);
        this.GB_Encounters.Controls.Add(this.NUP_Forme76);
        this.GB_Encounters.Controls.Add(this.CB_Enc76);
        this.GB_Encounters.Controls.Add(this.NUP_Forme75);
        this.GB_Encounters.Controls.Add(this.CB_Enc75);
        this.GB_Encounters.Controls.Add(this.NUP_Forme74);
        this.GB_Encounters.Controls.Add(this.CB_Enc74);
        this.GB_Encounters.Controls.Add(this.NUP_Forme73);
        this.GB_Encounters.Controls.Add(this.CB_Enc73);
        this.GB_Encounters.Controls.Add(this.NUP_Forme72);
        this.GB_Encounters.Controls.Add(this.CB_Enc72);
        this.GB_Encounters.Controls.Add(this.NUP_Forme71);
        this.GB_Encounters.Controls.Add(this.CB_Enc71);
        this.GB_Encounters.Controls.Add(this.L_SOS7);
        this.GB_Encounters.Controls.Add(this.NUP_Forme70);
        this.GB_Encounters.Controls.Add(this.CB_Enc70);
        this.GB_Encounters.Controls.Add(this.NUP_Forme69);
        this.GB_Encounters.Controls.Add(this.CB_Enc69);
        this.GB_Encounters.Controls.Add(this.NUP_Forme68);
        this.GB_Encounters.Controls.Add(this.CB_Enc68);
        this.GB_Encounters.Controls.Add(this.NUP_Forme67);
        this.GB_Encounters.Controls.Add(this.CB_Enc67);
        this.GB_Encounters.Controls.Add(this.NUP_Forme66);
        this.GB_Encounters.Controls.Add(this.CB_Enc66);
        this.GB_Encounters.Controls.Add(this.NUP_Forme65);
        this.GB_Encounters.Controls.Add(this.CB_Enc65);
        this.GB_Encounters.Controls.Add(this.NUP_Forme64);
        this.GB_Encounters.Controls.Add(this.CB_Enc64);
        this.GB_Encounters.Controls.Add(this.NUP_Forme63);
        this.GB_Encounters.Controls.Add(this.CB_Enc63);
        this.GB_Encounters.Controls.Add(this.NUP_Forme62);
        this.GB_Encounters.Controls.Add(this.CB_Enc62);
        this.GB_Encounters.Controls.Add(this.NUP_Forme61);
        this.GB_Encounters.Controls.Add(this.CB_Enc61);
        this.GB_Encounters.Controls.Add(this.L_SOS6);
        this.GB_Encounters.Controls.Add(this.NUP_Forme60);
        this.GB_Encounters.Controls.Add(this.CB_Enc60);
        this.GB_Encounters.Controls.Add(this.NUP_Forme59);
        this.GB_Encounters.Controls.Add(this.CB_Enc59);
        this.GB_Encounters.Controls.Add(this.NUP_Forme58);
        this.GB_Encounters.Controls.Add(this.CB_Enc58);
        this.GB_Encounters.Controls.Add(this.NUP_Forme57);
        this.GB_Encounters.Controls.Add(this.CB_Enc57);
        this.GB_Encounters.Controls.Add(this.NUP_Forme56);
        this.GB_Encounters.Controls.Add(this.CB_Enc56);
        this.GB_Encounters.Controls.Add(this.NUP_Forme55);
        this.GB_Encounters.Controls.Add(this.CB_Enc55);
        this.GB_Encounters.Controls.Add(this.NUP_Forme54);
        this.GB_Encounters.Controls.Add(this.CB_Enc54);
        this.GB_Encounters.Controls.Add(this.NUP_Forme53);
        this.GB_Encounters.Controls.Add(this.CB_Enc53);
        this.GB_Encounters.Controls.Add(this.NUP_Forme52);
        this.GB_Encounters.Controls.Add(this.CB_Enc52);
        this.GB_Encounters.Controls.Add(this.NUP_Forme51);
        this.GB_Encounters.Controls.Add(this.CB_Enc51);
        this.GB_Encounters.Controls.Add(this.L_SOS5);
        this.GB_Encounters.Controls.Add(this.NUP_Forme50);
        this.GB_Encounters.Controls.Add(this.CB_Enc50);
        this.GB_Encounters.Controls.Add(this.NUP_Forme49);
        this.GB_Encounters.Controls.Add(this.CB_Enc49);
        this.GB_Encounters.Controls.Add(this.NUP_Forme48);
        this.GB_Encounters.Controls.Add(this.CB_Enc48);
        this.GB_Encounters.Controls.Add(this.NUP_Forme47);
        this.GB_Encounters.Controls.Add(this.CB_Enc47);
        this.GB_Encounters.Controls.Add(this.NUP_Forme46);
        this.GB_Encounters.Controls.Add(this.CB_Enc46);
        this.GB_Encounters.Controls.Add(this.NUP_Forme45);
        this.GB_Encounters.Controls.Add(this.CB_Enc45);
        this.GB_Encounters.Controls.Add(this.NUP_Forme44);
        this.GB_Encounters.Controls.Add(this.CB_Enc44);
        this.GB_Encounters.Controls.Add(this.NUP_Forme43);
        this.GB_Encounters.Controls.Add(this.CB_Enc43);
        this.GB_Encounters.Controls.Add(this.NUP_Forme42);
        this.GB_Encounters.Controls.Add(this.CB_Enc42);
        this.GB_Encounters.Controls.Add(this.NUP_Forme41);
        this.GB_Encounters.Controls.Add(this.CB_Enc41);
        this.GB_Encounters.Controls.Add(this.L_SOS4);
        this.GB_Encounters.Controls.Add(this.NUP_Forme40);
        this.GB_Encounters.Controls.Add(this.CB_Enc40);
        this.GB_Encounters.Controls.Add(this.NUP_Forme39);
        this.GB_Encounters.Controls.Add(this.CB_Enc39);
        this.GB_Encounters.Controls.Add(this.NUP_Forme38);
        this.GB_Encounters.Controls.Add(this.CB_Enc38);
        this.GB_Encounters.Controls.Add(this.NUP_Forme37);
        this.GB_Encounters.Controls.Add(this.CB_Enc37);
        this.GB_Encounters.Controls.Add(this.NUP_Forme36);
        this.GB_Encounters.Controls.Add(this.CB_Enc36);
        this.GB_Encounters.Controls.Add(this.NUP_Forme35);
        this.GB_Encounters.Controls.Add(this.CB_Enc35);
        this.GB_Encounters.Controls.Add(this.NUP_Forme34);
        this.GB_Encounters.Controls.Add(this.CB_Enc34);
        this.GB_Encounters.Controls.Add(this.NUP_Forme33);
        this.GB_Encounters.Controls.Add(this.CB_Enc33);
        this.GB_Encounters.Controls.Add(this.NUP_Forme32);
        this.GB_Encounters.Controls.Add(this.CB_Enc32);
        this.GB_Encounters.Controls.Add(this.NUP_Forme31);
        this.GB_Encounters.Controls.Add(this.CB_Enc31);
        this.GB_Encounters.Controls.Add(this.L_SOS3);
        this.GB_Encounters.Controls.Add(this.NUP_Forme30);
        this.GB_Encounters.Controls.Add(this.CB_Enc30);
        this.GB_Encounters.Controls.Add(this.NUP_Forme29);
        this.GB_Encounters.Controls.Add(this.CB_Enc29);
        this.GB_Encounters.Controls.Add(this.NUP_Forme28);
        this.GB_Encounters.Controls.Add(this.CB_Enc28);
        this.GB_Encounters.Controls.Add(this.NUP_Forme27);
        this.GB_Encounters.Controls.Add(this.CB_Enc27);
        this.GB_Encounters.Controls.Add(this.NUP_Forme26);
        this.GB_Encounters.Controls.Add(this.CB_Enc26);
        this.GB_Encounters.Controls.Add(this.NUP_Forme25);
        this.GB_Encounters.Controls.Add(this.CB_Enc25);
        this.GB_Encounters.Controls.Add(this.NUP_Forme24);
        this.GB_Encounters.Controls.Add(this.CB_Enc24);
        this.GB_Encounters.Controls.Add(this.NUP_Forme23);
        this.GB_Encounters.Controls.Add(this.CB_Enc23);
        this.GB_Encounters.Controls.Add(this.NUP_Forme22);
        this.GB_Encounters.Controls.Add(this.CB_Enc22);
        this.GB_Encounters.Controls.Add(this.NUP_Forme21);
        this.GB_Encounters.Controls.Add(this.CB_Enc21);
        this.GB_Encounters.Controls.Add(this.L_SOS2);
        this.GB_Encounters.Controls.Add(this.NUP_Forme20);
        this.GB_Encounters.Controls.Add(this.CB_Enc20);
        this.GB_Encounters.Controls.Add(this.NUP_Forme19);
        this.GB_Encounters.Controls.Add(this.CB_Enc19);
        this.GB_Encounters.Controls.Add(this.NUP_Forme18);
        this.GB_Encounters.Controls.Add(this.CB_Enc18);
        this.GB_Encounters.Controls.Add(this.NUP_Forme17);
        this.GB_Encounters.Controls.Add(this.CB_Enc17);
        this.GB_Encounters.Controls.Add(this.NUP_Forme16);
        this.GB_Encounters.Controls.Add(this.CB_Enc16);
        this.GB_Encounters.Controls.Add(this.NUP_Forme15);
        this.GB_Encounters.Controls.Add(this.CB_Enc15);
        this.GB_Encounters.Controls.Add(this.NUP_Forme14);
        this.GB_Encounters.Controls.Add(this.CB_Enc14);
        this.GB_Encounters.Controls.Add(this.NUP_Forme13);
        this.GB_Encounters.Controls.Add(this.CB_Enc13);
        this.GB_Encounters.Controls.Add(this.NUP_Forme12);
        this.GB_Encounters.Controls.Add(this.CB_Enc12);
        this.GB_Encounters.Controls.Add(this.NUP_Forme11);
        this.GB_Encounters.Controls.Add(this.CB_Enc11);
        this.GB_Encounters.Controls.Add(this.L_SOS1);
        this.GB_Encounters.Controls.Add(this.label1);
        this.GB_Encounters.Controls.Add(this.NUP_Forme10);
        this.GB_Encounters.Controls.Add(this.CB_Enc10);
        this.GB_Encounters.Controls.Add(this.NUP_Rate10);
        this.GB_Encounters.Controls.Add(this.NUP_Forme09);
        this.GB_Encounters.Controls.Add(this.CB_Enc09);
        this.GB_Encounters.Controls.Add(this.NUP_Rate9);
        this.GB_Encounters.Controls.Add(this.NUP_Forme08);
        this.GB_Encounters.Controls.Add(this.CB_Enc08);
        this.GB_Encounters.Controls.Add(this.NUP_Rate8);
        this.GB_Encounters.Controls.Add(this.NUP_Forme07);
        this.GB_Encounters.Controls.Add(this.CB_Enc07);
        this.GB_Encounters.Controls.Add(this.NUP_Rate7);
        this.GB_Encounters.Controls.Add(this.NUP_Forme06);
        this.GB_Encounters.Controls.Add(this.CB_Enc06);
        this.GB_Encounters.Controls.Add(this.NUP_Rate6);
        this.GB_Encounters.Controls.Add(this.NUP_Forme05);
        this.GB_Encounters.Controls.Add(this.CB_Enc05);
        this.GB_Encounters.Controls.Add(this.NUP_Rate5);
        this.GB_Encounters.Controls.Add(this.NUP_Forme04);
        this.GB_Encounters.Controls.Add(this.CB_Enc04);
        this.GB_Encounters.Controls.Add(this.NUP_Rate4);
        this.GB_Encounters.Controls.Add(this.NUP_Forme03);
        this.GB_Encounters.Controls.Add(this.CB_Enc03);
        this.GB_Encounters.Controls.Add(this.NUP_Rate3);
        this.GB_Encounters.Controls.Add(this.NUP_Forme02);
        this.GB_Encounters.Controls.Add(this.CB_Enc02);
        this.GB_Encounters.Controls.Add(this.NUP_Rate2);
        this.GB_Encounters.Controls.Add(this.L_Rate);
        this.GB_Encounters.Controls.Add(this.NUP_Forme01);
        this.GB_Encounters.Controls.Add(this.CB_Enc01);
        this.GB_Encounters.Controls.Add(this.NUP_Rate1);
        this.GB_Encounters.Location = new System.Drawing.Point(14, 39);
        this.GB_Encounters.Name = "GB_Encounters";
        this.GB_Encounters.Size = new System.Drawing.Size(1138, 561);
        this.GB_Encounters.TabIndex = 430;
        this.GB_Encounters.TabStop = false;
        this.GB_Encounters.Text = "Encounters (100%)";
        // 
        // L_Sand
        // 
        this.L_Sand.AutoSize = true;
        this.L_Sand.Location = new System.Drawing.Point(254, 335);
        this.L_Sand.Name = "L_Sand";
        this.L_Sand.Size = new System.Drawing.Size(32, 13);
        this.L_Sand.TabIndex = 515;
        this.L_Sand.Text = "Sand";
        // 
        // L_Hail
        // 
        this.L_Hail.AutoSize = true;
        this.L_Hail.Location = new System.Drawing.Point(254, 309);
        this.L_Hail.Name = "L_Hail";
        this.L_Hail.Size = new System.Drawing.Size(25, 13);
        this.L_Hail.TabIndex = 514;
        this.L_Hail.Text = "Hail";
        // 
        // L_Rain
        // 
        this.L_Rain.AutoSize = true;
        this.L_Rain.Location = new System.Drawing.Point(254, 282);
        this.L_Rain.Name = "L_Rain";
        this.L_Rain.Size = new System.Drawing.Size(29, 13);
        this.L_Rain.TabIndex = 513;
        this.L_Rain.Text = "Rain";
        // 
        // L_Weather1
        // 
        this.L_Weather1.AutoSize = true;
        this.L_Weather1.Location = new System.Drawing.Point(222, 264);
        this.L_Weather1.Name = "L_Weather1";
        this.L_Weather1.Size = new System.Drawing.Size(27, 13);
        this.L_Weather1.TabIndex = 512;
        this.L_Weather1.Text = "10%";
        // 
        // L_Weather0
        // 
        this.L_Weather0.AutoSize = true;
        this.L_Weather0.Location = new System.Drawing.Point(114, 264);
        this.L_Weather0.Name = "L_Weather0";
        this.L_Weather0.Size = new System.Drawing.Size(21, 13);
        this.L_Weather0.TabIndex = 511;
        this.L_Weather0.Text = "1%";
        // 
        // B_PasteAll
        // 
        this.B_PasteAll.Enabled = false;
        this.B_PasteAll.Location = new System.Drawing.Point(206, 359);
        this.B_PasteAll.Name = "B_PasteAll";
        this.B_PasteAll.Size = new System.Drawing.Size(90, 40);
        this.B_PasteAll.TabIndex = 510;
        this.B_PasteAll.Text = "Paste To All (Location)";
        this.B_PasteAll.UseVisualStyleBackColor = true;
        this.B_PasteAll.Click += new System.EventHandler(this.B_PasteAll_Click);
        // 
        // B_Paste
        // 
        this.B_Paste.Enabled = false;
        this.B_Paste.Location = new System.Drawing.Point(110, 359);
        this.B_Paste.Name = "B_Paste";
        this.B_Paste.Size = new System.Drawing.Size(90, 40);
        this.B_Paste.TabIndex = 509;
        this.B_Paste.Text = "Paste Current Table";
        this.B_Paste.UseVisualStyleBackColor = true;
        this.B_Paste.Click += new System.EventHandler(this.B_Paste_Click);
        // 
        // B_Copy
        // 
        this.B_Copy.Location = new System.Drawing.Point(14, 359);
        this.B_Copy.Name = "B_Copy";
        this.B_Copy.Size = new System.Drawing.Size(90, 40);
        this.B_Copy.TabIndex = 508;
        this.B_Copy.Text = "Copy Current Table";
        this.B_Copy.UseVisualStyleBackColor = true;
        this.B_Copy.Click += new System.EventHandler(this.B_Copy_Click);
        // 
        // GB_Tweak
        // 
        this.GB_Tweak.Controls.Add(this.CB_SlotRand);
        this.GB_Tweak.Controls.Add(this.L_SOS);
        this.GB_Tweak.Controls.Add(this.CHK_G7);
        this.GB_Tweak.Controls.Add(this.CHK_MegaForm);
        this.GB_Tweak.Controls.Add(this.L_RandOpt);
        this.GB_Tweak.Controls.Add(this.CHK_BST);
        this.GB_Tweak.Controls.Add(this.CHK_E);
        this.GB_Tweak.Controls.Add(this.CHK_L);
        this.GB_Tweak.Controls.Add(this.CHK_G6);
        this.GB_Tweak.Controls.Add(this.CHK_G5);
        this.GB_Tweak.Controls.Add(this.CHK_G4);
        this.GB_Tweak.Controls.Add(this.CHK_G3);
        this.GB_Tweak.Controls.Add(this.CHK_G2);
        this.GB_Tweak.Controls.Add(this.CHK_G1);
        this.GB_Tweak.Controls.Add(this.B_LevelPlus);
        this.GB_Tweak.Controls.Add(this.NUD_LevelAmp);
        this.GB_Tweak.Controls.Add(this.CHK_Level);
        this.GB_Tweak.Location = new System.Drawing.Point(14, 405);
        this.GB_Tweak.Name = "GB_Tweak";
        this.GB_Tweak.Size = new System.Drawing.Size(282, 150);
        this.GB_Tweak.TabIndex = 507;
        this.GB_Tweak.TabStop = false;
        this.GB_Tweak.Text = "Extra Randomization Tweaks";
        // 
        // CB_SlotRand
        // 
        this.CB_SlotRand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_SlotRand.DropDownWidth = 200;
        this.CB_SlotRand.FormattingEnabled = true;
        this.CB_SlotRand.Items.AddRange(new object[] {
            "Randomize All",
            "Randomize Regular Only",
            "Randomize SOS Only",
            "Randomize Regular, Copy to SOS"});
        this.CB_SlotRand.Location = new System.Drawing.Point(124, 120);
        this.CB_SlotRand.Name = "CB_SlotRand";
        this.CB_SlotRand.Size = new System.Drawing.Size(121, 21);
        this.CB_SlotRand.TabIndex = 299;
        // 
        // L_SOS
        // 
        this.L_SOS.Location = new System.Drawing.Point(-9, 117);
        this.L_SOS.Name = "L_SOS";
        this.L_SOS.Size = new System.Drawing.Size(130, 23);
        this.L_SOS.TabIndex = 298;
        this.L_SOS.Text = "Slot Randomization:";
        this.L_SOS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CHK_G7
        // 
        this.CHK_G7.AutoSize = true;
        this.CHK_G7.Checked = true;
        this.CHK_G7.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G7.Location = new System.Drawing.Point(19, 97);
        this.CHK_G7.Name = "CHK_G7";
        this.CHK_G7.Size = new System.Drawing.Size(55, 17);
        this.CHK_G7.TabIndex = 296;
        this.CHK_G7.Text = "Gen 7";
        this.CHK_G7.UseVisualStyleBackColor = true;
        // 
        // CHK_MegaForm
        // 
        this.CHK_MegaForm.AutoSize = true;
        this.CHK_MegaForm.Location = new System.Drawing.Point(138, 97);
        this.CHK_MegaForm.Name = "CHK_MegaForm";
        this.CHK_MegaForm.Size = new System.Drawing.Size(127, 17);
        this.CHK_MegaForm.TabIndex = 295;
        this.CHK_MegaForm.Text = "Random Mega Forms";
        this.CHK_MegaForm.UseVisualStyleBackColor = true;
        // 
        // L_RandOpt
        // 
        this.L_RandOpt.AutoSize = true;
        this.L_RandOpt.Location = new System.Drawing.Point(16, 34);
        this.L_RandOpt.Name = "L_RandOpt";
        this.L_RandOpt.Size = new System.Drawing.Size(105, 13);
        this.L_RandOpt.TabIndex = 294;
        this.L_RandOpt.Text = "Randomizer Options:";
        // 
        // CHK_BST
        // 
        this.CHK_BST.AutoSize = true;
        this.CHK_BST.Location = new System.Drawing.Point(138, 82);
        this.CHK_BST.Name = "CHK_BST";
        this.CHK_BST.Size = new System.Drawing.Size(117, 17);
        this.CHK_BST.TabIndex = 288;
        this.CHK_BST.Text = "Randomize by BST";
        this.CHK_BST.UseVisualStyleBackColor = true;
        // 
        // CHK_E
        // 
        this.CHK_E.AutoSize = true;
        this.CHK_E.Checked = true;
        this.CHK_E.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_E.Location = new System.Drawing.Point(138, 67);
        this.CHK_E.Name = "CHK_E";
        this.CHK_E.Size = new System.Drawing.Size(98, 17);
        this.CHK_E.TabIndex = 287;
        this.CHK_E.Text = "Event Legends";
        this.CHK_E.UseVisualStyleBackColor = true;
        // 
        // CHK_L
        // 
        this.CHK_L.AutoSize = true;
        this.CHK_L.Checked = true;
        this.CHK_L.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_L.Location = new System.Drawing.Point(138, 52);
        this.CHK_L.Name = "CHK_L";
        this.CHK_L.Size = new System.Drawing.Size(98, 17);
        this.CHK_L.TabIndex = 286;
        this.CHK_L.Text = "Game Legends";
        this.CHK_L.UseVisualStyleBackColor = true;
        // 
        // CHK_G6
        // 
        this.CHK_G6.AutoSize = true;
        this.CHK_G6.Checked = true;
        this.CHK_G6.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G6.Location = new System.Drawing.Point(77, 82);
        this.CHK_G6.Name = "CHK_G6";
        this.CHK_G6.Size = new System.Drawing.Size(55, 17);
        this.CHK_G6.TabIndex = 285;
        this.CHK_G6.Text = "Gen 6";
        this.CHK_G6.UseVisualStyleBackColor = true;
        // 
        // CHK_G5
        // 
        this.CHK_G5.AutoSize = true;
        this.CHK_G5.Checked = true;
        this.CHK_G5.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G5.Location = new System.Drawing.Point(77, 67);
        this.CHK_G5.Name = "CHK_G5";
        this.CHK_G5.Size = new System.Drawing.Size(55, 17);
        this.CHK_G5.TabIndex = 284;
        this.CHK_G5.Text = "Gen 5";
        this.CHK_G5.UseVisualStyleBackColor = true;
        // 
        // CHK_G4
        // 
        this.CHK_G4.AutoSize = true;
        this.CHK_G4.Checked = true;
        this.CHK_G4.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G4.Location = new System.Drawing.Point(77, 52);
        this.CHK_G4.Name = "CHK_G4";
        this.CHK_G4.Size = new System.Drawing.Size(55, 17);
        this.CHK_G4.TabIndex = 283;
        this.CHK_G4.Text = "Gen 4";
        this.CHK_G4.UseVisualStyleBackColor = true;
        // 
        // CHK_G3
        // 
        this.CHK_G3.AutoSize = true;
        this.CHK_G3.Checked = true;
        this.CHK_G3.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G3.Location = new System.Drawing.Point(19, 82);
        this.CHK_G3.Name = "CHK_G3";
        this.CHK_G3.Size = new System.Drawing.Size(55, 17);
        this.CHK_G3.TabIndex = 282;
        this.CHK_G3.Text = "Gen 3";
        this.CHK_G3.UseVisualStyleBackColor = true;
        // 
        // CHK_G2
        // 
        this.CHK_G2.AutoSize = true;
        this.CHK_G2.Checked = true;
        this.CHK_G2.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G2.Location = new System.Drawing.Point(19, 67);
        this.CHK_G2.Name = "CHK_G2";
        this.CHK_G2.Size = new System.Drawing.Size(55, 17);
        this.CHK_G2.TabIndex = 281;
        this.CHK_G2.Text = "Gen 2";
        this.CHK_G2.UseVisualStyleBackColor = true;
        // 
        // CHK_G1
        // 
        this.CHK_G1.AutoSize = true;
        this.CHK_G1.Checked = true;
        this.CHK_G1.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_G1.Location = new System.Drawing.Point(19, 52);
        this.CHK_G1.Name = "CHK_G1";
        this.CHK_G1.Size = new System.Drawing.Size(55, 17);
        this.CHK_G1.TabIndex = 280;
        this.CHK_G1.Text = "Gen 1";
        this.CHK_G1.UseVisualStyleBackColor = true;
        // 
        // B_LevelPlus
        // 
        this.B_LevelPlus.Location = new System.Drawing.Point(203, 14);
        this.B_LevelPlus.Name = "B_LevelPlus";
        this.B_LevelPlus.Size = new System.Drawing.Size(66, 23);
        this.B_LevelPlus.TabIndex = 277;
        this.B_LevelPlus.Text = "× Current";
        this.B_LevelPlus.UseVisualStyleBackColor = true;
        this.B_LevelPlus.Click += new System.EventHandler(this.ModifyAllLevelRanges);
        // 
        // NUD_LevelAmp
        // 
        this.NUD_LevelAmp.DecimalPlaces = 2;
        this.NUD_LevelAmp.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
        this.NUD_LevelAmp.Location = new System.Drawing.Point(152, 16);
        this.NUD_LevelAmp.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
        this.NUD_LevelAmp.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
        this.NUD_LevelAmp.Name = "NUD_LevelAmp";
        this.NUD_LevelAmp.Size = new System.Drawing.Size(48, 20);
        this.NUD_LevelAmp.TabIndex = 276;
        this.NUD_LevelAmp.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
        // 
        // CHK_Level
        // 
        this.CHK_Level.AutoSize = true;
        this.CHK_Level.Location = new System.Drawing.Point(19, 17);
        this.CHK_Level.Name = "CHK_Level";
        this.CHK_Level.Size = new System.Drawing.Size(130, 17);
        this.CHK_Level.TabIndex = 279;
        this.CHK_Level.Text = "Multiply PKM Level by";
        this.CHK_Level.UseVisualStyleBackColor = true;
        // 
        // PB_NightIcon
        // 
        this.PB_NightIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_NightIcon.Location = new System.Drawing.Point(708, 256);
        this.PB_NightIcon.Name = "PB_NightIcon";
        this.PB_NightIcon.Size = new System.Drawing.Size(20, 20);
        this.PB_NightIcon.TabIndex = 506;
        this.PB_NightIcon.TabStop = false;
        // 
        // PB_DayIcon
        // 
        this.PB_DayIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_DayIcon.Location = new System.Drawing.Point(278, 255);
        this.PB_DayIcon.Name = "PB_DayIcon";
        this.PB_DayIcon.Size = new System.Drawing.Size(20, 20);
        this.PB_DayIcon.TabIndex = 505;
        this.PB_DayIcon.TabStop = false;
        // 
        // NUP_WeatherForme6
        // 
        this.NUP_WeatherForme6.Location = new System.Drawing.Point(220, 332);
        this.NUP_WeatherForme6.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_WeatherForme6.Name = "NUP_WeatherForme6";
        this.NUP_WeatherForme6.Size = new System.Drawing.Size(31, 20);
        this.NUP_WeatherForme6.TabIndex = 504;
        // 
        // NUP_WeatherForme3
        // 
        this.NUP_WeatherForme3.Location = new System.Drawing.Point(111, 307);
        this.NUP_WeatherForme3.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_WeatherForme3.Name = "NUP_WeatherForme3";
        this.NUP_WeatherForme3.Size = new System.Drawing.Size(31, 20);
        this.NUP_WeatherForme3.TabIndex = 503;
        // 
        // CB_WeatherEnc6
        // 
        this.CB_WeatherEnc6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_WeatherEnc6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_WeatherEnc6.FormattingEnabled = true;
        this.CB_WeatherEnc6.Location = new System.Drawing.Point(145, 332);
        this.CB_WeatherEnc6.Name = "CB_WeatherEnc6";
        this.CB_WeatherEnc6.Size = new System.Drawing.Size(72, 21);
        this.CB_WeatherEnc6.TabIndex = 502;
        // 
        // NUP_WeatherForme5
        // 
        this.NUP_WeatherForme5.Location = new System.Drawing.Point(111, 333);
        this.NUP_WeatherForme5.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_WeatherForme5.Name = "NUP_WeatherForme5";
        this.NUP_WeatherForme5.Size = new System.Drawing.Size(31, 20);
        this.NUP_WeatherForme5.TabIndex = 501;
        // 
        // CB_WeatherEnc5
        // 
        this.CB_WeatherEnc5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_WeatherEnc5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_WeatherEnc5.FormattingEnabled = true;
        this.CB_WeatherEnc5.Location = new System.Drawing.Point(36, 332);
        this.CB_WeatherEnc5.Name = "CB_WeatherEnc5";
        this.CB_WeatherEnc5.Size = new System.Drawing.Size(72, 21);
        this.CB_WeatherEnc5.TabIndex = 500;
        // 
        // NUP_WeatherForme4
        // 
        this.NUP_WeatherForme4.Location = new System.Drawing.Point(220, 307);
        this.NUP_WeatherForme4.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_WeatherForme4.Name = "NUP_WeatherForme4";
        this.NUP_WeatherForme4.Size = new System.Drawing.Size(31, 20);
        this.NUP_WeatherForme4.TabIndex = 499;
        // 
        // CB_WeatherEnc4
        // 
        this.CB_WeatherEnc4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_WeatherEnc4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_WeatherEnc4.FormattingEnabled = true;
        this.CB_WeatherEnc4.Location = new System.Drawing.Point(145, 306);
        this.CB_WeatherEnc4.Name = "CB_WeatherEnc4";
        this.CB_WeatherEnc4.Size = new System.Drawing.Size(72, 21);
        this.CB_WeatherEnc4.TabIndex = 498;
        // 
        // CB_WeatherEnc3
        // 
        this.CB_WeatherEnc3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_WeatherEnc3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_WeatherEnc3.FormattingEnabled = true;
        this.CB_WeatherEnc3.Location = new System.Drawing.Point(36, 306);
        this.CB_WeatherEnc3.Name = "CB_WeatherEnc3";
        this.CB_WeatherEnc3.Size = new System.Drawing.Size(72, 21);
        this.CB_WeatherEnc3.TabIndex = 497;
        // 
        // NUP_WeatherForme2
        // 
        this.NUP_WeatherForme2.Location = new System.Drawing.Point(220, 280);
        this.NUP_WeatherForme2.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_WeatherForme2.Name = "NUP_WeatherForme2";
        this.NUP_WeatherForme2.Size = new System.Drawing.Size(31, 20);
        this.NUP_WeatherForme2.TabIndex = 496;
        // 
        // CB_WeatherEnc2
        // 
        this.CB_WeatherEnc2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_WeatherEnc2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_WeatherEnc2.FormattingEnabled = true;
        this.CB_WeatherEnc2.Location = new System.Drawing.Point(145, 279);
        this.CB_WeatherEnc2.Name = "CB_WeatherEnc2";
        this.CB_WeatherEnc2.Size = new System.Drawing.Size(72, 21);
        this.CB_WeatherEnc2.TabIndex = 495;
        // 
        // NUP_WeatherForme1
        // 
        this.NUP_WeatherForme1.Location = new System.Drawing.Point(111, 280);
        this.NUP_WeatherForme1.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_WeatherForme1.Name = "NUP_WeatherForme1";
        this.NUP_WeatherForme1.Size = new System.Drawing.Size(31, 20);
        this.NUP_WeatherForme1.TabIndex = 494;
        // 
        // CB_WeatherEnc1
        // 
        this.CB_WeatherEnc1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_WeatherEnc1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_WeatherEnc1.FormattingEnabled = true;
        this.CB_WeatherEnc1.Location = new System.Drawing.Point(36, 279);
        this.CB_WeatherEnc1.Name = "CB_WeatherEnc1";
        this.CB_WeatherEnc1.Size = new System.Drawing.Size(72, 21);
        this.CB_WeatherEnc1.TabIndex = 493;
        // 
        // L_AddSOS
        // 
        this.L_AddSOS.AutoSize = true;
        this.L_AddSOS.Location = new System.Drawing.Point(15, 256);
        this.L_AddSOS.Name = "L_AddSOS";
        this.L_AddSOS.Size = new System.Drawing.Size(76, 13);
        this.L_AddSOS.TabIndex = 492;
        this.L_AddSOS.Text = "Weather SOS:";
        // 
        // PB_NightTable
        // 
        this.PB_NightTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_NightTable.Location = new System.Drawing.Point(732, 255);
        this.PB_NightTable.Name = "PB_NightTable";
        this.PB_NightTable.Size = new System.Drawing.Size(400, 300);
        this.PB_NightTable.TabIndex = 491;
        this.PB_NightTable.TabStop = false;
        // 
        // PB_DayTable
        // 
        this.PB_DayTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.PB_DayTable.Location = new System.Drawing.Point(302, 255);
        this.PB_DayTable.Name = "PB_DayTable";
        this.PB_DayTable.Size = new System.Drawing.Size(400, 300);
        this.PB_DayTable.TabIndex = 490;
        this.PB_DayTable.TabStop = false;
        // 
        // NUP_Forme80
        // 
        this.NUP_Forme80.Location = new System.Drawing.Point(1101, 229);
        this.NUP_Forme80.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme80.Name = "NUP_Forme80";
        this.NUP_Forme80.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme80.TabIndex = 489;
        // 
        // CB_Enc80
        // 
        this.CB_Enc80.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc80.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc80.FormattingEnabled = true;
        this.CB_Enc80.Location = new System.Drawing.Point(1026, 229);
        this.CB_Enc80.Name = "CB_Enc80";
        this.CB_Enc80.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc80.TabIndex = 488;
        // 
        // NUP_Forme79
        // 
        this.NUP_Forme79.Location = new System.Drawing.Point(993, 230);
        this.NUP_Forme79.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme79.Name = "NUP_Forme79";
        this.NUP_Forme79.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme79.TabIndex = 487;
        // 
        // CB_Enc79
        // 
        this.CB_Enc79.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc79.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc79.FormattingEnabled = true;
        this.CB_Enc79.Location = new System.Drawing.Point(918, 229);
        this.CB_Enc79.Name = "CB_Enc79";
        this.CB_Enc79.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc79.TabIndex = 486;
        // 
        // NUP_Forme78
        // 
        this.NUP_Forme78.Location = new System.Drawing.Point(885, 230);
        this.NUP_Forme78.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme78.Name = "NUP_Forme78";
        this.NUP_Forme78.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme78.TabIndex = 485;
        // 
        // CB_Enc78
        // 
        this.CB_Enc78.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc78.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc78.FormattingEnabled = true;
        this.CB_Enc78.Location = new System.Drawing.Point(810, 229);
        this.CB_Enc78.Name = "CB_Enc78";
        this.CB_Enc78.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc78.TabIndex = 484;
        // 
        // NUP_Forme77
        // 
        this.NUP_Forme77.Location = new System.Drawing.Point(777, 230);
        this.NUP_Forme77.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme77.Name = "NUP_Forme77";
        this.NUP_Forme77.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme77.TabIndex = 483;
        // 
        // CB_Enc77
        // 
        this.CB_Enc77.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc77.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc77.FormattingEnabled = true;
        this.CB_Enc77.Location = new System.Drawing.Point(702, 229);
        this.CB_Enc77.Name = "CB_Enc77";
        this.CB_Enc77.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc77.TabIndex = 482;
        // 
        // NUP_Forme76
        // 
        this.NUP_Forme76.Location = new System.Drawing.Point(668, 230);
        this.NUP_Forme76.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme76.Name = "NUP_Forme76";
        this.NUP_Forme76.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme76.TabIndex = 481;
        // 
        // CB_Enc76
        // 
        this.CB_Enc76.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc76.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc76.FormattingEnabled = true;
        this.CB_Enc76.Location = new System.Drawing.Point(593, 229);
        this.CB_Enc76.Name = "CB_Enc76";
        this.CB_Enc76.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc76.TabIndex = 480;
        // 
        // NUP_Forme75
        // 
        this.NUP_Forme75.Location = new System.Drawing.Point(560, 230);
        this.NUP_Forme75.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme75.Name = "NUP_Forme75";
        this.NUP_Forme75.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme75.TabIndex = 479;
        // 
        // CB_Enc75
        // 
        this.CB_Enc75.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc75.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc75.FormattingEnabled = true;
        this.CB_Enc75.Location = new System.Drawing.Point(485, 229);
        this.CB_Enc75.Name = "CB_Enc75";
        this.CB_Enc75.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc75.TabIndex = 478;
        // 
        // NUP_Forme74
        // 
        this.NUP_Forme74.Location = new System.Drawing.Point(452, 230);
        this.NUP_Forme74.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme74.Name = "NUP_Forme74";
        this.NUP_Forme74.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme74.TabIndex = 477;
        // 
        // CB_Enc74
        // 
        this.CB_Enc74.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc74.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc74.FormattingEnabled = true;
        this.CB_Enc74.Location = new System.Drawing.Point(378, 229);
        this.CB_Enc74.Name = "CB_Enc74";
        this.CB_Enc74.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc74.TabIndex = 476;
        // 
        // NUP_Forme73
        // 
        this.NUP_Forme73.Location = new System.Drawing.Point(345, 230);
        this.NUP_Forme73.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme73.Name = "NUP_Forme73";
        this.NUP_Forme73.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme73.TabIndex = 475;
        // 
        // CB_Enc73
        // 
        this.CB_Enc73.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc73.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc73.FormattingEnabled = true;
        this.CB_Enc73.Location = new System.Drawing.Point(271, 229);
        this.CB_Enc73.Name = "CB_Enc73";
        this.CB_Enc73.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc73.TabIndex = 474;
        // 
        // NUP_Forme72
        // 
        this.NUP_Forme72.Location = new System.Drawing.Point(238, 230);
        this.NUP_Forme72.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme72.Name = "NUP_Forme72";
        this.NUP_Forme72.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme72.TabIndex = 473;
        // 
        // CB_Enc72
        // 
        this.CB_Enc72.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc72.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc72.FormattingEnabled = true;
        this.CB_Enc72.Location = new System.Drawing.Point(163, 229);
        this.CB_Enc72.Name = "CB_Enc72";
        this.CB_Enc72.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc72.TabIndex = 472;
        // 
        // NUP_Forme71
        // 
        this.NUP_Forme71.Location = new System.Drawing.Point(129, 230);
        this.NUP_Forme71.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme71.Name = "NUP_Forme71";
        this.NUP_Forme71.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme71.TabIndex = 471;
        // 
        // CB_Enc71
        // 
        this.CB_Enc71.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc71.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc71.FormattingEnabled = true;
        this.CB_Enc71.Location = new System.Drawing.Point(54, 229);
        this.CB_Enc71.Name = "CB_Enc71";
        this.CB_Enc71.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc71.TabIndex = 470;
        // 
        // L_SOS7
        // 
        this.L_SOS7.AutoSize = true;
        this.L_SOS7.Location = new System.Drawing.Point(12, 233);
        this.L_SOS7.Name = "L_SOS7";
        this.L_SOS7.Size = new System.Drawing.Size(41, 13);
        this.L_SOS7.TabIndex = 469;
        this.L_SOS7.Text = "SOS 7:";
        // 
        // NUP_Forme70
        // 
        this.NUP_Forme70.Location = new System.Drawing.Point(1101, 202);
        this.NUP_Forme70.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme70.Name = "NUP_Forme70";
        this.NUP_Forme70.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme70.TabIndex = 468;
        // 
        // CB_Enc70
        // 
        this.CB_Enc70.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc70.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc70.FormattingEnabled = true;
        this.CB_Enc70.Location = new System.Drawing.Point(1026, 202);
        this.CB_Enc70.Name = "CB_Enc70";
        this.CB_Enc70.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc70.TabIndex = 467;
        // 
        // NUP_Forme69
        // 
        this.NUP_Forme69.Location = new System.Drawing.Point(993, 203);
        this.NUP_Forme69.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme69.Name = "NUP_Forme69";
        this.NUP_Forme69.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme69.TabIndex = 466;
        // 
        // CB_Enc69
        // 
        this.CB_Enc69.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc69.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc69.FormattingEnabled = true;
        this.CB_Enc69.Location = new System.Drawing.Point(918, 202);
        this.CB_Enc69.Name = "CB_Enc69";
        this.CB_Enc69.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc69.TabIndex = 465;
        // 
        // NUP_Forme68
        // 
        this.NUP_Forme68.Location = new System.Drawing.Point(885, 203);
        this.NUP_Forme68.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme68.Name = "NUP_Forme68";
        this.NUP_Forme68.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme68.TabIndex = 464;
        // 
        // CB_Enc68
        // 
        this.CB_Enc68.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc68.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc68.FormattingEnabled = true;
        this.CB_Enc68.Location = new System.Drawing.Point(810, 202);
        this.CB_Enc68.Name = "CB_Enc68";
        this.CB_Enc68.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc68.TabIndex = 463;
        // 
        // NUP_Forme67
        // 
        this.NUP_Forme67.Location = new System.Drawing.Point(777, 203);
        this.NUP_Forme67.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme67.Name = "NUP_Forme67";
        this.NUP_Forme67.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme67.TabIndex = 462;
        // 
        // CB_Enc67
        // 
        this.CB_Enc67.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc67.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc67.FormattingEnabled = true;
        this.CB_Enc67.Location = new System.Drawing.Point(702, 202);
        this.CB_Enc67.Name = "CB_Enc67";
        this.CB_Enc67.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc67.TabIndex = 461;
        // 
        // NUP_Forme66
        // 
        this.NUP_Forme66.Location = new System.Drawing.Point(668, 203);
        this.NUP_Forme66.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme66.Name = "NUP_Forme66";
        this.NUP_Forme66.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme66.TabIndex = 460;
        // 
        // CB_Enc66
        // 
        this.CB_Enc66.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc66.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc66.FormattingEnabled = true;
        this.CB_Enc66.Location = new System.Drawing.Point(593, 202);
        this.CB_Enc66.Name = "CB_Enc66";
        this.CB_Enc66.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc66.TabIndex = 459;
        // 
        // NUP_Forme65
        // 
        this.NUP_Forme65.Location = new System.Drawing.Point(560, 203);
        this.NUP_Forme65.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme65.Name = "NUP_Forme65";
        this.NUP_Forme65.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme65.TabIndex = 458;
        // 
        // CB_Enc65
        // 
        this.CB_Enc65.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc65.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc65.FormattingEnabled = true;
        this.CB_Enc65.Location = new System.Drawing.Point(485, 202);
        this.CB_Enc65.Name = "CB_Enc65";
        this.CB_Enc65.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc65.TabIndex = 457;
        // 
        // NUP_Forme64
        // 
        this.NUP_Forme64.Location = new System.Drawing.Point(452, 203);
        this.NUP_Forme64.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme64.Name = "NUP_Forme64";
        this.NUP_Forme64.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme64.TabIndex = 456;
        // 
        // CB_Enc64
        // 
        this.CB_Enc64.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc64.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc64.FormattingEnabled = true;
        this.CB_Enc64.Location = new System.Drawing.Point(378, 202);
        this.CB_Enc64.Name = "CB_Enc64";
        this.CB_Enc64.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc64.TabIndex = 455;
        // 
        // NUP_Forme63
        // 
        this.NUP_Forme63.Location = new System.Drawing.Point(345, 203);
        this.NUP_Forme63.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme63.Name = "NUP_Forme63";
        this.NUP_Forme63.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme63.TabIndex = 454;
        // 
        // CB_Enc63
        // 
        this.CB_Enc63.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc63.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc63.FormattingEnabled = true;
        this.CB_Enc63.Location = new System.Drawing.Point(271, 202);
        this.CB_Enc63.Name = "CB_Enc63";
        this.CB_Enc63.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc63.TabIndex = 453;
        // 
        // NUP_Forme62
        // 
        this.NUP_Forme62.Location = new System.Drawing.Point(238, 203);
        this.NUP_Forme62.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme62.Name = "NUP_Forme62";
        this.NUP_Forme62.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme62.TabIndex = 452;
        // 
        // CB_Enc62
        // 
        this.CB_Enc62.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc62.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc62.FormattingEnabled = true;
        this.CB_Enc62.Location = new System.Drawing.Point(163, 202);
        this.CB_Enc62.Name = "CB_Enc62";
        this.CB_Enc62.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc62.TabIndex = 451;
        // 
        // NUP_Forme61
        // 
        this.NUP_Forme61.Location = new System.Drawing.Point(129, 203);
        this.NUP_Forme61.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme61.Name = "NUP_Forme61";
        this.NUP_Forme61.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme61.TabIndex = 450;
        // 
        // CB_Enc61
        // 
        this.CB_Enc61.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc61.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc61.FormattingEnabled = true;
        this.CB_Enc61.Location = new System.Drawing.Point(54, 202);
        this.CB_Enc61.Name = "CB_Enc61";
        this.CB_Enc61.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc61.TabIndex = 449;
        // 
        // L_SOS6
        // 
        this.L_SOS6.AutoSize = true;
        this.L_SOS6.Location = new System.Drawing.Point(12, 206);
        this.L_SOS6.Name = "L_SOS6";
        this.L_SOS6.Size = new System.Drawing.Size(41, 13);
        this.L_SOS6.TabIndex = 448;
        this.L_SOS6.Text = "SOS 6:";
        // 
        // NUP_Forme60
        // 
        this.NUP_Forme60.Location = new System.Drawing.Point(1101, 175);
        this.NUP_Forme60.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme60.Name = "NUP_Forme60";
        this.NUP_Forme60.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme60.TabIndex = 447;
        // 
        // CB_Enc60
        // 
        this.CB_Enc60.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc60.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc60.FormattingEnabled = true;
        this.CB_Enc60.Location = new System.Drawing.Point(1026, 175);
        this.CB_Enc60.Name = "CB_Enc60";
        this.CB_Enc60.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc60.TabIndex = 446;
        // 
        // NUP_Forme59
        // 
        this.NUP_Forme59.Location = new System.Drawing.Point(993, 176);
        this.NUP_Forme59.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme59.Name = "NUP_Forme59";
        this.NUP_Forme59.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme59.TabIndex = 445;
        // 
        // CB_Enc59
        // 
        this.CB_Enc59.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc59.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc59.FormattingEnabled = true;
        this.CB_Enc59.Location = new System.Drawing.Point(918, 175);
        this.CB_Enc59.Name = "CB_Enc59";
        this.CB_Enc59.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc59.TabIndex = 444;
        // 
        // NUP_Forme58
        // 
        this.NUP_Forme58.Location = new System.Drawing.Point(885, 176);
        this.NUP_Forme58.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme58.Name = "NUP_Forme58";
        this.NUP_Forme58.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme58.TabIndex = 443;
        // 
        // CB_Enc58
        // 
        this.CB_Enc58.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc58.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc58.FormattingEnabled = true;
        this.CB_Enc58.Location = new System.Drawing.Point(810, 175);
        this.CB_Enc58.Name = "CB_Enc58";
        this.CB_Enc58.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc58.TabIndex = 442;
        // 
        // NUP_Forme57
        // 
        this.NUP_Forme57.Location = new System.Drawing.Point(777, 176);
        this.NUP_Forme57.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme57.Name = "NUP_Forme57";
        this.NUP_Forme57.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme57.TabIndex = 441;
        // 
        // CB_Enc57
        // 
        this.CB_Enc57.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc57.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc57.FormattingEnabled = true;
        this.CB_Enc57.Location = new System.Drawing.Point(702, 175);
        this.CB_Enc57.Name = "CB_Enc57";
        this.CB_Enc57.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc57.TabIndex = 440;
        // 
        // NUP_Forme56
        // 
        this.NUP_Forme56.Location = new System.Drawing.Point(668, 176);
        this.NUP_Forme56.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme56.Name = "NUP_Forme56";
        this.NUP_Forme56.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme56.TabIndex = 439;
        // 
        // CB_Enc56
        // 
        this.CB_Enc56.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc56.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc56.FormattingEnabled = true;
        this.CB_Enc56.Location = new System.Drawing.Point(593, 175);
        this.CB_Enc56.Name = "CB_Enc56";
        this.CB_Enc56.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc56.TabIndex = 438;
        // 
        // NUP_Forme55
        // 
        this.NUP_Forme55.Location = new System.Drawing.Point(560, 176);
        this.NUP_Forme55.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme55.Name = "NUP_Forme55";
        this.NUP_Forme55.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme55.TabIndex = 437;
        // 
        // CB_Enc55
        // 
        this.CB_Enc55.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc55.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc55.FormattingEnabled = true;
        this.CB_Enc55.Location = new System.Drawing.Point(485, 175);
        this.CB_Enc55.Name = "CB_Enc55";
        this.CB_Enc55.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc55.TabIndex = 436;
        // 
        // NUP_Forme54
        // 
        this.NUP_Forme54.Location = new System.Drawing.Point(452, 176);
        this.NUP_Forme54.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme54.Name = "NUP_Forme54";
        this.NUP_Forme54.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme54.TabIndex = 435;
        // 
        // CB_Enc54
        // 
        this.CB_Enc54.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc54.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc54.FormattingEnabled = true;
        this.CB_Enc54.Location = new System.Drawing.Point(378, 175);
        this.CB_Enc54.Name = "CB_Enc54";
        this.CB_Enc54.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc54.TabIndex = 434;
        // 
        // NUP_Forme53
        // 
        this.NUP_Forme53.Location = new System.Drawing.Point(345, 176);
        this.NUP_Forme53.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme53.Name = "NUP_Forme53";
        this.NUP_Forme53.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme53.TabIndex = 433;
        // 
        // CB_Enc53
        // 
        this.CB_Enc53.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc53.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc53.FormattingEnabled = true;
        this.CB_Enc53.Location = new System.Drawing.Point(271, 175);
        this.CB_Enc53.Name = "CB_Enc53";
        this.CB_Enc53.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc53.TabIndex = 432;
        // 
        // NUP_Forme52
        // 
        this.NUP_Forme52.Location = new System.Drawing.Point(238, 176);
        this.NUP_Forme52.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme52.Name = "NUP_Forme52";
        this.NUP_Forme52.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme52.TabIndex = 431;
        // 
        // CB_Enc52
        // 
        this.CB_Enc52.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc52.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc52.FormattingEnabled = true;
        this.CB_Enc52.Location = new System.Drawing.Point(163, 175);
        this.CB_Enc52.Name = "CB_Enc52";
        this.CB_Enc52.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc52.TabIndex = 430;
        // 
        // NUP_Forme51
        // 
        this.NUP_Forme51.Location = new System.Drawing.Point(129, 176);
        this.NUP_Forme51.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme51.Name = "NUP_Forme51";
        this.NUP_Forme51.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme51.TabIndex = 429;
        // 
        // CB_Enc51
        // 
        this.CB_Enc51.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc51.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc51.FormattingEnabled = true;
        this.CB_Enc51.Location = new System.Drawing.Point(54, 175);
        this.CB_Enc51.Name = "CB_Enc51";
        this.CB_Enc51.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc51.TabIndex = 428;
        // 
        // L_SOS5
        // 
        this.L_SOS5.AutoSize = true;
        this.L_SOS5.Location = new System.Drawing.Point(12, 179);
        this.L_SOS5.Name = "L_SOS5";
        this.L_SOS5.Size = new System.Drawing.Size(41, 13);
        this.L_SOS5.TabIndex = 427;
        this.L_SOS5.Text = "SOS 5:";
        // 
        // NUP_Forme50
        // 
        this.NUP_Forme50.Location = new System.Drawing.Point(1101, 148);
        this.NUP_Forme50.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme50.Name = "NUP_Forme50";
        this.NUP_Forme50.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme50.TabIndex = 426;
        // 
        // CB_Enc50
        // 
        this.CB_Enc50.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc50.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc50.FormattingEnabled = true;
        this.CB_Enc50.Location = new System.Drawing.Point(1026, 148);
        this.CB_Enc50.Name = "CB_Enc50";
        this.CB_Enc50.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc50.TabIndex = 425;
        // 
        // NUP_Forme49
        // 
        this.NUP_Forme49.Location = new System.Drawing.Point(993, 149);
        this.NUP_Forme49.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme49.Name = "NUP_Forme49";
        this.NUP_Forme49.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme49.TabIndex = 424;
        // 
        // CB_Enc49
        // 
        this.CB_Enc49.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc49.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc49.FormattingEnabled = true;
        this.CB_Enc49.Location = new System.Drawing.Point(918, 148);
        this.CB_Enc49.Name = "CB_Enc49";
        this.CB_Enc49.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc49.TabIndex = 423;
        // 
        // NUP_Forme48
        // 
        this.NUP_Forme48.Location = new System.Drawing.Point(885, 149);
        this.NUP_Forme48.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme48.Name = "NUP_Forme48";
        this.NUP_Forme48.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme48.TabIndex = 422;
        // 
        // CB_Enc48
        // 
        this.CB_Enc48.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc48.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc48.FormattingEnabled = true;
        this.CB_Enc48.Location = new System.Drawing.Point(810, 148);
        this.CB_Enc48.Name = "CB_Enc48";
        this.CB_Enc48.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc48.TabIndex = 421;
        // 
        // NUP_Forme47
        // 
        this.NUP_Forme47.Location = new System.Drawing.Point(777, 149);
        this.NUP_Forme47.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme47.Name = "NUP_Forme47";
        this.NUP_Forme47.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme47.TabIndex = 420;
        // 
        // CB_Enc47
        // 
        this.CB_Enc47.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc47.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc47.FormattingEnabled = true;
        this.CB_Enc47.Location = new System.Drawing.Point(702, 148);
        this.CB_Enc47.Name = "CB_Enc47";
        this.CB_Enc47.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc47.TabIndex = 419;
        // 
        // NUP_Forme46
        // 
        this.NUP_Forme46.Location = new System.Drawing.Point(668, 149);
        this.NUP_Forme46.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme46.Name = "NUP_Forme46";
        this.NUP_Forme46.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme46.TabIndex = 418;
        // 
        // CB_Enc46
        // 
        this.CB_Enc46.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc46.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc46.FormattingEnabled = true;
        this.CB_Enc46.Location = new System.Drawing.Point(593, 148);
        this.CB_Enc46.Name = "CB_Enc46";
        this.CB_Enc46.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc46.TabIndex = 417;
        // 
        // NUP_Forme45
        // 
        this.NUP_Forme45.Location = new System.Drawing.Point(560, 149);
        this.NUP_Forme45.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme45.Name = "NUP_Forme45";
        this.NUP_Forme45.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme45.TabIndex = 416;
        // 
        // CB_Enc45
        // 
        this.CB_Enc45.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc45.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc45.FormattingEnabled = true;
        this.CB_Enc45.Location = new System.Drawing.Point(485, 148);
        this.CB_Enc45.Name = "CB_Enc45";
        this.CB_Enc45.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc45.TabIndex = 415;
        // 
        // NUP_Forme44
        // 
        this.NUP_Forme44.Location = new System.Drawing.Point(452, 149);
        this.NUP_Forme44.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme44.Name = "NUP_Forme44";
        this.NUP_Forme44.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme44.TabIndex = 414;
        // 
        // CB_Enc44
        // 
        this.CB_Enc44.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc44.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc44.FormattingEnabled = true;
        this.CB_Enc44.Location = new System.Drawing.Point(378, 148);
        this.CB_Enc44.Name = "CB_Enc44";
        this.CB_Enc44.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc44.TabIndex = 413;
        // 
        // NUP_Forme43
        // 
        this.NUP_Forme43.Location = new System.Drawing.Point(345, 149);
        this.NUP_Forme43.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme43.Name = "NUP_Forme43";
        this.NUP_Forme43.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme43.TabIndex = 412;
        // 
        // CB_Enc43
        // 
        this.CB_Enc43.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc43.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc43.FormattingEnabled = true;
        this.CB_Enc43.Location = new System.Drawing.Point(271, 148);
        this.CB_Enc43.Name = "CB_Enc43";
        this.CB_Enc43.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc43.TabIndex = 411;
        // 
        // NUP_Forme42
        // 
        this.NUP_Forme42.Location = new System.Drawing.Point(238, 149);
        this.NUP_Forme42.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme42.Name = "NUP_Forme42";
        this.NUP_Forme42.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme42.TabIndex = 410;
        // 
        // CB_Enc42
        // 
        this.CB_Enc42.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc42.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc42.FormattingEnabled = true;
        this.CB_Enc42.Location = new System.Drawing.Point(163, 148);
        this.CB_Enc42.Name = "CB_Enc42";
        this.CB_Enc42.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc42.TabIndex = 409;
        // 
        // NUP_Forme41
        // 
        this.NUP_Forme41.Location = new System.Drawing.Point(129, 149);
        this.NUP_Forme41.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme41.Name = "NUP_Forme41";
        this.NUP_Forme41.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme41.TabIndex = 408;
        // 
        // CB_Enc41
        // 
        this.CB_Enc41.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc41.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc41.FormattingEnabled = true;
        this.CB_Enc41.Location = new System.Drawing.Point(54, 148);
        this.CB_Enc41.Name = "CB_Enc41";
        this.CB_Enc41.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc41.TabIndex = 407;
        // 
        // L_SOS4
        // 
        this.L_SOS4.AutoSize = true;
        this.L_SOS4.Location = new System.Drawing.Point(12, 152);
        this.L_SOS4.Name = "L_SOS4";
        this.L_SOS4.Size = new System.Drawing.Size(41, 13);
        this.L_SOS4.TabIndex = 406;
        this.L_SOS4.Text = "SOS 4:";
        // 
        // NUP_Forme40
        // 
        this.NUP_Forme40.Location = new System.Drawing.Point(1101, 121);
        this.NUP_Forme40.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme40.Name = "NUP_Forme40";
        this.NUP_Forme40.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme40.TabIndex = 405;
        // 
        // CB_Enc40
        // 
        this.CB_Enc40.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc40.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc40.FormattingEnabled = true;
        this.CB_Enc40.Location = new System.Drawing.Point(1026, 121);
        this.CB_Enc40.Name = "CB_Enc40";
        this.CB_Enc40.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc40.TabIndex = 404;
        // 
        // NUP_Forme39
        // 
        this.NUP_Forme39.Location = new System.Drawing.Point(993, 122);
        this.NUP_Forme39.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme39.Name = "NUP_Forme39";
        this.NUP_Forme39.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme39.TabIndex = 403;
        // 
        // CB_Enc39
        // 
        this.CB_Enc39.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc39.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc39.FormattingEnabled = true;
        this.CB_Enc39.Location = new System.Drawing.Point(918, 121);
        this.CB_Enc39.Name = "CB_Enc39";
        this.CB_Enc39.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc39.TabIndex = 402;
        // 
        // NUP_Forme38
        // 
        this.NUP_Forme38.Location = new System.Drawing.Point(885, 122);
        this.NUP_Forme38.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme38.Name = "NUP_Forme38";
        this.NUP_Forme38.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme38.TabIndex = 401;
        // 
        // CB_Enc38
        // 
        this.CB_Enc38.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc38.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc38.FormattingEnabled = true;
        this.CB_Enc38.Location = new System.Drawing.Point(810, 121);
        this.CB_Enc38.Name = "CB_Enc38";
        this.CB_Enc38.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc38.TabIndex = 400;
        // 
        // NUP_Forme37
        // 
        this.NUP_Forme37.Location = new System.Drawing.Point(777, 122);
        this.NUP_Forme37.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme37.Name = "NUP_Forme37";
        this.NUP_Forme37.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme37.TabIndex = 399;
        // 
        // CB_Enc37
        // 
        this.CB_Enc37.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc37.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc37.FormattingEnabled = true;
        this.CB_Enc37.Location = new System.Drawing.Point(702, 121);
        this.CB_Enc37.Name = "CB_Enc37";
        this.CB_Enc37.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc37.TabIndex = 398;
        // 
        // NUP_Forme36
        // 
        this.NUP_Forme36.Location = new System.Drawing.Point(668, 122);
        this.NUP_Forme36.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme36.Name = "NUP_Forme36";
        this.NUP_Forme36.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme36.TabIndex = 397;
        // 
        // CB_Enc36
        // 
        this.CB_Enc36.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc36.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc36.FormattingEnabled = true;
        this.CB_Enc36.Location = new System.Drawing.Point(593, 121);
        this.CB_Enc36.Name = "CB_Enc36";
        this.CB_Enc36.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc36.TabIndex = 396;
        // 
        // NUP_Forme35
        // 
        this.NUP_Forme35.Location = new System.Drawing.Point(560, 122);
        this.NUP_Forme35.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme35.Name = "NUP_Forme35";
        this.NUP_Forme35.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme35.TabIndex = 395;
        // 
        // CB_Enc35
        // 
        this.CB_Enc35.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc35.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc35.FormattingEnabled = true;
        this.CB_Enc35.Location = new System.Drawing.Point(485, 121);
        this.CB_Enc35.Name = "CB_Enc35";
        this.CB_Enc35.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc35.TabIndex = 394;
        // 
        // NUP_Forme34
        // 
        this.NUP_Forme34.Location = new System.Drawing.Point(452, 122);
        this.NUP_Forme34.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme34.Name = "NUP_Forme34";
        this.NUP_Forme34.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme34.TabIndex = 393;
        // 
        // CB_Enc34
        // 
        this.CB_Enc34.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc34.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc34.FormattingEnabled = true;
        this.CB_Enc34.Location = new System.Drawing.Point(378, 121);
        this.CB_Enc34.Name = "CB_Enc34";
        this.CB_Enc34.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc34.TabIndex = 392;
        // 
        // NUP_Forme33
        // 
        this.NUP_Forme33.Location = new System.Drawing.Point(345, 122);
        this.NUP_Forme33.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme33.Name = "NUP_Forme33";
        this.NUP_Forme33.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme33.TabIndex = 391;
        // 
        // CB_Enc33
        // 
        this.CB_Enc33.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc33.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc33.FormattingEnabled = true;
        this.CB_Enc33.Location = new System.Drawing.Point(271, 121);
        this.CB_Enc33.Name = "CB_Enc33";
        this.CB_Enc33.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc33.TabIndex = 390;
        // 
        // NUP_Forme32
        // 
        this.NUP_Forme32.Location = new System.Drawing.Point(238, 122);
        this.NUP_Forme32.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme32.Name = "NUP_Forme32";
        this.NUP_Forme32.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme32.TabIndex = 389;
        // 
        // CB_Enc32
        // 
        this.CB_Enc32.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc32.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc32.FormattingEnabled = true;
        this.CB_Enc32.Location = new System.Drawing.Point(163, 121);
        this.CB_Enc32.Name = "CB_Enc32";
        this.CB_Enc32.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc32.TabIndex = 388;
        // 
        // NUP_Forme31
        // 
        this.NUP_Forme31.Location = new System.Drawing.Point(129, 122);
        this.NUP_Forme31.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme31.Name = "NUP_Forme31";
        this.NUP_Forme31.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme31.TabIndex = 387;
        // 
        // CB_Enc31
        // 
        this.CB_Enc31.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc31.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc31.FormattingEnabled = true;
        this.CB_Enc31.Location = new System.Drawing.Point(54, 121);
        this.CB_Enc31.Name = "CB_Enc31";
        this.CB_Enc31.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc31.TabIndex = 386;
        // 
        // L_SOS3
        // 
        this.L_SOS3.AutoSize = true;
        this.L_SOS3.Location = new System.Drawing.Point(12, 125);
        this.L_SOS3.Name = "L_SOS3";
        this.L_SOS3.Size = new System.Drawing.Size(41, 13);
        this.L_SOS3.TabIndex = 385;
        this.L_SOS3.Text = "SOS 3:";
        // 
        // NUP_Forme30
        // 
        this.NUP_Forme30.Location = new System.Drawing.Point(1101, 94);
        this.NUP_Forme30.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme30.Name = "NUP_Forme30";
        this.NUP_Forme30.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme30.TabIndex = 384;
        // 
        // CB_Enc30
        // 
        this.CB_Enc30.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc30.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc30.FormattingEnabled = true;
        this.CB_Enc30.Location = new System.Drawing.Point(1026, 94);
        this.CB_Enc30.Name = "CB_Enc30";
        this.CB_Enc30.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc30.TabIndex = 383;
        // 
        // NUP_Forme29
        // 
        this.NUP_Forme29.Location = new System.Drawing.Point(993, 95);
        this.NUP_Forme29.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme29.Name = "NUP_Forme29";
        this.NUP_Forme29.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme29.TabIndex = 382;
        // 
        // CB_Enc29
        // 
        this.CB_Enc29.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc29.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc29.FormattingEnabled = true;
        this.CB_Enc29.Location = new System.Drawing.Point(918, 94);
        this.CB_Enc29.Name = "CB_Enc29";
        this.CB_Enc29.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc29.TabIndex = 381;
        // 
        // NUP_Forme28
        // 
        this.NUP_Forme28.Location = new System.Drawing.Point(885, 95);
        this.NUP_Forme28.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme28.Name = "NUP_Forme28";
        this.NUP_Forme28.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme28.TabIndex = 380;
        // 
        // CB_Enc28
        // 
        this.CB_Enc28.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc28.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc28.FormattingEnabled = true;
        this.CB_Enc28.Location = new System.Drawing.Point(810, 94);
        this.CB_Enc28.Name = "CB_Enc28";
        this.CB_Enc28.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc28.TabIndex = 379;
        // 
        // NUP_Forme27
        // 
        this.NUP_Forme27.Location = new System.Drawing.Point(777, 95);
        this.NUP_Forme27.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme27.Name = "NUP_Forme27";
        this.NUP_Forme27.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme27.TabIndex = 378;
        // 
        // CB_Enc27
        // 
        this.CB_Enc27.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc27.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc27.FormattingEnabled = true;
        this.CB_Enc27.Location = new System.Drawing.Point(702, 94);
        this.CB_Enc27.Name = "CB_Enc27";
        this.CB_Enc27.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc27.TabIndex = 377;
        // 
        // NUP_Forme26
        // 
        this.NUP_Forme26.Location = new System.Drawing.Point(668, 95);
        this.NUP_Forme26.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme26.Name = "NUP_Forme26";
        this.NUP_Forme26.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme26.TabIndex = 376;
        // 
        // CB_Enc26
        // 
        this.CB_Enc26.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc26.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc26.FormattingEnabled = true;
        this.CB_Enc26.Location = new System.Drawing.Point(593, 94);
        this.CB_Enc26.Name = "CB_Enc26";
        this.CB_Enc26.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc26.TabIndex = 375;
        // 
        // NUP_Forme25
        // 
        this.NUP_Forme25.Location = new System.Drawing.Point(560, 95);
        this.NUP_Forme25.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme25.Name = "NUP_Forme25";
        this.NUP_Forme25.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme25.TabIndex = 374;
        // 
        // CB_Enc25
        // 
        this.CB_Enc25.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc25.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc25.FormattingEnabled = true;
        this.CB_Enc25.Location = new System.Drawing.Point(485, 94);
        this.CB_Enc25.Name = "CB_Enc25";
        this.CB_Enc25.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc25.TabIndex = 373;
        // 
        // NUP_Forme24
        // 
        this.NUP_Forme24.Location = new System.Drawing.Point(452, 95);
        this.NUP_Forme24.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme24.Name = "NUP_Forme24";
        this.NUP_Forme24.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme24.TabIndex = 372;
        // 
        // CB_Enc24
        // 
        this.CB_Enc24.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc24.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc24.FormattingEnabled = true;
        this.CB_Enc24.Location = new System.Drawing.Point(378, 94);
        this.CB_Enc24.Name = "CB_Enc24";
        this.CB_Enc24.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc24.TabIndex = 371;
        // 
        // NUP_Forme23
        // 
        this.NUP_Forme23.Location = new System.Drawing.Point(345, 95);
        this.NUP_Forme23.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme23.Name = "NUP_Forme23";
        this.NUP_Forme23.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme23.TabIndex = 370;
        // 
        // CB_Enc23
        // 
        this.CB_Enc23.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc23.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc23.FormattingEnabled = true;
        this.CB_Enc23.Location = new System.Drawing.Point(271, 94);
        this.CB_Enc23.Name = "CB_Enc23";
        this.CB_Enc23.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc23.TabIndex = 369;
        // 
        // NUP_Forme22
        // 
        this.NUP_Forme22.Location = new System.Drawing.Point(238, 95);
        this.NUP_Forme22.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme22.Name = "NUP_Forme22";
        this.NUP_Forme22.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme22.TabIndex = 368;
        // 
        // CB_Enc22
        // 
        this.CB_Enc22.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc22.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc22.FormattingEnabled = true;
        this.CB_Enc22.Location = new System.Drawing.Point(163, 94);
        this.CB_Enc22.Name = "CB_Enc22";
        this.CB_Enc22.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc22.TabIndex = 367;
        // 
        // NUP_Forme21
        // 
        this.NUP_Forme21.Location = new System.Drawing.Point(129, 95);
        this.NUP_Forme21.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme21.Name = "NUP_Forme21";
        this.NUP_Forme21.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme21.TabIndex = 366;
        // 
        // CB_Enc21
        // 
        this.CB_Enc21.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc21.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc21.FormattingEnabled = true;
        this.CB_Enc21.Location = new System.Drawing.Point(54, 94);
        this.CB_Enc21.Name = "CB_Enc21";
        this.CB_Enc21.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc21.TabIndex = 365;
        // 
        // L_SOS2
        // 
        this.L_SOS2.AutoSize = true;
        this.L_SOS2.Location = new System.Drawing.Point(12, 98);
        this.L_SOS2.Name = "L_SOS2";
        this.L_SOS2.Size = new System.Drawing.Size(41, 13);
        this.L_SOS2.TabIndex = 364;
        this.L_SOS2.Text = "SOS 2:";
        // 
        // NUP_Forme20
        // 
        this.NUP_Forme20.Location = new System.Drawing.Point(1101, 67);
        this.NUP_Forme20.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme20.Name = "NUP_Forme20";
        this.NUP_Forme20.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme20.TabIndex = 363;
        // 
        // CB_Enc20
        // 
        this.CB_Enc20.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc20.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc20.FormattingEnabled = true;
        this.CB_Enc20.Location = new System.Drawing.Point(1026, 67);
        this.CB_Enc20.Name = "CB_Enc20";
        this.CB_Enc20.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc20.TabIndex = 362;
        // 
        // NUP_Forme19
        // 
        this.NUP_Forme19.Location = new System.Drawing.Point(993, 68);
        this.NUP_Forme19.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme19.Name = "NUP_Forme19";
        this.NUP_Forme19.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme19.TabIndex = 361;
        // 
        // CB_Enc19
        // 
        this.CB_Enc19.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc19.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc19.FormattingEnabled = true;
        this.CB_Enc19.Location = new System.Drawing.Point(918, 67);
        this.CB_Enc19.Name = "CB_Enc19";
        this.CB_Enc19.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc19.TabIndex = 360;
        // 
        // NUP_Forme18
        // 
        this.NUP_Forme18.Location = new System.Drawing.Point(885, 68);
        this.NUP_Forme18.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme18.Name = "NUP_Forme18";
        this.NUP_Forme18.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme18.TabIndex = 359;
        // 
        // CB_Enc18
        // 
        this.CB_Enc18.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc18.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc18.FormattingEnabled = true;
        this.CB_Enc18.Location = new System.Drawing.Point(810, 67);
        this.CB_Enc18.Name = "CB_Enc18";
        this.CB_Enc18.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc18.TabIndex = 358;
        // 
        // NUP_Forme17
        // 
        this.NUP_Forme17.Location = new System.Drawing.Point(777, 68);
        this.NUP_Forme17.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme17.Name = "NUP_Forme17";
        this.NUP_Forme17.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme17.TabIndex = 357;
        // 
        // CB_Enc17
        // 
        this.CB_Enc17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc17.FormattingEnabled = true;
        this.CB_Enc17.Location = new System.Drawing.Point(702, 67);
        this.CB_Enc17.Name = "CB_Enc17";
        this.CB_Enc17.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc17.TabIndex = 356;
        // 
        // NUP_Forme16
        // 
        this.NUP_Forme16.Location = new System.Drawing.Point(668, 68);
        this.NUP_Forme16.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme16.Name = "NUP_Forme16";
        this.NUP_Forme16.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme16.TabIndex = 355;
        // 
        // CB_Enc16
        // 
        this.CB_Enc16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc16.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc16.FormattingEnabled = true;
        this.CB_Enc16.Location = new System.Drawing.Point(593, 67);
        this.CB_Enc16.Name = "CB_Enc16";
        this.CB_Enc16.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc16.TabIndex = 354;
        // 
        // NUP_Forme15
        // 
        this.NUP_Forme15.Location = new System.Drawing.Point(560, 68);
        this.NUP_Forme15.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme15.Name = "NUP_Forme15";
        this.NUP_Forme15.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme15.TabIndex = 353;
        // 
        // CB_Enc15
        // 
        this.CB_Enc15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc15.FormattingEnabled = true;
        this.CB_Enc15.Location = new System.Drawing.Point(485, 67);
        this.CB_Enc15.Name = "CB_Enc15";
        this.CB_Enc15.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc15.TabIndex = 352;
        // 
        // NUP_Forme14
        // 
        this.NUP_Forme14.Location = new System.Drawing.Point(452, 68);
        this.NUP_Forme14.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme14.Name = "NUP_Forme14";
        this.NUP_Forme14.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme14.TabIndex = 351;
        // 
        // CB_Enc14
        // 
        this.CB_Enc14.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc14.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc14.FormattingEnabled = true;
        this.CB_Enc14.Location = new System.Drawing.Point(378, 67);
        this.CB_Enc14.Name = "CB_Enc14";
        this.CB_Enc14.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc14.TabIndex = 350;
        // 
        // NUP_Forme13
        // 
        this.NUP_Forme13.Location = new System.Drawing.Point(345, 68);
        this.NUP_Forme13.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme13.Name = "NUP_Forme13";
        this.NUP_Forme13.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme13.TabIndex = 349;
        // 
        // CB_Enc13
        // 
        this.CB_Enc13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc13.FormattingEnabled = true;
        this.CB_Enc13.Location = new System.Drawing.Point(271, 67);
        this.CB_Enc13.Name = "CB_Enc13";
        this.CB_Enc13.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc13.TabIndex = 348;
        // 
        // NUP_Forme12
        // 
        this.NUP_Forme12.Location = new System.Drawing.Point(238, 68);
        this.NUP_Forme12.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme12.Name = "NUP_Forme12";
        this.NUP_Forme12.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme12.TabIndex = 347;
        // 
        // CB_Enc12
        // 
        this.CB_Enc12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc12.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc12.FormattingEnabled = true;
        this.CB_Enc12.Location = new System.Drawing.Point(163, 67);
        this.CB_Enc12.Name = "CB_Enc12";
        this.CB_Enc12.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc12.TabIndex = 346;
        // 
        // NUP_Forme11
        // 
        this.NUP_Forme11.Location = new System.Drawing.Point(129, 68);
        this.NUP_Forme11.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme11.Name = "NUP_Forme11";
        this.NUP_Forme11.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme11.TabIndex = 345;
        // 
        // CB_Enc11
        // 
        this.CB_Enc11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc11.FormattingEnabled = true;
        this.CB_Enc11.Location = new System.Drawing.Point(54, 67);
        this.CB_Enc11.Name = "CB_Enc11";
        this.CB_Enc11.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc11.TabIndex = 344;
        // 
        // L_SOS1
        // 
        this.L_SOS1.AutoSize = true;
        this.L_SOS1.Location = new System.Drawing.Point(12, 71);
        this.L_SOS1.Name = "L_SOS1";
        this.L_SOS1.Size = new System.Drawing.Size(41, 13);
        this.L_SOS1.TabIndex = 343;
        this.L_SOS1.Text = "SOS 1:";
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Location = new System.Drawing.Point(15, 39);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(39, 13);
        this.label1.TabIndex = 342;
        this.label1.Text = "Initials:";
        // 
        // NUP_Forme10
        // 
        this.NUP_Forme10.Location = new System.Drawing.Point(1101, 37);
        this.NUP_Forme10.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme10.Name = "NUP_Forme10";
        this.NUP_Forme10.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme10.TabIndex = 340;
        // 
        // CB_Enc10
        // 
        this.CB_Enc10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc10.FormattingEnabled = true;
        this.CB_Enc10.Location = new System.Drawing.Point(1026, 37);
        this.CB_Enc10.Name = "CB_Enc10";
        this.CB_Enc10.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc10.TabIndex = 339;
        // 
        // NUP_Rate10
        // 
        this.NUP_Rate10.AutoSize = true;
        this.NUP_Rate10.Location = new System.Drawing.Point(1052, 16);
        this.NUP_Rate10.Name = "NUP_Rate10";
        this.NUP_Rate10.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate10.TabIndex = 341;
        // 
        // NUP_Forme09
        // 
        this.NUP_Forme09.Location = new System.Drawing.Point(993, 38);
        this.NUP_Forme09.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme09.Name = "NUP_Forme09";
        this.NUP_Forme09.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme09.TabIndex = 337;
        // 
        // CB_Enc09
        // 
        this.CB_Enc09.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc09.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc09.FormattingEnabled = true;
        this.CB_Enc09.Location = new System.Drawing.Point(918, 37);
        this.CB_Enc09.Name = "CB_Enc09";
        this.CB_Enc09.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc09.TabIndex = 336;
        // 
        // NUP_Rate9
        // 
        this.NUP_Rate9.AutoSize = true;
        this.NUP_Rate9.Location = new System.Drawing.Point(942, 16);
        this.NUP_Rate9.Name = "NUP_Rate9";
        this.NUP_Rate9.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate9.TabIndex = 338;
        // 
        // NUP_Forme08
        // 
        this.NUP_Forme08.Location = new System.Drawing.Point(885, 38);
        this.NUP_Forme08.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme08.Name = "NUP_Forme08";
        this.NUP_Forme08.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme08.TabIndex = 334;
        // 
        // CB_Enc08
        // 
        this.CB_Enc08.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc08.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc08.FormattingEnabled = true;
        this.CB_Enc08.Location = new System.Drawing.Point(810, 37);
        this.CB_Enc08.Name = "CB_Enc08";
        this.CB_Enc08.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc08.TabIndex = 333;
        // 
        // NUP_Rate8
        // 
        this.NUP_Rate8.AutoSize = true;
        this.NUP_Rate8.Location = new System.Drawing.Point(836, 16);
        this.NUP_Rate8.Name = "NUP_Rate8";
        this.NUP_Rate8.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate8.TabIndex = 335;
        // 
        // NUP_Forme07
        // 
        this.NUP_Forme07.Location = new System.Drawing.Point(777, 38);
        this.NUP_Forme07.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme07.Name = "NUP_Forme07";
        this.NUP_Forme07.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme07.TabIndex = 331;
        // 
        // CB_Enc07
        // 
        this.CB_Enc07.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc07.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc07.FormattingEnabled = true;
        this.CB_Enc07.Location = new System.Drawing.Point(702, 37);
        this.CB_Enc07.Name = "CB_Enc07";
        this.CB_Enc07.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc07.TabIndex = 330;
        // 
        // NUP_Rate7
        // 
        this.NUP_Rate7.AutoSize = true;
        this.NUP_Rate7.Location = new System.Drawing.Point(724, 16);
        this.NUP_Rate7.Name = "NUP_Rate7";
        this.NUP_Rate7.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate7.TabIndex = 332;
        // 
        // NUP_Forme06
        // 
        this.NUP_Forme06.Location = new System.Drawing.Point(668, 38);
        this.NUP_Forme06.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme06.Name = "NUP_Forme06";
        this.NUP_Forme06.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme06.TabIndex = 328;
        // 
        // CB_Enc06
        // 
        this.CB_Enc06.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc06.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc06.FormattingEnabled = true;
        this.CB_Enc06.Location = new System.Drawing.Point(593, 37);
        this.CB_Enc06.Name = "CB_Enc06";
        this.CB_Enc06.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc06.TabIndex = 327;
        // 
        // NUP_Rate6
        // 
        this.NUP_Rate6.AutoSize = true;
        this.NUP_Rate6.Location = new System.Drawing.Point(616, 16);
        this.NUP_Rate6.Name = "NUP_Rate6";
        this.NUP_Rate6.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate6.TabIndex = 329;
        // 
        // NUP_Forme05
        // 
        this.NUP_Forme05.Location = new System.Drawing.Point(560, 38);
        this.NUP_Forme05.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme05.Name = "NUP_Forme05";
        this.NUP_Forme05.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme05.TabIndex = 325;
        // 
        // CB_Enc05
        // 
        this.CB_Enc05.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc05.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc05.FormattingEnabled = true;
        this.CB_Enc05.Location = new System.Drawing.Point(485, 37);
        this.CB_Enc05.Name = "CB_Enc05";
        this.CB_Enc05.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc05.TabIndex = 324;
        // 
        // NUP_Rate5
        // 
        this.NUP_Rate5.AutoSize = true;
        this.NUP_Rate5.Location = new System.Drawing.Point(505, 16);
        this.NUP_Rate5.Name = "NUP_Rate5";
        this.NUP_Rate5.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate5.TabIndex = 326;
        // 
        // NUP_Forme04
        // 
        this.NUP_Forme04.Location = new System.Drawing.Point(452, 38);
        this.NUP_Forme04.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme04.Name = "NUP_Forme04";
        this.NUP_Forme04.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme04.TabIndex = 322;
        // 
        // CB_Enc04
        // 
        this.CB_Enc04.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc04.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc04.FormattingEnabled = true;
        this.CB_Enc04.Location = new System.Drawing.Point(378, 37);
        this.CB_Enc04.Name = "CB_Enc04";
        this.CB_Enc04.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc04.TabIndex = 321;
        // 
        // NUP_Rate4
        // 
        this.NUP_Rate4.AutoSize = true;
        this.NUP_Rate4.Location = new System.Drawing.Point(400, 16);
        this.NUP_Rate4.Name = "NUP_Rate4";
        this.NUP_Rate4.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate4.TabIndex = 323;
        // 
        // NUP_Forme03
        // 
        this.NUP_Forme03.Location = new System.Drawing.Point(345, 38);
        this.NUP_Forme03.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme03.Name = "NUP_Forme03";
        this.NUP_Forme03.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme03.TabIndex = 319;
        // 
        // CB_Enc03
        // 
        this.CB_Enc03.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc03.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc03.FormattingEnabled = true;
        this.CB_Enc03.Location = new System.Drawing.Point(271, 37);
        this.CB_Enc03.Name = "CB_Enc03";
        this.CB_Enc03.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc03.TabIndex = 318;
        // 
        // NUP_Rate3
        // 
        this.NUP_Rate3.AutoSize = true;
        this.NUP_Rate3.Location = new System.Drawing.Point(294, 16);
        this.NUP_Rate3.Name = "NUP_Rate3";
        this.NUP_Rate3.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate3.TabIndex = 320;
        // 
        // NUP_Forme02
        // 
        this.NUP_Forme02.Location = new System.Drawing.Point(238, 38);
        this.NUP_Forme02.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme02.Name = "NUP_Forme02";
        this.NUP_Forme02.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme02.TabIndex = 316;
        // 
        // CB_Enc02
        // 
        this.CB_Enc02.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc02.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc02.FormattingEnabled = true;
        this.CB_Enc02.Location = new System.Drawing.Point(163, 37);
        this.CB_Enc02.Name = "CB_Enc02";
        this.CB_Enc02.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc02.TabIndex = 315;
        // 
        // NUP_Rate2
        // 
        this.NUP_Rate2.AutoSize = true;
        this.NUP_Rate2.Location = new System.Drawing.Point(187, 16);
        this.NUP_Rate2.Name = "NUP_Rate2";
        this.NUP_Rate2.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate2.TabIndex = 317;
        // 
        // L_Rate
        // 
        this.L_Rate.AutoSize = true;
        this.L_Rate.Location = new System.Drawing.Point(15, 16);
        this.L_Rate.Name = "L_Rate";
        this.L_Rate.Size = new System.Drawing.Size(38, 13);
        this.L_Rate.TabIndex = 314;
        this.L_Rate.Text = "Rates:";
        // 
        // NUP_Forme01
        // 
        this.NUP_Forme01.Location = new System.Drawing.Point(129, 38);
        this.NUP_Forme01.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
        this.NUP_Forme01.Name = "NUP_Forme01";
        this.NUP_Forme01.Size = new System.Drawing.Size(31, 20);
        this.NUP_Forme01.TabIndex = 289;
        // 
        // CB_Enc01
        // 
        this.CB_Enc01.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Enc01.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Enc01.FormattingEnabled = true;
        this.CB_Enc01.Location = new System.Drawing.Point(54, 37);
        this.CB_Enc01.Name = "CB_Enc01";
        this.CB_Enc01.Size = new System.Drawing.Size(72, 21);
        this.CB_Enc01.TabIndex = 288;
        // 
        // NUP_Rate1
        // 
        this.NUP_Rate1.AutoSize = true;
        this.NUP_Rate1.Location = new System.Drawing.Point(78, 16);
        this.NUP_Rate1.Name = "NUP_Rate1";
        this.NUP_Rate1.Size = new System.Drawing.Size(41, 20);
        this.NUP_Rate1.TabIndex = 290;
        // 
        // CB_TableID
        // 
        this.CB_TableID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_TableID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_TableID.FormattingEnabled = true;
        this.CB_TableID.Location = new System.Drawing.Point(269, 12);
        this.CB_TableID.Name = "CB_TableID";
        this.CB_TableID.Size = new System.Drawing.Size(90, 21);
        this.CB_TableID.TabIndex = 431;
        this.CB_TableID.SelectedIndexChanged += new System.EventHandler(this.UpdatePanel);
        // 
        // B_Export
        // 
        this.B_Export.Location = new System.Drawing.Point(1034, 11);
        this.B_Export.Name = "B_Export";
        this.B_Export.Size = new System.Drawing.Size(112, 23);
        this.B_Export.TabIndex = 432;
        this.B_Export.Text = "Export Tables";
        this.B_Export.UseVisualStyleBackColor = true;
        this.B_Export.Click += new System.EventHandler(this.B_Export_Click);
        // 
        // CopySOS
        // 
        this.CopySOS.Location = new System.Drawing.Point(698, 11);
        this.CopySOS.Name = "CopySOS";
        this.CopySOS.Size = new System.Drawing.Size(109, 23);
        this.CopySOS.TabIndex = 433;
        this.CopySOS.Text = "Copy Initials to SOS";
        this.CopySOS.UseVisualStyleBackColor = true;
        this.CopySOS.Click += new System.EventHandler(this.CopySOS_Click);
        // 
        // SMWE
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(1161, 612);
        this.Controls.Add(this.CopySOS);
        this.Controls.Add(this.B_Export);
        this.Controls.Add(this.CB_TableID);
        this.Controls.Add(this.GB_Encounters);
        this.Controls.Add(this.L_Table);
        this.Controls.Add(this.NUP_Min);
        this.Controls.Add(this.NUP_Max);
        this.Controls.Add(this.L_Min);
        this.Controls.Add(this.L_Max);
        this.Controls.Add(this.B_Randomize);
        this.Controls.Add(this.B_Dump);
        this.Controls.Add(this.L_Location);
        this.Controls.Add(this.B_Save);
        this.Controls.Add(this.CB_LocationID);
        this.Name = "SMWE";
        this.Text = "Sun/Moon Wild Editor";
        this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SMWE_FormClosing);
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Min)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Max)).EndInit();
        this.GB_Encounters.ResumeLayout(false);
        this.GB_Encounters.PerformLayout();
        this.GB_Tweak.ResumeLayout(false);
        this.GB_Tweak.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_LevelAmp)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_NightIcon)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_DayIcon)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_WeatherForme1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_NightTable)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_DayTable)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme80)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme79)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme78)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme77)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme76)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme75)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme74)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme73)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme72)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme71)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme70)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme69)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme68)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme67)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme66)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme65)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme64)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme63)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme62)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme61)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme60)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme59)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme58)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme57)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme56)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme55)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme54)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme53)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme52)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme51)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme50)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme49)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme48)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme47)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme46)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme45)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme44)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme43)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme42)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme41)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme40)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme39)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme38)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme37)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme36)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme35)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme34)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme33)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme32)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme31)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme30)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme29)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme28)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme27)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme26)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme25)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme24)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme23)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme22)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme21)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme20)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme19)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme18)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme17)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme16)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme15)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme14)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme13)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme12)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme11)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate10)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme09)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate9)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme08)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme07)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme06)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme05)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme04)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme03)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme02)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Forme01)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUP_Rate1)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button B_Randomize;
    private System.Windows.Forms.Button B_Dump;
    private System.Windows.Forms.Label L_Location;
    private System.Windows.Forms.Button B_Save;
    private System.Windows.Forms.ComboBox CB_LocationID;
    private System.Windows.Forms.NumericUpDown NUP_Min;
    private System.Windows.Forms.NumericUpDown NUP_Max;
    private System.Windows.Forms.Label L_Min;
    private System.Windows.Forms.Label L_Max;
    private System.Windows.Forms.Label L_Table;
    private System.Windows.Forms.GroupBox GB_Encounters;
    private System.Windows.Forms.NumericUpDown NUP_Forme08;
    private System.Windows.Forms.ComboBox CB_Enc08;
    private System.Windows.Forms.NumericUpDown NUP_Rate8;
    private System.Windows.Forms.NumericUpDown NUP_Forme07;
    private System.Windows.Forms.ComboBox CB_Enc07;
    private System.Windows.Forms.NumericUpDown NUP_Rate7;
    private System.Windows.Forms.NumericUpDown NUP_Forme06;
    private System.Windows.Forms.ComboBox CB_Enc06;
    private System.Windows.Forms.NumericUpDown NUP_Rate6;
    private System.Windows.Forms.NumericUpDown NUP_Forme05;
    private System.Windows.Forms.ComboBox CB_Enc05;
    private System.Windows.Forms.NumericUpDown NUP_Rate5;
    private System.Windows.Forms.NumericUpDown NUP_Forme04;
    private System.Windows.Forms.ComboBox CB_Enc04;
    private System.Windows.Forms.NumericUpDown NUP_Rate4;
    private System.Windows.Forms.NumericUpDown NUP_Forme03;
    private System.Windows.Forms.ComboBox CB_Enc03;
    private System.Windows.Forms.NumericUpDown NUP_Rate3;
    private System.Windows.Forms.NumericUpDown NUP_Forme02;
    private System.Windows.Forms.ComboBox CB_Enc02;
    private System.Windows.Forms.NumericUpDown NUP_Rate2;
    private System.Windows.Forms.Label L_Rate;
    private System.Windows.Forms.NumericUpDown NUP_Forme01;
    private System.Windows.Forms.ComboBox CB_Enc01;
    private System.Windows.Forms.NumericUpDown NUP_Rate1;
    private System.Windows.Forms.NumericUpDown NUP_Forme10;
    private System.Windows.Forms.ComboBox CB_Enc10;
    private System.Windows.Forms.NumericUpDown NUP_Rate10;
    private System.Windows.Forms.NumericUpDown NUP_Forme09;
    private System.Windows.Forms.ComboBox CB_Enc09;
    private System.Windows.Forms.NumericUpDown NUP_Rate9;
    private System.Windows.Forms.ComboBox CB_TableID;
    private System.Windows.Forms.Button B_Export;
    private System.Windows.Forms.NumericUpDown NUP_Forme20;
    private System.Windows.Forms.ComboBox CB_Enc20;
    private System.Windows.Forms.NumericUpDown NUP_Forme19;
    private System.Windows.Forms.ComboBox CB_Enc19;
    private System.Windows.Forms.NumericUpDown NUP_Forme18;
    private System.Windows.Forms.ComboBox CB_Enc18;
    private System.Windows.Forms.NumericUpDown NUP_Forme17;
    private System.Windows.Forms.ComboBox CB_Enc17;
    private System.Windows.Forms.NumericUpDown NUP_Forme16;
    private System.Windows.Forms.ComboBox CB_Enc16;
    private System.Windows.Forms.NumericUpDown NUP_Forme15;
    private System.Windows.Forms.ComboBox CB_Enc15;
    private System.Windows.Forms.NumericUpDown NUP_Forme14;
    private System.Windows.Forms.ComboBox CB_Enc14;
    private System.Windows.Forms.NumericUpDown NUP_Forme13;
    private System.Windows.Forms.ComboBox CB_Enc13;
    private System.Windows.Forms.NumericUpDown NUP_Forme12;
    private System.Windows.Forms.ComboBox CB_Enc12;
    private System.Windows.Forms.NumericUpDown NUP_Forme11;
    private System.Windows.Forms.ComboBox CB_Enc11;
    private System.Windows.Forms.Label L_SOS1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.NumericUpDown NUP_Forme80;
    private System.Windows.Forms.ComboBox CB_Enc80;
    private System.Windows.Forms.NumericUpDown NUP_Forme79;
    private System.Windows.Forms.ComboBox CB_Enc79;
    private System.Windows.Forms.NumericUpDown NUP_Forme78;
    private System.Windows.Forms.ComboBox CB_Enc78;
    private System.Windows.Forms.NumericUpDown NUP_Forme77;
    private System.Windows.Forms.ComboBox CB_Enc77;
    private System.Windows.Forms.NumericUpDown NUP_Forme76;
    private System.Windows.Forms.ComboBox CB_Enc76;
    private System.Windows.Forms.NumericUpDown NUP_Forme75;
    private System.Windows.Forms.ComboBox CB_Enc75;
    private System.Windows.Forms.NumericUpDown NUP_Forme74;
    private System.Windows.Forms.ComboBox CB_Enc74;
    private System.Windows.Forms.NumericUpDown NUP_Forme73;
    private System.Windows.Forms.ComboBox CB_Enc73;
    private System.Windows.Forms.NumericUpDown NUP_Forme72;
    private System.Windows.Forms.ComboBox CB_Enc72;
    private System.Windows.Forms.NumericUpDown NUP_Forme71;
    private System.Windows.Forms.ComboBox CB_Enc71;
    private System.Windows.Forms.Label L_SOS7;
    private System.Windows.Forms.NumericUpDown NUP_Forme70;
    private System.Windows.Forms.ComboBox CB_Enc70;
    private System.Windows.Forms.NumericUpDown NUP_Forme69;
    private System.Windows.Forms.ComboBox CB_Enc69;
    private System.Windows.Forms.NumericUpDown NUP_Forme68;
    private System.Windows.Forms.ComboBox CB_Enc68;
    private System.Windows.Forms.NumericUpDown NUP_Forme67;
    private System.Windows.Forms.ComboBox CB_Enc67;
    private System.Windows.Forms.NumericUpDown NUP_Forme66;
    private System.Windows.Forms.ComboBox CB_Enc66;
    private System.Windows.Forms.NumericUpDown NUP_Forme65;
    private System.Windows.Forms.ComboBox CB_Enc65;
    private System.Windows.Forms.NumericUpDown NUP_Forme64;
    private System.Windows.Forms.ComboBox CB_Enc64;
    private System.Windows.Forms.NumericUpDown NUP_Forme63;
    private System.Windows.Forms.ComboBox CB_Enc63;
    private System.Windows.Forms.NumericUpDown NUP_Forme62;
    private System.Windows.Forms.ComboBox CB_Enc62;
    private System.Windows.Forms.NumericUpDown NUP_Forme61;
    private System.Windows.Forms.ComboBox CB_Enc61;
    private System.Windows.Forms.Label L_SOS6;
    private System.Windows.Forms.NumericUpDown NUP_Forme60;
    private System.Windows.Forms.ComboBox CB_Enc60;
    private System.Windows.Forms.NumericUpDown NUP_Forme59;
    private System.Windows.Forms.ComboBox CB_Enc59;
    private System.Windows.Forms.NumericUpDown NUP_Forme58;
    private System.Windows.Forms.ComboBox CB_Enc58;
    private System.Windows.Forms.NumericUpDown NUP_Forme57;
    private System.Windows.Forms.ComboBox CB_Enc57;
    private System.Windows.Forms.NumericUpDown NUP_Forme56;
    private System.Windows.Forms.ComboBox CB_Enc56;
    private System.Windows.Forms.NumericUpDown NUP_Forme55;
    private System.Windows.Forms.ComboBox CB_Enc55;
    private System.Windows.Forms.NumericUpDown NUP_Forme54;
    private System.Windows.Forms.ComboBox CB_Enc54;
    private System.Windows.Forms.NumericUpDown NUP_Forme53;
    private System.Windows.Forms.ComboBox CB_Enc53;
    private System.Windows.Forms.NumericUpDown NUP_Forme52;
    private System.Windows.Forms.ComboBox CB_Enc52;
    private System.Windows.Forms.NumericUpDown NUP_Forme51;
    private System.Windows.Forms.ComboBox CB_Enc51;
    private System.Windows.Forms.Label L_SOS5;
    private System.Windows.Forms.NumericUpDown NUP_Forme50;
    private System.Windows.Forms.ComboBox CB_Enc50;
    private System.Windows.Forms.NumericUpDown NUP_Forme49;
    private System.Windows.Forms.ComboBox CB_Enc49;
    private System.Windows.Forms.NumericUpDown NUP_Forme48;
    private System.Windows.Forms.ComboBox CB_Enc48;
    private System.Windows.Forms.NumericUpDown NUP_Forme47;
    private System.Windows.Forms.ComboBox CB_Enc47;
    private System.Windows.Forms.NumericUpDown NUP_Forme46;
    private System.Windows.Forms.ComboBox CB_Enc46;
    private System.Windows.Forms.NumericUpDown NUP_Forme45;
    private System.Windows.Forms.ComboBox CB_Enc45;
    private System.Windows.Forms.NumericUpDown NUP_Forme44;
    private System.Windows.Forms.ComboBox CB_Enc44;
    private System.Windows.Forms.NumericUpDown NUP_Forme43;
    private System.Windows.Forms.ComboBox CB_Enc43;
    private System.Windows.Forms.NumericUpDown NUP_Forme42;
    private System.Windows.Forms.ComboBox CB_Enc42;
    private System.Windows.Forms.NumericUpDown NUP_Forme41;
    private System.Windows.Forms.ComboBox CB_Enc41;
    private System.Windows.Forms.Label L_SOS4;
    private System.Windows.Forms.NumericUpDown NUP_Forme40;
    private System.Windows.Forms.ComboBox CB_Enc40;
    private System.Windows.Forms.NumericUpDown NUP_Forme39;
    private System.Windows.Forms.ComboBox CB_Enc39;
    private System.Windows.Forms.NumericUpDown NUP_Forme38;
    private System.Windows.Forms.ComboBox CB_Enc38;
    private System.Windows.Forms.NumericUpDown NUP_Forme37;
    private System.Windows.Forms.ComboBox CB_Enc37;
    private System.Windows.Forms.NumericUpDown NUP_Forme36;
    private System.Windows.Forms.ComboBox CB_Enc36;
    private System.Windows.Forms.NumericUpDown NUP_Forme35;
    private System.Windows.Forms.ComboBox CB_Enc35;
    private System.Windows.Forms.NumericUpDown NUP_Forme34;
    private System.Windows.Forms.ComboBox CB_Enc34;
    private System.Windows.Forms.NumericUpDown NUP_Forme33;
    private System.Windows.Forms.ComboBox CB_Enc33;
    private System.Windows.Forms.NumericUpDown NUP_Forme32;
    private System.Windows.Forms.ComboBox CB_Enc32;
    private System.Windows.Forms.NumericUpDown NUP_Forme31;
    private System.Windows.Forms.ComboBox CB_Enc31;
    private System.Windows.Forms.Label L_SOS3;
    private System.Windows.Forms.NumericUpDown NUP_Forme30;
    private System.Windows.Forms.ComboBox CB_Enc30;
    private System.Windows.Forms.NumericUpDown NUP_Forme29;
    private System.Windows.Forms.ComboBox CB_Enc29;
    private System.Windows.Forms.NumericUpDown NUP_Forme28;
    private System.Windows.Forms.ComboBox CB_Enc28;
    private System.Windows.Forms.NumericUpDown NUP_Forme27;
    private System.Windows.Forms.ComboBox CB_Enc27;
    private System.Windows.Forms.NumericUpDown NUP_Forme26;
    private System.Windows.Forms.ComboBox CB_Enc26;
    private System.Windows.Forms.NumericUpDown NUP_Forme25;
    private System.Windows.Forms.ComboBox CB_Enc25;
    private System.Windows.Forms.NumericUpDown NUP_Forme24;
    private System.Windows.Forms.ComboBox CB_Enc24;
    private System.Windows.Forms.NumericUpDown NUP_Forme23;
    private System.Windows.Forms.ComboBox CB_Enc23;
    private System.Windows.Forms.NumericUpDown NUP_Forme22;
    private System.Windows.Forms.ComboBox CB_Enc22;
    private System.Windows.Forms.NumericUpDown NUP_Forme21;
    private System.Windows.Forms.ComboBox CB_Enc21;
    private System.Windows.Forms.Label L_SOS2;
    private System.Windows.Forms.PictureBox PB_DayTable;
    private System.Windows.Forms.PictureBox PB_NightTable;
    private System.Windows.Forms.NumericUpDown NUP_WeatherForme6;
    private System.Windows.Forms.NumericUpDown NUP_WeatherForme3;
    private System.Windows.Forms.ComboBox CB_WeatherEnc6;
    private System.Windows.Forms.NumericUpDown NUP_WeatherForme5;
    private System.Windows.Forms.ComboBox CB_WeatherEnc5;
    private System.Windows.Forms.NumericUpDown NUP_WeatherForme4;
    private System.Windows.Forms.ComboBox CB_WeatherEnc4;
    private System.Windows.Forms.ComboBox CB_WeatherEnc3;
    private System.Windows.Forms.NumericUpDown NUP_WeatherForme2;
    private System.Windows.Forms.ComboBox CB_WeatherEnc2;
    private System.Windows.Forms.NumericUpDown NUP_WeatherForme1;
    private System.Windows.Forms.ComboBox CB_WeatherEnc1;
    private System.Windows.Forms.Label L_AddSOS;
    private System.Windows.Forms.PictureBox PB_NightIcon;
    private System.Windows.Forms.PictureBox PB_DayIcon;
    private System.Windows.Forms.GroupBox GB_Tweak;
    private System.Windows.Forms.CheckBox CHK_G7;
    private System.Windows.Forms.CheckBox CHK_MegaForm;
    private System.Windows.Forms.Label L_RandOpt;
    private System.Windows.Forms.CheckBox CHK_BST;
    private System.Windows.Forms.CheckBox CHK_E;
    private System.Windows.Forms.CheckBox CHK_L;
    private System.Windows.Forms.CheckBox CHK_G6;
    private System.Windows.Forms.CheckBox CHK_G5;
    private System.Windows.Forms.CheckBox CHK_G4;
    private System.Windows.Forms.CheckBox CHK_G3;
    private System.Windows.Forms.CheckBox CHK_G2;
    private System.Windows.Forms.CheckBox CHK_G1;
    private System.Windows.Forms.Button B_LevelPlus;
    private System.Windows.Forms.NumericUpDown NUD_LevelAmp;
    private System.Windows.Forms.CheckBox CHK_Level;
    private System.Windows.Forms.Button CopySOS;
    private System.Windows.Forms.Label L_SOS;
    private System.Windows.Forms.ComboBox CB_SlotRand;
    private System.Windows.Forms.Button B_PasteAll;
    private System.Windows.Forms.Button B_Paste;
    private System.Windows.Forms.Button B_Copy;
    private System.Windows.Forms.Label L_Sand;
    private System.Windows.Forms.Label L_Hail;
    private System.Windows.Forms.Label L_Rain;
    private System.Windows.Forms.Label L_Weather1;
    private System.Windows.Forms.Label L_Weather0;
}