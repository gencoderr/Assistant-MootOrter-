﻿namespace pk3DS.WinForms;

partial class EvolutionEditor7
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.CB_Species = new System.Windows.Forms.ComboBox();
        this.L_Species = new System.Windows.Forms.Label();
        this.B_Dump = new System.Windows.Forms.Button();
        this.CB_M1 = new System.Windows.Forms.ComboBox();
        this.L_M1 = new System.Windows.Forms.Label();
        this.CB_I1 = new System.Windows.Forms.ComboBox();
        this.CB_P1 = new System.Windows.Forms.ComboBox();
        this.PB_1 = new System.Windows.Forms.PictureBox();
        this.B_RandAll = new System.Windows.Forms.Button();
        this.GB_Randomizer = new System.Windows.Forms.GroupBox();
        this.L_Protip = new System.Windows.Forms.Label();
        this.CHK_BST = new System.Windows.Forms.CheckBox();
        this.CHK_Type = new System.Windows.Forms.CheckBox();
        this.CHK_Exp = new System.Windows.Forms.CheckBox();
        this.NUD_F1 = new System.Windows.Forms.NumericUpDown();
        this.NUD_L1 = new System.Windows.Forms.NumericUpDown();
        this.NUD_L2 = new System.Windows.Forms.NumericUpDown();
        this.NUD_F2 = new System.Windows.Forms.NumericUpDown();
        this.PB_2 = new System.Windows.Forms.PictureBox();
        this.CB_P2 = new System.Windows.Forms.ComboBox();
        this.CB_I2 = new System.Windows.Forms.ComboBox();
        this.label1 = new System.Windows.Forms.Label();
        this.CB_M2 = new System.Windows.Forms.ComboBox();
        this.NUD_L3 = new System.Windows.Forms.NumericUpDown();
        this.NUD_F3 = new System.Windows.Forms.NumericUpDown();
        this.PB_3 = new System.Windows.Forms.PictureBox();
        this.CB_P3 = new System.Windows.Forms.ComboBox();
        this.CB_I3 = new System.Windows.Forms.ComboBox();
        this.label2 = new System.Windows.Forms.Label();
        this.CB_M3 = new System.Windows.Forms.ComboBox();
        this.NUD_L4 = new System.Windows.Forms.NumericUpDown();
        this.NUD_F4 = new System.Windows.Forms.NumericUpDown();
        this.PB_4 = new System.Windows.Forms.PictureBox();
        this.CB_P4 = new System.Windows.Forms.ComboBox();
        this.CB_I4 = new System.Windows.Forms.ComboBox();
        this.label3 = new System.Windows.Forms.Label();
        this.CB_M4 = new System.Windows.Forms.ComboBox();
        this.NUD_L5 = new System.Windows.Forms.NumericUpDown();
        this.NUD_F5 = new System.Windows.Forms.NumericUpDown();
        this.PB_5 = new System.Windows.Forms.PictureBox();
        this.CB_P5 = new System.Windows.Forms.ComboBox();
        this.CB_I5 = new System.Windows.Forms.ComboBox();
        this.label4 = new System.Windows.Forms.Label();
        this.CB_M5 = new System.Windows.Forms.ComboBox();
        this.NUD_L6 = new System.Windows.Forms.NumericUpDown();
        this.NUD_F6 = new System.Windows.Forms.NumericUpDown();
        this.PB_6 = new System.Windows.Forms.PictureBox();
        this.CB_P6 = new System.Windows.Forms.ComboBox();
        this.CB_I6 = new System.Windows.Forms.ComboBox();
        this.label5 = new System.Windows.Forms.Label();
        this.CB_M6 = new System.Windows.Forms.ComboBox();
        this.NUD_L7 = new System.Windows.Forms.NumericUpDown();
        this.NUD_F7 = new System.Windows.Forms.NumericUpDown();
        this.PB_7 = new System.Windows.Forms.PictureBox();
        this.CB_P7 = new System.Windows.Forms.ComboBox();
        this.CB_I7 = new System.Windows.Forms.ComboBox();
        this.label6 = new System.Windows.Forms.Label();
        this.CB_M7 = new System.Windows.Forms.ComboBox();
        this.NUD_L8 = new System.Windows.Forms.NumericUpDown();
        this.NUD_F8 = new System.Windows.Forms.NumericUpDown();
        this.PB_8 = new System.Windows.Forms.PictureBox();
        this.CB_P8 = new System.Windows.Forms.ComboBox();
        this.CB_I8 = new System.Windows.Forms.ComboBox();
        this.label7 = new System.Windows.Forms.Label();
        this.CB_M8 = new System.Windows.Forms.ComboBox();
        this.B_Trade = new System.Windows.Forms.Button();
        this.B_EveryLevel = new System.Windows.Forms.Button();
        this.CHK_E = new System.Windows.Forms.CheckBox();
        this.CHK_L = new System.Windows.Forms.CheckBox();
        ((System.ComponentModel.ISupportInitialize)(this.PB_1)).BeginInit();
        this.GB_Randomizer.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L1)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_2)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_3)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_4)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_5)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_6)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_7)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F8)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_8)).BeginInit();
        this.SuspendLayout();
        // 
        // CB_Species
        // 
        this.CB_Species.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_Species.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_Species.FormattingEnabled = true;
        this.CB_Species.Location = new System.Drawing.Point(66, 12);
        this.CB_Species.Name = "CB_Species";
        this.CB_Species.Size = new System.Drawing.Size(121, 21);
        this.CB_Species.TabIndex = 1;
        this.CB_Species.SelectedIndexChanged += new System.EventHandler(this.ChangeEntry);
        // 
        // L_Species
        // 
        this.L_Species.AutoSize = true;
        this.L_Species.Location = new System.Drawing.Point(12, 15);
        this.L_Species.Name = "L_Species";
        this.L_Species.Size = new System.Drawing.Size(48, 13);
        this.L_Species.TabIndex = 2;
        this.L_Species.Text = "Species:";
        // 
        // B_Dump
        // 
        this.B_Dump.Location = new System.Drawing.Point(193, 11);
        this.B_Dump.Name = "B_Dump";
        this.B_Dump.Size = new System.Drawing.Size(59, 23);
        this.B_Dump.TabIndex = 5;
        this.B_Dump.Text = "Dump";
        this.B_Dump.UseVisualStyleBackColor = true;
        this.B_Dump.Click += new System.EventHandler(this.B_Dump_Click);
        // 
        // CB_M1
        // 
        this.CB_M1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M1.DropDownWidth = 200;
        this.CB_M1.FormattingEnabled = true;
        this.CB_M1.Location = new System.Drawing.Point(125, 46);
        this.CB_M1.MaxDropDownItems = 10;
        this.CB_M1.Name = "CB_M1";
        this.CB_M1.Size = new System.Drawing.Size(150, 21);
        this.CB_M1.TabIndex = 6;
        this.CB_M1.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // L_M1
        // 
        this.L_M1.Location = new System.Drawing.Point(13, 45);
        this.L_M1.Name = "L_M1";
        this.L_M1.Size = new System.Drawing.Size(60, 20);
        this.L_M1.TabIndex = 7;
        this.L_M1.Text = "Method 1:";
        this.L_M1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_I1
        // 
        this.CB_I1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I1.FormattingEnabled = true;
        this.CB_I1.Location = new System.Drawing.Point(281, 46);
        this.CB_I1.Name = "CB_I1";
        this.CB_I1.Size = new System.Drawing.Size(101, 21);
        this.CB_I1.TabIndex = 9;
        this.CB_I1.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // CB_P1
        // 
        this.CB_P1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P1.FormattingEnabled = true;
        this.CB_P1.Location = new System.Drawing.Point(388, 46);
        this.CB_P1.Name = "CB_P1";
        this.CB_P1.Size = new System.Drawing.Size(121, 21);
        this.CB_P1.TabIndex = 10;
        // 
        // PB_1
        // 
        this.PB_1.Location = new System.Drawing.Point(79, 39);
        this.PB_1.Name = "PB_1";
        this.PB_1.Size = new System.Drawing.Size(40, 30);
        this.PB_1.TabIndex = 54;
        this.PB_1.TabStop = false;
        // 
        // B_RandAll
        // 
        this.B_RandAll.Location = new System.Drawing.Point(511, 324);
        this.B_RandAll.Name = "B_RandAll";
        this.B_RandAll.Size = new System.Drawing.Size(100, 23);
        this.B_RandAll.TabIndex = 62;
        this.B_RandAll.Text = "Randomize All";
        this.B_RandAll.UseVisualStyleBackColor = true;
        this.B_RandAll.Click += new System.EventHandler(this.B_RandAll_Click);
        // 
        // GB_Randomizer
        // 
        this.GB_Randomizer.Controls.Add(this.CHK_E);
        this.GB_Randomizer.Controls.Add(this.CHK_L);
        this.GB_Randomizer.Controls.Add(this.L_Protip);
        this.GB_Randomizer.Controls.Add(this.CHK_BST);
        this.GB_Randomizer.Controls.Add(this.CHK_Type);
        this.GB_Randomizer.Controls.Add(this.CHK_Exp);
        this.GB_Randomizer.Location = new System.Drawing.Point(16, 292);
        this.GB_Randomizer.Name = "GB_Randomizer";
        this.GB_Randomizer.Size = new System.Drawing.Size(357, 104);
        this.GB_Randomizer.TabIndex = 63;
        this.GB_Randomizer.TabStop = false;
        this.GB_Randomizer.Text = "Randomizer Options";
        // 
        // L_Protip
        // 
        this.L_Protip.AutoSize = true;
        this.L_Protip.ForeColor = System.Drawing.Color.Red;
        this.L_Protip.Location = new System.Drawing.Point(198, 9);
        this.L_Protip.Name = "L_Protip";
        this.L_Protip.Size = new System.Drawing.Size(153, 13);
        this.L_Protip.TabIndex = 66;
        this.L_Protip.Text = "(Protip: Difficulty++ in Personal)";
        // 
        // CHK_BST
        // 
        this.CHK_BST.AutoSize = true;
        this.CHK_BST.Checked = true;
        this.CHK_BST.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_BST.Location = new System.Drawing.Point(6, 53);
        this.CHK_BST.Name = "CHK_BST";
        this.CHK_BST.Size = new System.Drawing.Size(179, 17);
        this.CHK_BST.TabIndex = 65;
        this.CHK_BST.Text = "Share a similar BST as Evolution";
        this.CHK_BST.UseVisualStyleBackColor = true;
        // 
        // CHK_Type
        // 
        this.CHK_Type.AutoSize = true;
        this.CHK_Type.Checked = true;
        this.CHK_Type.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_Type.Location = new System.Drawing.Point(6, 38);
        this.CHK_Type.Name = "CHK_Type";
        this.CHK_Type.Size = new System.Drawing.Size(200, 17);
        this.CHK_Type.TabIndex = 64;
        this.CHK_Type.Text = "Share at least one Type as Evolution";
        this.CHK_Type.UseVisualStyleBackColor = true;
        // 
        // CHK_Exp
        // 
        this.CHK_Exp.AutoSize = true;
        this.CHK_Exp.Checked = true;
        this.CHK_Exp.CheckState = System.Windows.Forms.CheckState.Checked;
        this.CHK_Exp.Location = new System.Drawing.Point(6, 23);
        this.CHK_Exp.Name = "CHK_Exp";
        this.CHK_Exp.Size = new System.Drawing.Size(222, 17);
        this.CHK_Exp.TabIndex = 63;
        this.CHK_Exp.Text = "Share the same EXP Growth as Evolution";
        this.CHK_Exp.UseVisualStyleBackColor = true;
        // 
        // NUD_F1
        // 
        this.NUD_F1.Location = new System.Drawing.Point(515, 47);
        this.NUD_F1.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F1.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F1.Name = "NUD_F1";
        this.NUD_F1.Size = new System.Drawing.Size(45, 20);
        this.NUD_F1.TabIndex = 64;
        this.NUD_F1.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // NUD_L1
        // 
        this.NUD_L1.Location = new System.Drawing.Point(566, 47);
        this.NUD_L1.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L1.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L1.Name = "NUD_L1";
        this.NUD_L1.Size = new System.Drawing.Size(45, 20);
        this.NUD_L1.TabIndex = 65;
        // 
        // NUD_L2
        // 
        this.NUD_L2.Location = new System.Drawing.Point(566, 78);
        this.NUD_L2.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L2.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L2.Name = "NUD_L2";
        this.NUD_L2.Size = new System.Drawing.Size(45, 20);
        this.NUD_L2.TabIndex = 72;
        // 
        // NUD_F2
        // 
        this.NUD_F2.Location = new System.Drawing.Point(515, 78);
        this.NUD_F2.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F2.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F2.Name = "NUD_F2";
        this.NUD_F2.Size = new System.Drawing.Size(45, 20);
        this.NUD_F2.TabIndex = 71;
        this.NUD_F2.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // PB_2
        // 
        this.PB_2.Location = new System.Drawing.Point(79, 70);
        this.PB_2.Name = "PB_2";
        this.PB_2.Size = new System.Drawing.Size(40, 30);
        this.PB_2.TabIndex = 70;
        this.PB_2.TabStop = false;
        // 
        // CB_P2
        // 
        this.CB_P2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P2.FormattingEnabled = true;
        this.CB_P2.Location = new System.Drawing.Point(388, 77);
        this.CB_P2.Name = "CB_P2";
        this.CB_P2.Size = new System.Drawing.Size(121, 21);
        this.CB_P2.TabIndex = 69;
        // 
        // CB_I2
        // 
        this.CB_I2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I2.FormattingEnabled = true;
        this.CB_I2.Location = new System.Drawing.Point(281, 77);
        this.CB_I2.Name = "CB_I2";
        this.CB_I2.Size = new System.Drawing.Size(101, 21);
        this.CB_I2.TabIndex = 68;
        this.CB_I2.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // label1
        // 
        this.label1.Location = new System.Drawing.Point(13, 76);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(60, 20);
        this.label1.TabIndex = 67;
        this.label1.Text = "Method 2:";
        this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_M2
        // 
        this.CB_M2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M2.DropDownWidth = 200;
        this.CB_M2.FormattingEnabled = true;
        this.CB_M2.Location = new System.Drawing.Point(125, 77);
        this.CB_M2.MaxDropDownItems = 10;
        this.CB_M2.Name = "CB_M2";
        this.CB_M2.Size = new System.Drawing.Size(150, 21);
        this.CB_M2.TabIndex = 66;
        this.CB_M2.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // NUD_L3
        // 
        this.NUD_L3.Location = new System.Drawing.Point(566, 109);
        this.NUD_L3.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L3.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L3.Name = "NUD_L3";
        this.NUD_L3.Size = new System.Drawing.Size(45, 20);
        this.NUD_L3.TabIndex = 79;
        // 
        // NUD_F3
        // 
        this.NUD_F3.Location = new System.Drawing.Point(515, 109);
        this.NUD_F3.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F3.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F3.Name = "NUD_F3";
        this.NUD_F3.Size = new System.Drawing.Size(45, 20);
        this.NUD_F3.TabIndex = 78;
        this.NUD_F3.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // PB_3
        // 
        this.PB_3.Location = new System.Drawing.Point(79, 101);
        this.PB_3.Name = "PB_3";
        this.PB_3.Size = new System.Drawing.Size(40, 30);
        this.PB_3.TabIndex = 77;
        this.PB_3.TabStop = false;
        // 
        // CB_P3
        // 
        this.CB_P3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P3.FormattingEnabled = true;
        this.CB_P3.Location = new System.Drawing.Point(388, 108);
        this.CB_P3.Name = "CB_P3";
        this.CB_P3.Size = new System.Drawing.Size(121, 21);
        this.CB_P3.TabIndex = 76;
        // 
        // CB_I3
        // 
        this.CB_I3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I3.FormattingEnabled = true;
        this.CB_I3.Location = new System.Drawing.Point(281, 108);
        this.CB_I3.Name = "CB_I3";
        this.CB_I3.Size = new System.Drawing.Size(101, 21);
        this.CB_I3.TabIndex = 75;
        this.CB_I3.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // label2
        // 
        this.label2.Location = new System.Drawing.Point(13, 107);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(60, 20);
        this.label2.TabIndex = 74;
        this.label2.Text = "Method 3:";
        this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_M3
        // 
        this.CB_M3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M3.DropDownWidth = 200;
        this.CB_M3.FormattingEnabled = true;
        this.CB_M3.Location = new System.Drawing.Point(125, 108);
        this.CB_M3.MaxDropDownItems = 10;
        this.CB_M3.Name = "CB_M3";
        this.CB_M3.Size = new System.Drawing.Size(150, 21);
        this.CB_M3.TabIndex = 73;
        this.CB_M3.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // NUD_L4
        // 
        this.NUD_L4.Location = new System.Drawing.Point(566, 140);
        this.NUD_L4.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L4.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L4.Name = "NUD_L4";
        this.NUD_L4.Size = new System.Drawing.Size(45, 20);
        this.NUD_L4.TabIndex = 86;
        // 
        // NUD_F4
        // 
        this.NUD_F4.Location = new System.Drawing.Point(515, 140);
        this.NUD_F4.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F4.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F4.Name = "NUD_F4";
        this.NUD_F4.Size = new System.Drawing.Size(45, 20);
        this.NUD_F4.TabIndex = 85;
        this.NUD_F4.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // PB_4
        // 
        this.PB_4.Location = new System.Drawing.Point(79, 132);
        this.PB_4.Name = "PB_4";
        this.PB_4.Size = new System.Drawing.Size(40, 30);
        this.PB_4.TabIndex = 84;
        this.PB_4.TabStop = false;
        // 
        // CB_P4
        // 
        this.CB_P4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P4.FormattingEnabled = true;
        this.CB_P4.Location = new System.Drawing.Point(388, 139);
        this.CB_P4.Name = "CB_P4";
        this.CB_P4.Size = new System.Drawing.Size(121, 21);
        this.CB_P4.TabIndex = 83;
        // 
        // CB_I4
        // 
        this.CB_I4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I4.FormattingEnabled = true;
        this.CB_I4.Location = new System.Drawing.Point(281, 139);
        this.CB_I4.Name = "CB_I4";
        this.CB_I4.Size = new System.Drawing.Size(101, 21);
        this.CB_I4.TabIndex = 82;
        this.CB_I4.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // label3
        // 
        this.label3.Location = new System.Drawing.Point(13, 138);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(60, 20);
        this.label3.TabIndex = 81;
        this.label3.Text = "Method 4:";
        this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_M4
        // 
        this.CB_M4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M4.DropDownWidth = 200;
        this.CB_M4.FormattingEnabled = true;
        this.CB_M4.Location = new System.Drawing.Point(125, 139);
        this.CB_M4.MaxDropDownItems = 10;
        this.CB_M4.Name = "CB_M4";
        this.CB_M4.Size = new System.Drawing.Size(150, 21);
        this.CB_M4.TabIndex = 80;
        this.CB_M4.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // NUD_L5
        // 
        this.NUD_L5.Location = new System.Drawing.Point(566, 171);
        this.NUD_L5.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L5.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L5.Name = "NUD_L5";
        this.NUD_L5.Size = new System.Drawing.Size(45, 20);
        this.NUD_L5.TabIndex = 93;
        // 
        // NUD_F5
        // 
        this.NUD_F5.Location = new System.Drawing.Point(515, 171);
        this.NUD_F5.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F5.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F5.Name = "NUD_F5";
        this.NUD_F5.Size = new System.Drawing.Size(45, 20);
        this.NUD_F5.TabIndex = 92;
        this.NUD_F5.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // PB_5
        // 
        this.PB_5.Location = new System.Drawing.Point(79, 163);
        this.PB_5.Name = "PB_5";
        this.PB_5.Size = new System.Drawing.Size(40, 30);
        this.PB_5.TabIndex = 91;
        this.PB_5.TabStop = false;
        // 
        // CB_P5
        // 
        this.CB_P5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P5.FormattingEnabled = true;
        this.CB_P5.Location = new System.Drawing.Point(388, 170);
        this.CB_P5.Name = "CB_P5";
        this.CB_P5.Size = new System.Drawing.Size(121, 21);
        this.CB_P5.TabIndex = 90;
        // 
        // CB_I5
        // 
        this.CB_I5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I5.FormattingEnabled = true;
        this.CB_I5.Location = new System.Drawing.Point(281, 170);
        this.CB_I5.Name = "CB_I5";
        this.CB_I5.Size = new System.Drawing.Size(101, 21);
        this.CB_I5.TabIndex = 89;
        this.CB_I5.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // label4
        // 
        this.label4.Location = new System.Drawing.Point(13, 169);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(60, 20);
        this.label4.TabIndex = 88;
        this.label4.Text = "Method 5:";
        this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_M5
        // 
        this.CB_M5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M5.DropDownWidth = 200;
        this.CB_M5.FormattingEnabled = true;
        this.CB_M5.Location = new System.Drawing.Point(125, 170);
        this.CB_M5.MaxDropDownItems = 10;
        this.CB_M5.Name = "CB_M5";
        this.CB_M5.Size = new System.Drawing.Size(150, 21);
        this.CB_M5.TabIndex = 87;
        this.CB_M5.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // NUD_L6
        // 
        this.NUD_L6.Location = new System.Drawing.Point(566, 202);
        this.NUD_L6.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L6.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L6.Name = "NUD_L6";
        this.NUD_L6.Size = new System.Drawing.Size(45, 20);
        this.NUD_L6.TabIndex = 100;
        // 
        // NUD_F6
        // 
        this.NUD_F6.Location = new System.Drawing.Point(515, 202);
        this.NUD_F6.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F6.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F6.Name = "NUD_F6";
        this.NUD_F6.Size = new System.Drawing.Size(45, 20);
        this.NUD_F6.TabIndex = 99;
        this.NUD_F6.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // PB_6
        // 
        this.PB_6.Location = new System.Drawing.Point(79, 194);
        this.PB_6.Name = "PB_6";
        this.PB_6.Size = new System.Drawing.Size(40, 30);
        this.PB_6.TabIndex = 98;
        this.PB_6.TabStop = false;
        // 
        // CB_P6
        // 
        this.CB_P6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P6.FormattingEnabled = true;
        this.CB_P6.Location = new System.Drawing.Point(388, 201);
        this.CB_P6.Name = "CB_P6";
        this.CB_P6.Size = new System.Drawing.Size(121, 21);
        this.CB_P6.TabIndex = 97;
        // 
        // CB_I6
        // 
        this.CB_I6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I6.FormattingEnabled = true;
        this.CB_I6.Location = new System.Drawing.Point(281, 201);
        this.CB_I6.Name = "CB_I6";
        this.CB_I6.Size = new System.Drawing.Size(101, 21);
        this.CB_I6.TabIndex = 96;
        this.CB_I6.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // label5
        // 
        this.label5.Location = new System.Drawing.Point(13, 200);
        this.label5.Name = "label5";
        this.label5.Size = new System.Drawing.Size(60, 20);
        this.label5.TabIndex = 95;
        this.label5.Text = "Method 6:";
        this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_M6
        // 
        this.CB_M6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M6.DropDownWidth = 200;
        this.CB_M6.FormattingEnabled = true;
        this.CB_M6.Location = new System.Drawing.Point(125, 201);
        this.CB_M6.MaxDropDownItems = 10;
        this.CB_M6.Name = "CB_M6";
        this.CB_M6.Size = new System.Drawing.Size(150, 21);
        this.CB_M6.TabIndex = 94;
        this.CB_M6.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // NUD_L7
        // 
        this.NUD_L7.Location = new System.Drawing.Point(566, 233);
        this.NUD_L7.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L7.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L7.Name = "NUD_L7";
        this.NUD_L7.Size = new System.Drawing.Size(45, 20);
        this.NUD_L7.TabIndex = 107;
        // 
        // NUD_F7
        // 
        this.NUD_F7.Location = new System.Drawing.Point(515, 233);
        this.NUD_F7.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F7.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F7.Name = "NUD_F7";
        this.NUD_F7.Size = new System.Drawing.Size(45, 20);
        this.NUD_F7.TabIndex = 106;
        this.NUD_F7.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // PB_7
        // 
        this.PB_7.Location = new System.Drawing.Point(79, 225);
        this.PB_7.Name = "PB_7";
        this.PB_7.Size = new System.Drawing.Size(40, 30);
        this.PB_7.TabIndex = 105;
        this.PB_7.TabStop = false;
        // 
        // CB_P7
        // 
        this.CB_P7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P7.FormattingEnabled = true;
        this.CB_P7.Location = new System.Drawing.Point(388, 232);
        this.CB_P7.Name = "CB_P7";
        this.CB_P7.Size = new System.Drawing.Size(121, 21);
        this.CB_P7.TabIndex = 104;
        // 
        // CB_I7
        // 
        this.CB_I7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I7.FormattingEnabled = true;
        this.CB_I7.Location = new System.Drawing.Point(281, 232);
        this.CB_I7.Name = "CB_I7";
        this.CB_I7.Size = new System.Drawing.Size(101, 21);
        this.CB_I7.TabIndex = 103;
        this.CB_I7.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // label6
        // 
        this.label6.Location = new System.Drawing.Point(13, 231);
        this.label6.Name = "label6";
        this.label6.Size = new System.Drawing.Size(60, 20);
        this.label6.TabIndex = 102;
        this.label6.Text = "Method 7:";
        this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_M7
        // 
        this.CB_M7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M7.DropDownWidth = 200;
        this.CB_M7.FormattingEnabled = true;
        this.CB_M7.Location = new System.Drawing.Point(125, 232);
        this.CB_M7.MaxDropDownItems = 10;
        this.CB_M7.Name = "CB_M7";
        this.CB_M7.Size = new System.Drawing.Size(150, 21);
        this.CB_M7.TabIndex = 101;
        this.CB_M7.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // NUD_L8
        // 
        this.NUD_L8.Location = new System.Drawing.Point(566, 264);
        this.NUD_L8.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_L8.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_L8.Name = "NUD_L8";
        this.NUD_L8.Size = new System.Drawing.Size(45, 20);
        this.NUD_L8.TabIndex = 114;
        // 
        // NUD_F8
        // 
        this.NUD_F8.Location = new System.Drawing.Point(515, 264);
        this.NUD_F8.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
        this.NUD_F8.Minimum = new decimal(new int[] {
            127,
            0,
            0,
            -2147483648});
        this.NUD_F8.Name = "NUD_F8";
        this.NUD_F8.Size = new System.Drawing.Size(45, 20);
        this.NUD_F8.TabIndex = 113;
        this.NUD_F8.ValueChanged += new System.EventHandler(this.ChangeInto);
        // 
        // PB_8
        // 
        this.PB_8.Location = new System.Drawing.Point(79, 256);
        this.PB_8.Name = "PB_8";
        this.PB_8.Size = new System.Drawing.Size(40, 30);
        this.PB_8.TabIndex = 112;
        this.PB_8.TabStop = false;
        // 
        // CB_P8
        // 
        this.CB_P8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_P8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_P8.FormattingEnabled = true;
        this.CB_P8.Location = new System.Drawing.Point(388, 263);
        this.CB_P8.Name = "CB_P8";
        this.CB_P8.Size = new System.Drawing.Size(121, 21);
        this.CB_P8.TabIndex = 111;
        // 
        // CB_I8
        // 
        this.CB_I8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
        this.CB_I8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
        this.CB_I8.FormattingEnabled = true;
        this.CB_I8.Location = new System.Drawing.Point(281, 263);
        this.CB_I8.Name = "CB_I8";
        this.CB_I8.Size = new System.Drawing.Size(101, 21);
        this.CB_I8.TabIndex = 110;
        this.CB_I8.SelectedIndexChanged += new System.EventHandler(this.ChangeInto);
        // 
        // label7
        // 
        this.label7.Location = new System.Drawing.Point(13, 262);
        this.label7.Name = "label7";
        this.label7.Size = new System.Drawing.Size(60, 20);
        this.label7.TabIndex = 109;
        this.label7.Text = "Method 8:";
        this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // CB_M8
        // 
        this.CB_M8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.CB_M8.DropDownWidth = 200;
        this.CB_M8.FormattingEnabled = true;
        this.CB_M8.Location = new System.Drawing.Point(125, 263);
        this.CB_M8.MaxDropDownItems = 10;
        this.CB_M8.Name = "CB_M8";
        this.CB_M8.Size = new System.Drawing.Size(150, 21);
        this.CB_M8.TabIndex = 108;
        this.CB_M8.SelectedIndexChanged += new System.EventHandler(this.ChangeMethod);
        // 
        // B_Trade
        // 
        this.B_Trade.Location = new System.Drawing.Point(468, 347);
        this.B_Trade.Name = "B_Trade";
        this.B_Trade.Size = new System.Drawing.Size(143, 23);
        this.B_Trade.TabIndex = 115;
        this.B_Trade.Text = "Remove Trade Evolutions";
        this.B_Trade.UseVisualStyleBackColor = true;
        this.B_Trade.Click += new System.EventHandler(this.B_Trade_Click);
        // 
        // B_EveryLevel
        // 
        this.B_EveryLevel.Location = new System.Drawing.Point(446, 370);
        this.B_EveryLevel.Name = "B_EveryLevel";
        this.B_EveryLevel.Size = new System.Drawing.Size(165, 23);
        this.B_EveryLevel.TabIndex = 118;
        this.B_EveryLevel.Text = "Random Evolution Every Level";
        this.B_EveryLevel.UseVisualStyleBackColor = true;
        this.B_EveryLevel.Click += new System.EventHandler(this.B_EveryLevel_Click);
        // 
        // CHK_E
        // 
        this.CHK_E.AutoSize = true;
        this.CHK_E.Location = new System.Drawing.Point(6, 83);
        this.CHK_E.Name = "CHK_E";
        this.CHK_E.Size = new System.Drawing.Size(98, 17);
        this.CHK_E.TabIndex = 480;
        this.CHK_E.Text = "Event Legends";
        this.CHK_E.UseVisualStyleBackColor = true;
        // 
        // CHK_L
        // 
        this.CHK_L.AutoSize = true;
        this.CHK_L.Location = new System.Drawing.Point(6, 68);
        this.CHK_L.Name = "CHK_L";
        this.CHK_L.Size = new System.Drawing.Size(98, 17);
        this.CHK_L.TabIndex = 479;
        this.CHK_L.Text = "Game Legends";
        this.CHK_L.UseVisualStyleBackColor = true;
        // 
        // EvolutionEditor7
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(624, 406);
        this.Controls.Add(this.B_EveryLevel);
        this.Controls.Add(this.B_Trade);
        this.Controls.Add(this.NUD_L8);
        this.Controls.Add(this.NUD_F8);
        this.Controls.Add(this.PB_8);
        this.Controls.Add(this.CB_P8);
        this.Controls.Add(this.B_RandAll);
        this.Controls.Add(this.CB_I8);
        this.Controls.Add(this.label7);
        this.Controls.Add(this.CB_M8);
        this.Controls.Add(this.NUD_L7);
        this.Controls.Add(this.NUD_F7);
        this.Controls.Add(this.PB_7);
        this.Controls.Add(this.CB_P7);
        this.Controls.Add(this.CB_I7);
        this.Controls.Add(this.label6);
        this.Controls.Add(this.CB_M7);
        this.Controls.Add(this.NUD_L6);
        this.Controls.Add(this.NUD_F6);
        this.Controls.Add(this.PB_6);
        this.Controls.Add(this.CB_P6);
        this.Controls.Add(this.CB_I6);
        this.Controls.Add(this.label5);
        this.Controls.Add(this.CB_M6);
        this.Controls.Add(this.NUD_L5);
        this.Controls.Add(this.NUD_F5);
        this.Controls.Add(this.PB_5);
        this.Controls.Add(this.CB_P5);
        this.Controls.Add(this.CB_I5);
        this.Controls.Add(this.label4);
        this.Controls.Add(this.CB_M5);
        this.Controls.Add(this.NUD_L4);
        this.Controls.Add(this.NUD_F4);
        this.Controls.Add(this.PB_4);
        this.Controls.Add(this.CB_P4);
        this.Controls.Add(this.CB_I4);
        this.Controls.Add(this.label3);
        this.Controls.Add(this.CB_M4);
        this.Controls.Add(this.NUD_L3);
        this.Controls.Add(this.NUD_F3);
        this.Controls.Add(this.PB_3);
        this.Controls.Add(this.CB_P3);
        this.Controls.Add(this.CB_I3);
        this.Controls.Add(this.label2);
        this.Controls.Add(this.CB_M3);
        this.Controls.Add(this.NUD_L2);
        this.Controls.Add(this.NUD_F2);
        this.Controls.Add(this.PB_2);
        this.Controls.Add(this.CB_P2);
        this.Controls.Add(this.CB_I2);
        this.Controls.Add(this.label1);
        this.Controls.Add(this.CB_M2);
        this.Controls.Add(this.NUD_L1);
        this.Controls.Add(this.NUD_F1);
        this.Controls.Add(this.GB_Randomizer);
        this.Controls.Add(this.PB_1);
        this.Controls.Add(this.CB_P1);
        this.Controls.Add(this.CB_I1);
        this.Controls.Add(this.L_M1);
        this.Controls.Add(this.CB_M1);
        this.Controls.Add(this.B_Dump);
        this.Controls.Add(this.L_Species);
        this.Controls.Add(this.CB_Species);
        this.MaximizeBox = false;
        this.MaximumSize = new System.Drawing.Size(640, 445);
        this.MinimumSize = new System.Drawing.Size(640, 445);
        this.Name = "EvolutionEditor7";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
        this.Text = "Evolution Editor";
        this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Closing);
        ((System.ComponentModel.ISupportInitialize)(this.PB_1)).EndInit();
        this.GB_Randomizer.ResumeLayout(false);
        this.GB_Randomizer.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L1)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_2)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_3)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_4)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_5)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_6)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_7)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_L8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.NUD_F8)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.PB_8)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.ComboBox CB_Species;
    private System.Windows.Forms.Label L_Species;
    private System.Windows.Forms.Button B_Dump;
    private System.Windows.Forms.ComboBox CB_M1;
    private System.Windows.Forms.Label L_M1;
    private System.Windows.Forms.ComboBox CB_I1;
    private System.Windows.Forms.ComboBox CB_P1;
    private System.Windows.Forms.PictureBox PB_1;
    private System.Windows.Forms.Button B_RandAll;
    private System.Windows.Forms.GroupBox GB_Randomizer;
    private System.Windows.Forms.CheckBox CHK_Exp;
    private System.Windows.Forms.CheckBox CHK_Type;
    private System.Windows.Forms.CheckBox CHK_BST;
    private System.Windows.Forms.Label L_Protip;
    private System.Windows.Forms.NumericUpDown NUD_F1;
    private System.Windows.Forms.NumericUpDown NUD_L1;
    private System.Windows.Forms.NumericUpDown NUD_L2;
    private System.Windows.Forms.NumericUpDown NUD_F2;
    private System.Windows.Forms.PictureBox PB_2;
    private System.Windows.Forms.ComboBox CB_P2;
    private System.Windows.Forms.ComboBox CB_I2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox CB_M2;
    private System.Windows.Forms.NumericUpDown NUD_L3;
    private System.Windows.Forms.NumericUpDown NUD_F3;
    private System.Windows.Forms.PictureBox PB_3;
    private System.Windows.Forms.ComboBox CB_P3;
    private System.Windows.Forms.ComboBox CB_I3;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.ComboBox CB_M3;
    private System.Windows.Forms.NumericUpDown NUD_L4;
    private System.Windows.Forms.NumericUpDown NUD_F4;
    private System.Windows.Forms.PictureBox PB_4;
    private System.Windows.Forms.ComboBox CB_P4;
    private System.Windows.Forms.ComboBox CB_I4;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.ComboBox CB_M4;
    private System.Windows.Forms.NumericUpDown NUD_L5;
    private System.Windows.Forms.NumericUpDown NUD_F5;
    private System.Windows.Forms.PictureBox PB_5;
    private System.Windows.Forms.ComboBox CB_P5;
    private System.Windows.Forms.ComboBox CB_I5;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.ComboBox CB_M5;
    private System.Windows.Forms.NumericUpDown NUD_L6;
    private System.Windows.Forms.NumericUpDown NUD_F6;
    private System.Windows.Forms.PictureBox PB_6;
    private System.Windows.Forms.ComboBox CB_P6;
    private System.Windows.Forms.ComboBox CB_I6;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.ComboBox CB_M6;
    private System.Windows.Forms.NumericUpDown NUD_L7;
    private System.Windows.Forms.NumericUpDown NUD_F7;
    private System.Windows.Forms.PictureBox PB_7;
    private System.Windows.Forms.ComboBox CB_P7;
    private System.Windows.Forms.ComboBox CB_I7;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.ComboBox CB_M7;
    private System.Windows.Forms.NumericUpDown NUD_L8;
    private System.Windows.Forms.NumericUpDown NUD_F8;
    private System.Windows.Forms.PictureBox PB_8;
    private System.Windows.Forms.ComboBox CB_P8;
    private System.Windows.Forms.ComboBox CB_I8;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.ComboBox CB_M8;
    private System.Windows.Forms.Button B_Trade;
    private System.Windows.Forms.Button B_EveryLevel;
    private System.Windows.Forms.CheckBox CHK_E;
    private System.Windows.Forms.CheckBox CHK_L;
}