﻿namespace pk3DS.Core.CTR.Images;

public static class XLIMUtil
{
    /// <summary>
    /// Greatest common multiple (to round up)
    /// </summary>
    /// <param name="n">Number to round-up.</param>
    /// <param name="m">Multiple to round-up to.</param>
    /// <returns>Rounded up number.</returns>
    internal static int GreatestCommonMultiple(int n, int m)
    {
        return (n + m - 1) / m * m;
    }

    /// <summary>
    /// Next Largest Power of 2
    /// </summary>
    /// <param name="x">Input to round up to next 2^n</param>
    /// <returns>2^n > x && x > 2^(n-1) </returns>
    internal static int NextLargestPow2(int x)
    {
        x--; // comment out to always take the next biggest power of two, even if x is already a power of two
        x |= x >> 1;
        x |= x >> 2;
        x |= x >> 4;
        x |= x >> 8;
        x |= x >> 16;
        return x + 1;
    }
}