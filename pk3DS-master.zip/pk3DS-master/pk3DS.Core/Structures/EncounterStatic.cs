﻿namespace pk3DS.Core.Structures;

public abstract class EncounterStatic
{
    public abstract int Species { get; set; }
    public abstract int HeldItem { get; set; }
}