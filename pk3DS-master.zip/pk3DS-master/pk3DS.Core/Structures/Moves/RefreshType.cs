﻿namespace pk3DS.Core.Structures;

public enum RefreshType : byte
{
    None,
    Disheveled,
    Mud,
    Dust,
    Dry,
}