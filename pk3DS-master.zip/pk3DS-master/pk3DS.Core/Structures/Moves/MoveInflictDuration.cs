﻿namespace pk3DS.Core.Structures;

public enum MoveInflictDuration
{
    None = 0,
    Permanent,
    TurnCountSwitch,
    PermanentSwitch,
    TurnCountNoSwitch,
}