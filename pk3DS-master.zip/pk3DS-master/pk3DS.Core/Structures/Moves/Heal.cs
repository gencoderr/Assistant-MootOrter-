﻿namespace pk3DS.Core.Structures;

public enum Heal : byte
{
    None = 0,
    Quarter = 253,
    Half = 254,
    Full = 255,
}