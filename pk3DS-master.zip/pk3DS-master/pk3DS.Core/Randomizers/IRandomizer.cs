﻿namespace pk3DS.Core.Randomizers;

public interface IRandomizer
{
    void Execute();
}