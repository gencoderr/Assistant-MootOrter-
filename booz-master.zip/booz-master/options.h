/* OBSOLETE -- NOW PART OF BOOZ.H */
/* System-specific options for Booz */

/* T_UINT16 must be an unsigned data type of exactly 16 bits */
#define T_UINT16     unsigned short

/* Define FIXFNAME to activate the fixfname() function that converts
filename syntax to be acceptable to the host system */
/* #define FIXFNAME */
