REVISION HISTORY
================

Version 2.00
------------

Revised to extract archives crated with zoo 2.1.  Deleted TINY,
SMALL, and BIG options;  it's all BIG now.  Deleted low-level
I/O (read/write) and replaced it with stdio (fread/fwrite).

Version 1.02
-------------

Fixed bug in function `needed()`.  Added support for Turbo C 1.0.
Revised this documentation and some comments in the source code.

Version 1.01
------------

Included TINY, SMALL, BIG compilation options.  Had a bug in function
`needed()` that sometimes cause file extraction to fail.

Version 1.00
------------

Corresponded to just the Tiny booz 1.02
