type Github = ReturnType<typeof import("@actions/github").getOctokit>;
type Context = typeof import("@actions/github").context;
