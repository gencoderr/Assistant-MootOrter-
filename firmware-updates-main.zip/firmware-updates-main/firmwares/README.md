# Firmware update definition files

This directory contains the definition files for firmware updates.

**WARNING:** Despite the download links being listed here, it is strongly recommended to do the upgrades through Z-Wave JS to avoid mis-identifying devices and installing the wrong firmware.
