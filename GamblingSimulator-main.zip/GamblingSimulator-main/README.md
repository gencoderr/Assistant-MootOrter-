# GAMBLING SIMULATOR

## v0.2.1

### By: SaQreeZ

This is gambling simulator :)

## COMMANDS

- `crime` - More money than work, but risky!
- `double` - Double, or nothing!
- `help` - Commands!
- `lottery` - Play lottery! You have to guess 3 numbers from 1 to 10! Bigger bet/more numbers guessed = MORE MONEY!!!
- `roullete` - Play roullete! (Bet, and then Numbers!)
- `wallet` - Ckeck your wallet!
- `work` - You will work for some money!

## DATA

You can modify data (like changing your money amount in your wallet) as much as you want, but if you do, you wont feel as much satisfaction as without changing it.
