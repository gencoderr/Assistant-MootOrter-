# Ghost-Toolbox-Universal
Make Ghost Toolbox Working on Your Windows 10/11

> [!IMPORTANT]
> - extract nhcolor.exe to system32
> - extract Ghost Toolbox to C:\
run update cmd as admin and wait 30 second and close update cmd
> - run ghost.cmd as admin (wait till close)
> - run ghost.cmd as admin again and enjoy.


# Download here
Download [Ghost_Toolbox](https://github.com/risunCode/Ghost-Toolbox-Universal/releases/download/Toolbox/Ghost.Toolbox-RisunUpdatedWork.zip)
