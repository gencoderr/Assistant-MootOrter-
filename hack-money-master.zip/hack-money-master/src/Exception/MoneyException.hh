<?hh // strict

namespace Money\Exception;
use Exception;

class MoneyException extends \InvalidArgumentException {

}
