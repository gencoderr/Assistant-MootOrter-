<?hh // strict

namespace Money\Exception;
use Exception;

class CurrencyException extends \InvalidArgumentException {

}
